# SPDX-License-Identifier: AGPL-3.0-only
"""Phase 874/882 — CDL-074/075 truth primitive submit CLI helper.

Wires validate_truth_primitive_submission into the ILC CLI `submit` command.
Validates a CDL-073 wire-format submission envelope, optionally persists to
an LMDB graph store (CDL-075), and returns the graph-output contract.

Graph persistence is activated when ILC_TRUTH_GRAPH_STORE_PATH is set in the
environment.  Without that env var, behaviour is identical to Phase 874.

Command surface:
    ilc submit --primitive <name> --payload-json <json-string>
               --agent-id <hex> --epoch <n>
    ilc submit --primitive <name> --payload-file <path>
               --agent-id <hex> --epoch <n>
"""

from __future__ import annotations

import argparse
import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.asymmetric import ed25519

from ilc_core.epistemic.truth_primitive_submission_runtime import (
    CDL_074_DEPENDENCY as RUNTIME_CDL_074_DEPENDENCY,
    AGENT_ISSUABLE_PRIMITIVES,
    validate_truth_primitive_submission,
)
from ilc_core.epistemic.node_submission_runtime import EpistemicSubmissionError
from ilc_core.epistemic.truth_primitive_sig_verifier import attach_truth_primitive_signature
from ilc_core.value_action.local_signing_provider import LocalEd25519SigningProvider

D2E_SUBMIT_CLI_VERSION = "d2e_submit_cli_874_GAP_GRAPH_SIGN_00.v0.1"
CDL_074_DEPENDENCY = RUNTIME_CDL_074_DEPENDENCY
CDL_075_DEPENDENCY = "cdl_075_truth_primitive_graph_persistence.v0.1"
CDL_076_DEPENDENCY = "cdl_076_truth_primitive_announcement_gossip.v0.1"
_MAX_SUBMIT_PAYLOAD_BYTES = 256 * 1024
_GRAPH_SUBMIT_AGENT_ID_RE = re.compile(r"^[0-9a-f]{64}$")
_MAX_REFUTATION_CRITERION_BYTES = 500

if CDL_074_DEPENDENCY != "cdl_074_truth_primitive_runtime_ratified.v0.1":
    raise ValueError("submit_cli_dependency_mismatch")


@dataclass(frozen=True)
class GraphSubmitAdvisoryEnvelope:
    """Graph-native advisory wrapper for signed CDL-073 submissions."""

    agent_id_hex: str
    epoch: int
    truth_primitive: dict[str, Any]
    sig: str
    sig_pubkey_hex: str
    sig_pubkey_fingerprint: str
    sig_scheme: str


class SubmitCommandError(Exception):
    """Typed error carrying submit contract error token and message."""

    def __init__(self, token: str, message: str) -> None:
        super().__init__(message)
        self.token = token
        self.message = message


def _reject_non_finite_json_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON constant is not allowed: {value}")


def _require_graph_submit_agent_id(agent_id_hex: str) -> None:
    if not isinstance(agent_id_hex, str):
        raise ValueError("invalid_agent_id_hex")
    if _GRAPH_SUBMIT_AGENT_ID_RE.fullmatch(agent_id_hex) is None:
        raise ValueError("invalid_agent_id_hex")


def _require_graph_submit_epoch(epoch: int) -> None:
    if isinstance(epoch, bool) or not isinstance(epoch, int) or epoch < 0:
        raise ValueError("invalid_epoch")


def build_graph_submit_envelope(
    truth_primitive: dict[str, Any],
    agent_id_hex: str,
    epoch: int,
    private_key: ed25519.Ed25519PrivateKey,
) -> GraphSubmitAdvisoryEnvelope:
    """Return a graph-specific advisory envelope signed over CDL-073 fields."""

    _require_graph_submit_agent_id(agent_id_hex)
    _require_graph_submit_epoch(epoch)
    if not isinstance(truth_primitive, dict):
        raise ValueError("invalid_truth_primitive")
    payload = truth_primitive.get("payload")
    primitive = truth_primitive.get("primitive")
    version = truth_primitive.get("v", 1)
    if not isinstance(payload, dict) or not isinstance(primitive, str) or not primitive:
        raise ValueError("invalid_truth_primitive")
    if version != 1:
        raise ValueError("invalid_truth_primitive")

    # GRAPH_SUBMIT type is advisory pending CDL-111 ratification — do not wire to AgentActionEnvelope dispatch until ratified
    envelope_dict: dict[str, Any] = {
        "agent_id": agent_id_hex,
        "epoch": epoch,
        "payload": payload,
        "primitive": primitive,
        "v": 1,
    }
    signed = attach_truth_primitive_signature(envelope_dict, private_key)
    return GraphSubmitAdvisoryEnvelope(
        agent_id_hex=agent_id_hex,
        epoch=epoch,
        truth_primitive=dict(envelope_dict),
        sig=str(signed["sig"]),
        sig_pubkey_hex=str(signed["sig_pubkey_hex"]),
        sig_pubkey_fingerprint=str(signed["sig_pubkey_fingerprint"]),
        sig_scheme=str(signed["sig_scheme"]),
    )


def build_refutation_primitive(
    target_node_id: str,
    refutation_criterion_text: str,
    evidence_node_ids: list[Any],
    agent_id_hex: str,
    epoch: int,
) -> dict[str, Any]:
    """Build a CDL-073 refute.claim submission dict accepted by CDL-074."""

    _require_graph_submit_agent_id(agent_id_hex)
    _require_graph_submit_epoch(epoch)
    if not isinstance(target_node_id, str) or not target_node_id:
        raise ValueError("invalid_refutation_target_empty")
    if not isinstance(refutation_criterion_text, str):
        raise ValueError("invalid_refutation_criterion_type")
    if len(refutation_criterion_text.encode("utf-8")) > _MAX_REFUTATION_CRITERION_BYTES:
        raise ValueError("invalid_refutation_reason_too_long")
    if not isinstance(evidence_node_ids, list):
        raise ValueError("invalid_evidence_node_id")
    for evidence_node_id in evidence_node_ids:
        if not isinstance(evidence_node_id, str) or not evidence_node_id:
            raise ValueError("invalid_evidence_node_id")

    return {
        "agent_id": agent_id_hex,
        "epoch": epoch,
        "payload": {
            "evidence_node_ids": list(evidence_node_ids),
            "refutation_criterion": {
                "claim": refutation_criterion_text,
                "claim_form": "singular",
                "evidence_type": "logical",
                "has_falsifiable_test": True,
                "scope_boundary": f"target_node_id:{target_node_id}",
            },
            "target_node_id": target_node_id,
        },
        "primitive": "refute.claim",
        "v": 1,
    }


def check_graph_mutation_allowed(public_path_guard_value: bool) -> None:
    """Fail closed before graph mutation when the caller's guard remains set."""

    if not isinstance(public_path_guard_value, bool):
        raise TypeError("invalid_guard_value_not_bool")
    if public_path_guard_value is True:
        raise ValueError("graph_mutation_blocked_public_path_not_cleared")


def _load_payload(args: argparse.Namespace) -> dict[str, Any]:
    """Load payload from --payload-json string or --payload-file path."""
    json_str = getattr(args, "payload_json", None)
    file_path = getattr(args, "payload_file", None)

    if json_str and file_path:
        raise SubmitCommandError(
            "submit_payload_ambiguous",
            "provide --payload-json or --payload-file, not both",
        )
    if not json_str and not file_path:
        raise SubmitCommandError(
            "submit_payload_missing",
            "one of --payload-json or --payload-file is required",
        )

    raw = json_str
    if file_path:
        path = Path(file_path)
        if not path.exists():
            raise SubmitCommandError(
                "submit_payload_file_not_found",
                f"payload file not found: {file_path}",
            )
        try:
            raw = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise SubmitCommandError(
                "submit_payload_file_read_error",
                f"could not read payload file: {exc}",
            ) from exc

    if not isinstance(raw, str):
        raise SubmitCommandError(
            "submit_payload_invalid_type",
            "payload source must produce text JSON",
        )
    if len(raw.encode("utf-8")) > _MAX_SUBMIT_PAYLOAD_BYTES:
        raise SubmitCommandError(
            "submit_payload_too_large",
            "payload exceeds maximum submit payload size",
        )

    try:
        payload = json.loads(raw, parse_constant=_reject_non_finite_json_constant)
    except json.JSONDecodeError as exc:
        raise SubmitCommandError(
            "submit_payload_invalid_json",
            f"payload is not valid JSON: {exc}",
        ) from exc
    except ValueError as exc:
        raise SubmitCommandError(
            "submit_payload_invalid_json",
            f"payload is not valid JSON: {exc}",
        ) from exc

    if not isinstance(payload, dict):
        raise SubmitCommandError(
            "submit_payload_not_object",
            "payload must be a JSON object",
        )
    return payload


def _sign_submission_envelope(envelope: dict[str, Any], signing_key_uri: str | None) -> dict[str, Any]:
    """Attach optional Ed25519 hotkey signature metadata to a submission envelope."""

    if not signing_key_uri:
        return envelope
    if envelope.get("sig") not in {None, "", "UNSIGNED"}:
        raise SubmitCommandError(
            "submit_signature_ambiguous",
            "provide --sig or --signing-key, not both",
        )
    try:
        private_key = LocalEd25519SigningProvider()._load_private_key(signing_key_uri)
        return attach_truth_primitive_signature(envelope, private_key)
    except SubmitCommandError:
        raise
    except ValueError as exc:
        raise SubmitCommandError("submit_signing_key_invalid", str(exc)) from exc


def handle_submit(args: argparse.Namespace) -> dict[str, Any]:
    """Execute the submit command.

    Builds a CDL-073 submission envelope from CLI arguments, validates it via
    validate_truth_primitive_submission, and returns the graph-output contract.
    """
    primitive = getattr(args, "primitive", None)
    if not primitive:
        raise SubmitCommandError("submit_primitive_missing", "--primitive is required")

    agent_id = getattr(args, "agent_id", None)
    if not agent_id:
        raise SubmitCommandError("submit_agent_id_missing", "--agent-id is required")

    epoch = getattr(args, "epoch", None)
    if epoch is None or isinstance(epoch, bool) or not isinstance(epoch, int) or epoch < 0:
        raise SubmitCommandError(
            "submit_epoch_invalid",
            "--epoch must be a non-negative integer",
        )

    payload = _load_payload(args)

    envelope: dict[str, Any] = {
        "v": 1,
        "primitive": primitive,
        "agent_id": agent_id,
        "epoch": epoch,
        "payload": payload,
        "sig": args.sig if hasattr(args, "sig") and args.sig else "UNSIGNED",
    }

    try:
        result = validate_truth_primitive_submission(envelope)
    except EpistemicSubmissionError as exc:
        raise SubmitCommandError(exc.token, str(exc)) from exc

    envelope = _sign_submission_envelope(envelope, getattr(args, "signing_key", None))

    edges_out = [
        {"edge_type": e.edge_type, "source": e.source, "target": e.target}
        for e in result.edges
    ]

    # CDL-075: persist to LMDB graph store when ILC_TRUTH_GRAPH_STORE_PATH is set.
    node_id: str | None = None
    graph_persistence: str = "deferred — CDL-075 graph store path not configured"
    write_receipt: dict[str, Any] = {}
    store_path = os.environ.get("ILC_TRUTH_GRAPH_STORE_PATH", "").strip()
    if store_path:
        # Missing guard attribute means this caller is using the public-RC-cleared
        # local write path. An explicit True still blocks before any LMDB write.
        check_graph_mutation_allowed(getattr(args, "public_path_guard_value", False))
        from ilc_core.epistemic.truth_primitive_graph_store import (
            write_truth_primitive_result,
        )
        from ilc_core.storage.truth_primitive_graph_lmdb_adapter import (
            TruthPrimitiveGraphStore,
        )
        store = TruthPrimitiveGraphStore(store_path)
        try:
            write_receipt = write_truth_primitive_result(store, envelope, result)
            node_id = write_receipt["node_id"]
            graph_persistence = "persisted"
        finally:
            store.close()

    # CDL-076: announce to gossip peers after confirmed CDL-075 persist.
    gossip_delivery: str = "deferred — gossip peers not configured"
    if node_id:
        from ilc_core.network.d2d.truth_primitive_gossip_runtime import (
            announce_truth_primitive,
        )
        gossip_receipt = announce_truth_primitive(write_receipt, envelope)
        gossip_delivery = gossip_receipt["gossip_delivery"]

    return {
        "subcommand": "submit",
        "primitive": result.primitive,
        "creates_node": result.creates_node,
        "node_primitive_type": result.node_primitive_type,
        "node_id": node_id,
        "edges": edges_out,
        "graph_persistence": graph_persistence,
        "gossip_delivery": gossip_delivery,
        "version": D2E_SUBMIT_CLI_VERSION,
    }
