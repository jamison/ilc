# SPDX-License-Identifier: AGPL-3.0-only
"""CDL-048 ConversionCandidate eligible-lot runtime.

Phase 1573j adds a schema-level generator for OBL-040. It derives
ConversionCandidate records from epoch ECU lot state using the CDL-048
deadline-epoch rule. It does not mutate the CDL-048 sweeper state, write a
ledger, resolve conversion settlement, or expose a live CDL-057 witness getter.
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any

from ilc_core.ledger.distributed_conversion_schema import (
    CDL057_WITNESS_ABSENT_TOKEN,
    GENESIS_TRANCHE_APPLIED_BY_AUTHORIZED_VALUE_PATH,
    GENESIS_TRANCHE_EXPLICITLY_DEFERRED,
    ConversionCandidate,
)


CONVERSION_CANDIDATE_RUNTIME_VERSION = "conversion_candidate_runtime_1573j.v0.1"
CONVERSION_CANDIDATE_RUNTIME_NOT_ACTIVATED = False  # cleared by Phase 1575g economic guard clearance
MANDATORY_CONVERSION_EPOCHS_CDL048 = 4
CONVERSION_CANDIDATE_SOURCE = "conversion_candidate_runtime_1573j"


def generate_conversion_candidates(
    epoch_ecu_state: dict[str, Any],
    current_epoch: int,
    mandatory_conversion_epochs: int = MANDATORY_CONVERSION_EPOCHS_CDL048,
) -> list[ConversionCandidate]:
    """Build deterministic ConversionCandidate rows for deadline-eligible ECU lots.

    Eligibility follows the existing CDL-048 sweeper semantics: a lot is
    eligible when ``current_epoch >= deadline_epoch``. The
    ``mandatory_conversion_epochs`` parameter is retained as the CDL-048
    contract anchor, but the deadline is read from each lot so this runtime does
    not duplicate sweeper registration logic.
    """

    if CONVERSION_CANDIDATE_RUNTIME_NOT_ACTIVATED:
        raise ValueError("conversion_candidate_runtime_not_activated")
    epoch = _require_epoch(current_epoch, token="current_epoch_invalid")
    _require_epoch(mandatory_conversion_epochs, token="mandatory_conversion_epochs_invalid")
    lots = _require_lots(epoch_ecu_state)
    candidates: list[ConversionCandidate] = []
    for lot in lots:
        normalized_lot = _require_lot(lot)
        raw_amount = normalized_lot["amount_ecu"]
        if isinstance(raw_amount, float):
            raise ValueError("ecu_amount_must_be_decimal_not_float")
        if isinstance(raw_amount, bool):
            raise ValueError("amount_ecu_invalid")
        if isinstance(raw_amount, Decimal):
            amount = raw_amount
        else:
            try:
                amount = Decimal(raw_amount)
            except (InvalidOperation, TypeError, ValueError) as exc:
                raise ValueError("amount_ecu_invalid") from exc
        if not amount.is_finite():
            raise ValueError("invalid_amount_non_finite:amount_ecu")

        deadline_epoch = _require_epoch(
            normalized_lot["deadline_epoch"],
            token="deadline_epoch_invalid",
        )
        issue_epoch = _require_epoch(
            normalized_lot["issue_epoch"],
            token="issue_epoch_invalid",
        )
        if epoch < deadline_epoch:
            continue
        is_genesis = normalized_lot.get("is_genesis_tranche") is True
        treatment = (
            GENESIS_TRANCHE_APPLIED_BY_AUTHORIZED_VALUE_PATH
            if is_genesis
            else GENESIS_TRANCHE_EXPLICITLY_DEFERRED
        )
        # CDL-057 get_latest_witness_ref is not exposed in this runtime lane.
        candidates.append(
            ConversionCandidate(
                lot_id=_require_text(normalized_lot["lot_id"], token="lot_id_required"),
                agent_id=_require_text(
                    normalized_lot["agent_id"],
                    token="agent_id_required",
                ),
                amount_ecu=amount,
                issue_epoch=issue_epoch,
                deadline_epoch=deadline_epoch,
                conversion_epoch=epoch,
                genesis_tranche_treatment=treatment,
                cdl057_witness_ref=CDL057_WITNESS_ABSENT_TOKEN,
                candidate_source=CONVERSION_CANDIDATE_SOURCE,
            )
        )
    return sorted(candidates, key=lambda candidate: candidate.lot_id)


def detect_omission(
    expected_candidates: list[ConversionCandidate],
    checkpoint_candidates: list[ConversionCandidate],
) -> list[ConversionCandidate]:
    """Return expected candidates missing from a checkpoint candidate list."""

    expected = _require_candidate_list(expected_candidates, token="expected_candidates_invalid")
    checkpoint = _require_candidate_list(
        checkpoint_candidates,
        token="checkpoint_candidates_invalid",
    )
    checkpoint_lot_ids = {candidate.lot_id for candidate in checkpoint}
    return [
        candidate
        for candidate in expected
        if candidate.lot_id not in checkpoint_lot_ids
    ]


def _require_lots(epoch_ecu_state: dict[str, Any]) -> list[dict[str, Any]]:
    if not isinstance(epoch_ecu_state, dict):
        raise ValueError("epoch_ecu_state_must_be_object")
    lots = epoch_ecu_state.get("lots")
    if not isinstance(lots, list):
        raise ValueError("epoch_ecu_state_lots_must_be_list")
    return lots


def _require_lot(lot: Any) -> dict[str, Any]:
    if not isinstance(lot, dict):
        raise ValueError("ecu_lot_must_be_object")
    for field in ("lot_id", "agent_id", "amount_ecu", "issue_epoch", "deadline_epoch"):
        if field not in lot:
            raise ValueError(f"{field}_required")
    return lot


def _require_text(value: Any, *, token: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(token)
    return value.strip()


def _require_epoch(value: Any, *, token: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(token)
    return value


def _require_candidate_list(
    candidates: list[ConversionCandidate],
    *,
    token: str,
) -> list[ConversionCandidate]:
    if not isinstance(candidates, list):
        raise ValueError(token)
    for candidate in candidates:
        if not isinstance(candidate, ConversionCandidate):
            raise ValueError(token)
    return candidates


__all__ = [
    "CONVERSION_CANDIDATE_RUNTIME_NOT_ACTIVATED",
    "CONVERSION_CANDIDATE_RUNTIME_VERSION",
    "CONVERSION_CANDIDATE_SOURCE",
    "MANDATORY_CONVERSION_EPOCHS_CDL048",
    "ConversionCandidate",
    "detect_omission",
    "generate_conversion_candidates",
]
