# PUBLIC_RC_EXCLUDE: internal_phase_helper_not_public_rc_launch_surface
# PUBLIC_RC_EXCLUDE_REASON: local Phase 1275 proof-binding scaffold only.
# PUBLIC_RC_INCLUDE_REQUIRES: explicit allowlist review and ratified public claimability verifier/API authority.
# PHASE_1282_FIX1_AUDIT_HARDENING: phase_1282_fix1_claimability_runtime_audit_hardening
# PHASE_1282_FIX1_TOKENS: claimability_conversion_receipt_semantics_hardened_phase_1282_fix1; settled_runtime_root_domain_separation_hardened_phase_1282_fix1; balance_receipt_decimal_boundary_hardened_phase_1282_fix1; cdl048_conversion_sweeper_public_rc_exclude_marked_phase_1282_fix1; public_rc_remains_blocked_after_phase_1282_fix1

"""Phase 1275 local claimability proof-binding boundary.

This module records deterministic proof material for a future public
claimability verifier. It deliberately does not expose a public API, wallet
write path, mint path, spend path, transfer path, withdrawal path, or settlement
path.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any

from ilc_core.ledger.cdl048_conversion_sweeper_runtime import (
    CDL048_CONVERSION_DEADLINE_ISSUANCE_EPOCHS,
    CDL048_CONVERSION_SWEEPER_RUNTIME_VERSION,
    CONVERSION_SWEEPER_NO_PUBLIC_CLAIMABILITY_TOKEN,
    CONVERSION_TRANSITION,
    ECU_LOT_DEADLINE_ENFORCEMENT_TOKEN,
    WALLET_WITHDRAWAL_TRANSFER_SPEND_BLOCKED_TOKEN,
    ConversionReceipt,
    conversion_receipt_payload,
)


CLAIMABILITY_PROOF_BINDING_RUNTIME_VERSION = (
    "claimability_proof_binding_runtime_boundary_phase_1275.v0.1"
)
SETTLED_ROOT_WALLET_ROOT_RECEIPT_BINDING_TOKEN = (
    "settled_root_wallet_root_receipt_binding_recorded_phase_1275"
)
NON_LOOPBACK_CLAIMABILITY_API_BLOCKED_TOKEN = (
    "non_loopback_claimability_api_still_blocked_phase_1275"
)
PUBLIC_CLAIMABILITY_NOT_ACTIVATED_TOKEN = (
    "public_claimability_not_activated_phase_1275"
)

CLAIMABILITY_STATE = "proof_bound_local_only"
CLAIMABILITY_PROOF_REF_PREFIX = "claimability_proof_sha256"
LATEST_BALANCE_RECEIPT_REF_PREFIX = "balance_receipt_sha256"
WALLET_STATE_ROOT_PREFIX = "wallet_state_sha256"
SETTLED_RUNTIME_ROOT_PREFIXES = ("settled_runtime_sha256",)
HISTORY_DIGEST_PREFIX = "history_sha256"

_HEX = frozenset("0123456789abcdef")
_MAX_CANONICAL_PAYLOAD_DEPTH = 32
_MAX_CANONICAL_PAYLOAD_NODES = 100_000
_EXPECTED_CONVERSION_RECEIPT_KEYS = {
    "agent_id",
    "amount_ecu",
    "conversion_epoch",
    "conversion_key_sha256",
    "conversion_state_transition",
    "deadline_epoch",
    "ecu_mint_authorized",
    "ilc_settlement_authorized",
    "issue_epoch",
    "lot_id",
    "public_claimability_activated",
    "receipt_sha256",
    "runtime_version",
    "settled_runtime_epoch",
    "settled_runtime_root",
    "sweeper_state_root_before",
    "tokens",
    "wallet_spend_enabled",
    "wallet_state_root",
    "wallet_transfer_enabled",
    "wallet_withdrawal_enabled",
}


class ClaimabilityProofBindingRuntimeError(ValueError):
    """Fail-closed claimability proof-binding error with a stable token."""

    def __init__(self, token: str, message: str) -> None:
        super().__init__(message)
        self.token = token


@dataclass(frozen=True)
class ClaimabilityProofBinding:
    runtime_version: str
    agent_id: str
    epoch_id: str
    settled_runtime_root: str
    wallet_state_root: str
    latest_balance_receipt: dict[str, Any]
    latest_balance_receipt_ref: str
    history_digest: str
    conversion_receipt: dict[str, Any]
    conversion_receipt_sha256: str
    conversion_key_sha256: str
    conversion_lot_id: str
    conversion_epoch: int
    conversion_deadline_epoch: int
    conversion_sweeper_state_root_before: str
    claimability_state: str
    proof_binding_sha256: str
    public_claimability_activated: bool = False
    non_loopback_claimability_api_enabled: bool = False
    wallet_withdrawal_enabled: bool = False
    wallet_transfer_enabled: bool = False
    wallet_spend_enabled: bool = False
    ecu_mint_authorized: bool = False
    ilc_settlement_authorized: bool = False
    transport_principal_required_before_non_loopback: bool = True


def build_claimability_proof_binding(
    *,
    agent_id: str,
    epoch_id: str,
    settled_runtime_root: str,
    wallet_state_root: str,
    latest_balance_receipt: dict[str, Any],
    history_digest: str,
    conversion_receipt: ConversionReceipt | dict[str, Any],
) -> ClaimabilityProofBinding:
    """Build a deterministic local-only claimability proof binding."""

    normalized_agent_id = _require_text(agent_id, token="claimability_agent_id_required")
    normalized_epoch_id = _require_text(epoch_id, token="claimability_epoch_id_required")
    normalized_settled_root = _require_prefixed_sha256(
        settled_runtime_root,
        prefixes=SETTLED_RUNTIME_ROOT_PREFIXES,
        token="claimability_settled_runtime_root_invalid",
    )
    normalized_wallet_root = _require_prefixed_sha256(
        wallet_state_root,
        prefixes=(WALLET_STATE_ROOT_PREFIX,),
        token="claimability_wallet_state_root_invalid",
    )
    normalized_history_digest = _require_sha256_or_prefixed_sha256(
        history_digest,
        prefix=HISTORY_DIGEST_PREFIX,
        token="claimability_history_digest_invalid",
    )
    normalized_balance_receipt = _normalize_latest_balance_receipt(
        latest_balance_receipt,
        epoch_id=normalized_epoch_id,
    )
    normalized_conversion_receipt = _normalize_conversion_receipt(conversion_receipt)
    _validate_conversion_receipt_semantics(
        normalized_conversion_receipt,
        agent_id=normalized_agent_id,
        settled_runtime_root=normalized_settled_root,
        wallet_state_root=normalized_wallet_root,
    )

    latest_balance_ref = latest_balance_receipt_ref(normalized_balance_receipt)
    body = {
        "agent_id": normalized_agent_id,
        "canonical_agent_identity": normalized_agent_id,
        "claimability_state": CLAIMABILITY_STATE,
        "conversion_deadline_epoch": normalized_conversion_receipt["deadline_epoch"],
        "conversion_epoch": normalized_conversion_receipt["conversion_epoch"],
        "conversion_key_sha256": normalized_conversion_receipt["conversion_key_sha256"],
        "conversion_lot_id": normalized_conversion_receipt["lot_id"],
        "conversion_receipt": normalized_conversion_receipt,
        "conversion_receipt_sha256": normalized_conversion_receipt["receipt_sha256"],
        "conversion_sweeper_state_root_before": normalized_conversion_receipt[
            "sweeper_state_root_before"
        ],
        "ecu_mint_authorized": False,
        "epoch_id": normalized_epoch_id,
        "history_digest": normalized_history_digest,
        "ilc_settlement_authorized": False,
        "latest_balance_receipt": normalized_balance_receipt,
        "latest_balance_receipt_ref": latest_balance_ref,
        "non_loopback_claimability_api_enabled": False,
        "public_claimability_activated": False,
        "runtime_version": CLAIMABILITY_PROOF_BINDING_RUNTIME_VERSION,
        "settled_runtime_root": normalized_settled_root,
        "tokens": _tokens(),
        "transport_principal_required_before_non_loopback": True,
        "wallet_spend_enabled": False,
        "wallet_state_root": normalized_wallet_root,
        "wallet_transfer_enabled": False,
        "wallet_withdrawal_enabled": False,
    }
    proof_hash = _sha256_payload(body)
    return ClaimabilityProofBinding(
        runtime_version=CLAIMABILITY_PROOF_BINDING_RUNTIME_VERSION,
        agent_id=normalized_agent_id,
        epoch_id=normalized_epoch_id,
        settled_runtime_root=normalized_settled_root,
        wallet_state_root=normalized_wallet_root,
        latest_balance_receipt=normalized_balance_receipt,
        latest_balance_receipt_ref=latest_balance_ref,
        history_digest=normalized_history_digest,
        conversion_receipt=normalized_conversion_receipt,
        conversion_receipt_sha256=normalized_conversion_receipt["receipt_sha256"],
        conversion_key_sha256=normalized_conversion_receipt["conversion_key_sha256"],
        conversion_lot_id=normalized_conversion_receipt["lot_id"],
        conversion_epoch=normalized_conversion_receipt["conversion_epoch"],
        conversion_deadline_epoch=normalized_conversion_receipt["deadline_epoch"],
        conversion_sweeper_state_root_before=normalized_conversion_receipt[
            "sweeper_state_root_before"
        ],
        claimability_state=CLAIMABILITY_STATE,
        proof_binding_sha256=proof_hash,
    )


def claimability_proof_payload(binding: ClaimabilityProofBinding) -> dict[str, Any]:
    if not isinstance(binding, ClaimabilityProofBinding):
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_binding_invalid",
            "binding must be a ClaimabilityProofBinding",
        )
    payload = {
        "agent_id": binding.agent_id,
        "canonical_agent_identity": binding.agent_id,
        "claimability_state": binding.claimability_state,
        "conversion_deadline_epoch": binding.conversion_deadline_epoch,
        "conversion_epoch": binding.conversion_epoch,
        "conversion_key_sha256": binding.conversion_key_sha256,
        "conversion_lot_id": binding.conversion_lot_id,
        "conversion_receipt": binding.conversion_receipt,
        "conversion_receipt_sha256": binding.conversion_receipt_sha256,
        "conversion_sweeper_state_root_before": binding.conversion_sweeper_state_root_before,
        "ecu_mint_authorized": binding.ecu_mint_authorized,
        "epoch_id": binding.epoch_id,
        "history_digest": binding.history_digest,
        "ilc_settlement_authorized": binding.ilc_settlement_authorized,
        "latest_balance_receipt": binding.latest_balance_receipt,
        "latest_balance_receipt_ref": binding.latest_balance_receipt_ref,
        "non_loopback_claimability_api_enabled": binding.non_loopback_claimability_api_enabled,
        "proof_binding_sha256": binding.proof_binding_sha256,
        "public_claimability_activated": binding.public_claimability_activated,
        "runtime_version": binding.runtime_version,
        "settled_runtime_root": binding.settled_runtime_root,
        "tokens": _tokens(),
        "transport_principal_required_before_non_loopback": (
            binding.transport_principal_required_before_non_loopback
        ),
        "wallet_spend_enabled": binding.wallet_spend_enabled,
        "wallet_state_root": binding.wallet_state_root,
        "wallet_transfer_enabled": binding.wallet_transfer_enabled,
        "wallet_withdrawal_enabled": binding.wallet_withdrawal_enabled,
    }
    _reject_float_tree(payload)
    _validate_proof_hash(payload)
    return payload


def canonical_claimability_proof_json(binding: ClaimabilityProofBinding) -> str:
    return canonical_json(claimability_proof_payload(binding))


def claimability_proof_ref(binding: ClaimabilityProofBinding) -> str:
    payload = claimability_proof_payload(binding)
    return f"{CLAIMABILITY_PROOF_REF_PREFIX}:{payload['proof_binding_sha256']}"


def latest_balance_receipt_ref(payload: dict[str, Any]) -> str:
    normalized = _normalize_latest_balance_receipt(
        payload,
        epoch_id=_require_text(
            payload.get("epoch_id") if isinstance(payload, dict) else None,
            token="claimability_latest_balance_receipt_invalid",
        ),
    )
    return f"{LATEST_BALANCE_RECEIPT_REF_PREFIX}:{_sha256_payload(normalized)}"


def canonical_json(payload: Any) -> str:
    _reject_float_tree(payload)
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _normalize_latest_balance_receipt(
    payload: dict[str, Any],
    *,
    epoch_id: str,
) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_latest_balance_receipt_invalid",
            "latest_balance_receipt must be an object",
        )
    _reject_float_tree(payload)
    normalized = dict(payload)
    receipt_epoch = _require_text(
        normalized.get("epoch_id"),
        token="claimability_latest_balance_receipt_invalid",
    )
    if receipt_epoch != epoch_id:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_latest_balance_receipt_epoch_mismatch",
            "latest_balance_receipt epoch_id must match proof epoch_id",
        )
    normalized["reward_delta_ilc"] = _require_decimal_string(
        normalized.get("reward_delta_ilc"),
        token="claimability_latest_balance_receipt_invalid",
        non_negative=False,
    )
    normalized["balance_after_ilc"] = _require_decimal_string(
        normalized.get("balance_after_ilc"),
        token="claimability_latest_balance_receipt_invalid",
        non_negative=True,
    )
    _require_text(
        normalized.get("settlement_status"),
        token="claimability_latest_balance_receipt_invalid",
    )
    if normalized["settlement_status"] != "applied":
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_latest_balance_receipt_invalid",
            "latest_balance_receipt settlement_status must be applied",
        )
    return normalized


def _normalize_conversion_receipt(
    receipt: ConversionReceipt | dict[str, Any],
) -> dict[str, Any]:
    if isinstance(receipt, ConversionReceipt):
        payload = conversion_receipt_payload(receipt)
    elif isinstance(receipt, dict):
        payload = dict(receipt)
    else:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_invalid",
            "conversion_receipt must be a ConversionReceipt or object",
        )
    _reject_float_tree(payload)
    if set(payload) != _EXPECTED_CONVERSION_RECEIPT_KEYS:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_invalid",
            "conversion_receipt fields do not match the Phase 1274 receipt shape",
        )
    _validate_conversion_receipt_hash(payload)
    return payload


def _validate_conversion_receipt_semantics(
    payload: dict[str, Any],
    *,
    agent_id: str,
    settled_runtime_root: str,
    wallet_state_root: str,
) -> None:
    if payload["runtime_version"] != CDL048_CONVERSION_SWEEPER_RUNTIME_VERSION:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_invalid",
            "conversion_receipt runtime_version is not the Phase 1274 skeleton",
        )
    if payload["agent_id"] != agent_id:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_agent_mismatch",
            "conversion_receipt agent_id must match proof agent_id",
        )
    if payload["wallet_state_root"] != wallet_state_root:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_wallet_root_mismatch",
            "conversion_receipt wallet_state_root must match proof wallet_state_root",
        )
    if payload["settled_runtime_root"] != settled_runtime_root:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_settled_root_mismatch",
            "conversion_receipt settled_runtime_root must match proof settled_runtime_root",
        )
    if payload["settled_runtime_epoch"] != payload["conversion_epoch"]:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_invalid",
            "conversion_receipt settled_runtime_epoch must match conversion_epoch",
        )
    if payload["conversion_state_transition"] != CONVERSION_TRANSITION:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_invalid",
            "conversion_receipt transition does not match the CDL-048 conversion transition",
        )
    canonical_amount = _require_decimal_string(
        payload["amount_ecu"],
        token="claimability_conversion_receipt_invalid",
        positive=True,
    )
    if payload["amount_ecu"] != canonical_amount:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_invalid",
            "conversion_receipt amount_ecu must be canonical Decimal text",
        )
    issue_epoch = _require_non_negative_int(
        payload["issue_epoch"],
        token="claimability_conversion_receipt_invalid",
    )
    _require_non_negative_int(
        payload["conversion_epoch"],
        token="claimability_conversion_receipt_invalid",
    )
    _require_non_negative_int(
        payload["deadline_epoch"],
        token="claimability_conversion_receipt_invalid",
    )
    if payload["deadline_epoch"] != issue_epoch + CDL048_CONVERSION_DEADLINE_ISSUANCE_EPOCHS:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_invalid",
            "conversion_receipt deadline_epoch does not match the CDL-048 issuance window",
        )
    if payload["conversion_epoch"] < issue_epoch:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_invalid",
            "conversion_receipt conversion_epoch cannot precede issue_epoch",
        )
    if payload["conversion_epoch"] > payload["deadline_epoch"]:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_invalid",
            "conversion_receipt conversion_epoch exceeds deadline_epoch",
        )
    _require_bare_sha256(
        payload["receipt_sha256"],
        token="claimability_conversion_receipt_sha256_invalid",
    )
    _require_bare_sha256(
        payload["conversion_key_sha256"],
        token="claimability_conversion_key_sha256_invalid",
    )
    _require_prefixed_sha256(
        payload["sweeper_state_root_before"],
        prefixes=("cdl048_conversion_sweeper_state_sha256",),
        token="claimability_conversion_sweeper_state_root_invalid",
    )
    expected_conversion_key = _sha256_payload(
        {
            "agent_id": payload["agent_id"],
            "conversion_epoch": payload["conversion_epoch"],
            "conversion_state_transition": CONVERSION_TRANSITION,
            "lot_id": payload["lot_id"],
            "settled_runtime_root": payload["settled_runtime_root"],
            "wallet_state_root": payload["wallet_state_root"],
        }
    )
    if payload["conversion_key_sha256"] != expected_conversion_key:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_key_sha256_invalid",
            "conversion_receipt conversion_key_sha256 does not match binding material",
        )
    tokens = payload["tokens"]
    if not isinstance(tokens, list) or not all(isinstance(item, str) for item in tokens):
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_invalid",
            "conversion_receipt tokens must be a list of strings",
        )
    if not {
        CONVERSION_SWEEPER_NO_PUBLIC_CLAIMABILITY_TOKEN,
        ECU_LOT_DEADLINE_ENFORCEMENT_TOKEN,
        WALLET_WITHDRAWAL_TRANSFER_SPEND_BLOCKED_TOKEN,
    }.issubset(set(tokens)):
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_invalid",
            "conversion_receipt is missing Phase 1274 non-activation tokens",
        )
    for field in (
        "public_claimability_activated",
        "wallet_withdrawal_enabled",
        "wallet_transfer_enabled",
        "wallet_spend_enabled",
        "ecu_mint_authorized",
        "ilc_settlement_authorized",
    ):
        if payload[field] is not False:
            raise ClaimabilityProofBindingRuntimeError(
                "claimability_conversion_receipt_activation_forbidden",
                f"conversion_receipt field {field} must be false",
            )


def _validate_conversion_receipt_hash(payload: dict[str, Any]) -> None:
    expected_payload = dict(payload)
    receipt_sha256 = expected_payload.pop("receipt_sha256", None)
    if receipt_sha256 != _sha256_payload(expected_payload):
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_conversion_receipt_hash_mismatch",
            "conversion_receipt receipt_sha256 does not match canonical body",
        )


def _validate_proof_hash(payload: dict[str, Any]) -> None:
    expected_payload = dict(payload)
    proof_hash = expected_payload.pop("proof_binding_sha256", None)
    if proof_hash != _sha256_payload(expected_payload):
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_proof_hash_mismatch",
            "proof_binding_sha256 does not match canonical proof body",
        )


def _require_text(value: object, *, token: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ClaimabilityProofBindingRuntimeError(token, "required non-empty string")
    return value.strip()


def _require_non_negative_int(value: object, *, token: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ClaimabilityProofBindingRuntimeError(token, "required non-negative integer")
    return value


def _require_decimal_string(
    value: object,
    *,
    token: str,
    non_negative: bool = False,
    positive: bool = False,
) -> str:
    text = _require_text(value, token=token)
    try:
        number = Decimal(text)
    except InvalidOperation as exc:
        raise ClaimabilityProofBindingRuntimeError(token, "required finite Decimal string") from exc
    if not number.is_finite():
        raise ClaimabilityProofBindingRuntimeError(token, "required finite Decimal string")
    if positive and number <= Decimal("0"):
        raise ClaimabilityProofBindingRuntimeError(token, "required positive Decimal string")
    if non_negative and number < Decimal("0"):
        raise ClaimabilityProofBindingRuntimeError(token, "required non-negative Decimal string")
    return _decimal_to_canonical_string(number)


def _require_prefixed_sha256(value: object, *, prefixes: tuple[str, ...], token: str) -> str:
    text = _require_text(value, token=token)
    if ":" not in text:
        raise ClaimabilityProofBindingRuntimeError(token, "required prefixed SHA-256 digest")
    prefix, digest = text.split(":", maxsplit=1)
    if prefix not in prefixes:
        raise ClaimabilityProofBindingRuntimeError(token, "unexpected digest prefix")
    _require_bare_sha256(digest, token=token)
    return text


def _require_sha256_or_prefixed_sha256(value: object, *, prefix: str, token: str) -> str:
    text = _require_text(value, token=token)
    if ":" not in text:
        _require_bare_sha256(text, token=token)
        return text
    actual_prefix, digest = text.split(":", maxsplit=1)
    if actual_prefix != prefix:
        raise ClaimabilityProofBindingRuntimeError(token, "unexpected digest prefix")
    _require_bare_sha256(digest, token=token)
    return text


def _require_bare_sha256(value: object, *, token: str) -> str:
    text = _require_text(value, token=token)
    if len(text) != 64 or any(char not in _HEX for char in text):
        raise ClaimabilityProofBindingRuntimeError(token, "required lowercase full SHA-256 digest")
    return text


def _reject_float_tree(
    value: Any,
    *,
    _depth: int = 0,
    _seen: set[int] | None = None,
    _counter: list[int] | None = None,
) -> None:
    if _depth > _MAX_CANONICAL_PAYLOAD_DEPTH:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_payload_too_deep",
            "claimability proof-binding payload exceeds maximum traversal depth",
        )
    if _seen is None:
        _seen = set()
    if _counter is None:
        _counter = [0]
    _counter[0] += 1
    if _counter[0] > _MAX_CANONICAL_PAYLOAD_NODES:
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_payload_too_large",
            "claimability proof-binding payload exceeds maximum traversal size",
        )
    if isinstance(value, float):
        raise ClaimabilityProofBindingRuntimeError(
            "claimability_float_forbidden",
            "float is forbidden in claimability proof-binding payloads",
        )
    if isinstance(value, dict):
        object_id = id(value)
        if object_id in _seen:
            raise ClaimabilityProofBindingRuntimeError(
                "claimability_payload_cycle_forbidden",
                "claimability proof-binding payload must not contain cycles",
            )
        _seen.add(object_id)
        try:
            for key, item in value.items():
                if not isinstance(key, str):
                    raise ClaimabilityProofBindingRuntimeError(
                        "claimability_payload_key_invalid",
                        "claimability proof-binding payload keys must be strings",
                    )
                _reject_float_tree(
                    item,
                    _depth=_depth + 1,
                    _seen=_seen,
                    _counter=_counter,
                )
        finally:
            _seen.remove(object_id)
        return
    if isinstance(value, (list, tuple)):
        object_id = id(value)
        if object_id in _seen:
            raise ClaimabilityProofBindingRuntimeError(
                "claimability_payload_cycle_forbidden",
                "claimability proof-binding payload must not contain cycles",
            )
        _seen.add(object_id)
        try:
            for item in value:
                _reject_float_tree(
                    item,
                    _depth=_depth + 1,
                    _seen=_seen,
                    _counter=_counter,
                )
        finally:
            _seen.remove(object_id)


def _sha256_payload(payload: Any) -> str:
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def _decimal_to_canonical_string(value: Decimal) -> str:
    if value == Decimal("0"):
        return "0"
    rendered = format(value, "f")
    if "." in rendered:
        rendered = rendered.rstrip("0").rstrip(".")
    return rendered


def _tokens() -> list[str]:
    return [
        CLAIMABILITY_PROOF_BINDING_RUNTIME_VERSION,
        SETTLED_ROOT_WALLET_ROOT_RECEIPT_BINDING_TOKEN,
        NON_LOOPBACK_CLAIMABILITY_API_BLOCKED_TOKEN,
        PUBLIC_CLAIMABILITY_NOT_ACTIVATED_TOKEN,
    ]


__all__ = [
    "CLAIMABILITY_PROOF_BINDING_RUNTIME_VERSION",
    "CLAIMABILITY_PROOF_REF_PREFIX",
    "NON_LOOPBACK_CLAIMABILITY_API_BLOCKED_TOKEN",
    "PUBLIC_CLAIMABILITY_NOT_ACTIVATED_TOKEN",
    "SETTLED_ROOT_WALLET_ROOT_RECEIPT_BINDING_TOKEN",
    "ClaimabilityProofBinding",
    "ClaimabilityProofBindingRuntimeError",
    "build_claimability_proof_binding",
    "canonical_claimability_proof_json",
    "canonical_json",
    "claimability_proof_payload",
    "claimability_proof_ref",
    "latest_balance_receipt_ref",
]
