# PUBLIC_RC_EXCLUDE: internal_source_allowlist_rehearsal_tool_not_public_rc_launch_surface
# PUBLIC_RC_EXCLUDE_REASON: Phase 1319 dry-run packaging scanner; never part of the public RC export.
"""Deterministic source allowlist export rehearsal for Phase 1319.

This module creates rehearsal evidence only. It does not copy files into a
public tree, publish source, produce release artifacts, remove markers, strip
helpers, generate keys, or authorize a public RC.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import re as _re
import tempfile
from collections import defaultdict, deque
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path, PurePosixPath
from typing import Any

from cryptography.hazmat.primitives.asymmetric import ed25519

from ilc_core.bundle.bundle_verifier import verify_adr_0009_bundle
from ilc_core.rc.public_rc_exclude_disposition import (
    build_public_rc_exclude_disposition_inventory,
)


SOURCE_ALLOWLIST_EXPORT_REHEARSAL_VERSION = (
    "deterministic_source_allowlist_export_rehearsal_phase_1319.v0.1"
)
PUBLIC_RC_EXCLUDE_MARKER_SCAN_ZERO_TOKEN = (
    "public_rc_exclude_marker_scan_zero_exported_markers_phase_1319"
)
STRIPPED_HELPER_IMPORT_SCAN_ZERO_TOKEN = "stripped_helper_import_scan_zero_phase_1319"
LEGACY_UNTAGGED_REVIEW_RESULTS_TOKEN = (
    "legacy_untagged_review_results_recorded_phase_1319"
)
SOURCE_EXPORT_REHEARSAL_NO_PUBLICATION_TOKEN = (
    "source_export_rehearsal_no_publication_phase_1319"
)
PHASE_1320_NEXT_TOKEN = "phase_1320_release_artifact_manifest_instance_rehearsal_next"
PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1319_TOKEN = (
    "public_rc_remains_blocked_after_phase_1319"
)
ADR_0009_SOURCE_EXPORT_REHEARSAL_PROFILE_INTEGRATION_TOKEN = (
    "adr_0009_source_export_rehearsal_profile_integration_phase_1519p"
)
ADR_0009_PUBLIC_EXPORT_NOT_EXECUTED_TOKEN = (
    "adr_0009_public_export_not_executed_phase_1519p"
)
ADR_0009_BUNDLE_CHAIN_VERIFIED_FIELD = "adr_0009_bundle_chain_verified"

PUBLIC_RC_EXCLUDE_MARKER = "PUBLIC_RC_EXCLUDE"

# Header-anchored pattern for detection.  A file carries the exclusion marker
# only when PUBLIC_RC_EXCLUDE appears as a comment header in its first 8 lines:
# Files that reference or document the marker as prose (CLAUDE.md, AGENTS.md,
# scanner modules, test files) do NOT match and are not excluded.
# The 8-line bound is empirical and intentionally conservative for the
# current repo: public-release exclusion declarations belong in the opening
# comment header, not in explanatory prose later in the file.
_PUBLIC_RC_EXCLUDE_HEADER_PATTERN = _re.compile(
    rb"^\s*(?:(?:#|//)\s*PUBLIC_RC_EXCLUDE(?::|\b)|<!--\s*PUBLIC_RC_EXCLUDE(?::|\b))",
    _re.MULTILINE,
)
_HEADER_LINES = 8
MAX_DEPENDENCY_SCAN_FILE_BYTES = 2 * 1024 * 1024
DEPENDENCY_SCAN_TEXT_SUFFIXES = {".md", ".json", ".rst", ".sh", ".toml", ".txt", ".yaml", ".yml"}

DEFAULT_FORCE_INCLUDE_PATHS = (
    # methodology.md pre-dates the header-anchored pattern fix and its
    # content references the marker as prose.  It is force-included here as a
    # belt-and-suspenders safety net; the header-anchored pattern would not
    # exclude it anyway since it has no header marker.
    "methodology.md",
    # Reviewed public docs under otherwise default-excluded docs/.
    "docs/GETTING_STARTED.md",
    "docs/HUMAN.md",
    "docs/OPERATOR_GUIDE.md",
    "docs/architecture/ilc_canonical_glossary_and_concepts_v0.2.md",
    "docs/user/action_signing_keys.md",
    # Reviewed public helper tools under otherwise default-excluded tools/.
    "tools/demo_walkthrough.py",
    "tools/genesis_boot.py",
    "tools/public_release_prepare_update.py",
    "tools/rc_install_bundle_node.py",
    "tools/rc_update_bundle_node.py",
)

DEFAULT_INCLUDE_ROOTS = (
    # Root-level human-facing documents
    "CODE_OF_CONDUCT.md",
    "CONTRIBUTING.md",
    "FUNDING.md",
    "Glossary.md",
    "HUMANS.md",
    "LICENSE",
    "LICENSING.md",
    "MANIFESTO.md",
    "MANIFEST.in",
    "PATENTS.md",
    "QUICKSTART.md",
    "README.md",
    "SECURITY.md",
    "THIRD_PARTY_NOTICES.md",
    "WHITEPAPER.md",
    "conftest.py",
    "economics.md",
    "metaphysics.md",
    "methodology.md",
    "pyproject.toml",
    "requirements.txt",
    "run_node.py",
    "sidecars.md",
    # Public docs are force-included individually; broad docs/ remains default-excluded.
    "docs",
    # Public-facing assets (images, etc.)
    "assets",
    # Public sidecar repos
    "ilc-ccss-sidecar",
    "ilc-graphics-sidecar",
    "ilc-timecapsule-sidecar",
    "ilc-wallet-sidecar",
    # OpenClaw skill
    "skills",
    # Genesis config (testnet sub-dirs excluded below)
    "config/genesis.json",
    "config/README.md",
    # Rust consensus layer
    "ilc_consensus/Cargo.toml",
    "ilc_consensus/build.rs",
    "ilc_consensus/src",
    # Python core
    "ilc_core",
    # Public tools are force-included individually; broad tools/ remains default-excluded.
    "tools",
)

DEFAULT_EXCLUDED_ROOTS = (
    ("docs", "docs_tree_default_excluded_pending_public_manifest_review"),
    # Phase prompt and walkthrough history — private development artifacts
    ("docs/antigravity_tasks", "private_phase_prompt_history_default_excluded"),
    ("docs/phases", "private_phase_walkthrough_history_default_excluded"),
    # Research, patent-sensitive, and internal planning material
    ("docs/research", "research_and_patent_sensitive_material_default_excluded"),
    # Generated output, MemPalace, monitoring snapshots
    ("out", "generated_mempalace_and_local_output_default_excluded"),
    ("monitoring", "local_monitoring_output_default_excluded"),
    ("local_monitoring", "local_monitoring_output_default_excluded"),
    # Raw session transcripts
    ("Z_Past_Chats", "raw_chat_corpus_default_excluded"),
    # Rust build artifacts
    ("ilc_consensus/target", "generated_rust_build_output_default_excluded"),
    # Private test suite (kept in main repo only)
    ("tests", "private_phase_regression_tests_default_excluded"),
    # Internal development and ops artifacts
    ("TODO Docs Post MVP", "internal_todo_doc_default_excluded"),
    ("automation", "internal_ci_ops_tooling_default_excluded"),
    ("deploy", "internal_deployment_scripts_default_excluded"),
    ("protocol", "stale_mvp_protocol_json_default_excluded"),
    ("simulations", "economic_simulation_scripts_default_excluded"),
    ("testbed", "private_dev_testbed_infrastructure_default_excluded"),
    ("whitepaper", "stale_early_phase_whitepaper_default_excluded"),
    # Sidecar repositories with private/local or pre-CDL public posture.
    ("ilc-ccss-sidecar", "ccss_sidecar_private_local_default_excluded"),
    ("ilc-timecapsule-sidecar", "timecapsule_sidecar_pre_cdl_default_excluded"),
    # Private testnet validator configs inside config/
    ("config/mysticeti_testnet_M009", "private_testnet_validator_config_excluded"),
    ("config/mysticeti_testnet_multiop_1360", "private_testnet_validator_config_excluded"),
    # Internal tool subdirectories
    ("tools/testbed", "private_testbed_operator_scripts_excluded"),
    ("tools", "tools_tree_default_excluded_pending_public_manifest_review"),
    # Build artifacts
    ("build", "python_build_dist_artifacts_default_excluded"),
    ("ilc_core.egg-info", "python_egg_info_build_artifact_default_excluded"),
    # Other internal directories
    ("graphify-out", "internal_graph_output_default_excluded"),
    ("lib", "internal_lib_artifacts_default_excluded"),
    ("output", "internal_output_artifacts_default_excluded"),
    ("scripts", "internal_scripts_default_excluded"),
    ("states", "internal_state_snapshots_default_excluded"),
)

_EXCLUDED_PATH_PARTS = frozenset(
    {
        ".git",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        ".venv",
        "__pycache__",
        "node_modules",
    }
)
_EXCLUDED_SUFFIXES = frozenset({".pyc", ".pyo", ".so", ".dylib", ".dll"})
_LEGACY_REVIEW_EXTENSIONS = frozenset({".md", ".rst", ".txt"})
_REVIEW_REQUIRED_TERMS = (
    "private",
    "not public",
    "do not publish",
    "patent",
    "patent pending",
    "counsel",
    "publication",
    "public rc",
    "release artifact",
    "release key",
    "release envelope",
    "signing",
    "launch",
    "claim",
    "internal",
)
_DEFAULT_REVIEWED_METADATA_PATHS = frozenset(
    {
        "CODE_OF_CONDUCT.md",
        "CONTRIBUTING.md",
        "FUNDING.md",
        "Glossary.md",
        "HUMANS.md",
        "LICENSE",
        "LICENSING.md",
        "PATENTS.md",
        "QUICKSTART.md",
        "README.md",
        "SECURITY.md",
        "THIRD_PARTY_NOTICES.md",
        "WHITEPAPER.md",
        "docs/GETTING_STARTED.md",
        "docs/HUMAN.md",
        "docs/OPERATOR_GUIDE.md",
        "docs/architecture/ilc_canonical_glossary_and_concepts_v0.2.md",
        "docs/user/action_signing_keys.md",
        "economics.md",
        "ilc-wallet-sidecar/README.md",
        "ilc_consensus/Cargo.toml",
        "ilc_consensus/build.rs",
        "metaphysics.md",
        "methodology.md",
        "pyproject.toml",
        "sidecars.md",
        "skills/ilc-openclaw-local-capture/SKILL.md",
        "skills/ilc-openclaw-local-capture/skill-card.md",
        "skills/ilc/SKILL.md",
        "skills/ilc/skill-card.md",
    }
)
_SOURCE_SUFFIXES = frozenset(
    {
        ".py",
        ".rs",
        ".toml",
        ".lock",
        ".md",
        ".txt",
        ".yaml",
        ".yml",
        ".json",
    }
)


def phase_1319_required_tokens() -> list[str]:
    return [
        SOURCE_ALLOWLIST_EXPORT_REHEARSAL_VERSION,
        PUBLIC_RC_EXCLUDE_MARKER_SCAN_ZERO_TOKEN,
        STRIPPED_HELPER_IMPORT_SCAN_ZERO_TOKEN,
        LEGACY_UNTAGGED_REVIEW_RESULTS_TOKEN,
        SOURCE_EXPORT_REHEARSAL_NO_PUBLICATION_TOKEN,
        PHASE_1320_NEXT_TOKEN,
        PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1319_TOKEN,
    ]


def _prepare_source_rehearsal_inputs(
    repo_root: Path | str,
    include_roots: Sequence[str],
    excluded_roots: Sequence[tuple[str, str]],
    force_include_paths: Iterable[str],
    reviewed_legacy_paths: Iterable[str],
) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError("phase_1319_repo_root_invalid")
    normalized_excluded_roots = [
        {
            "count": _count_existing_files(root, selector),
            "reason": reason,
            "root": selector,
        }
        for selector, reason in (
            (_normalize_relative_path(path, field="excluded_root"), reason)
            for path, reason in excluded_roots
        )
    ]
    return {
        "force_included": {
            _normalize_relative_path(value, field="force_include_path")
            for value in force_include_paths
        },
        "normalized_excluded_roots": normalized_excluded_roots,
        "normalized_include_roots": [
            _normalize_relative_path(value, field="include_root") for value in include_roots
        ],
        "reviewed_legacy": {
            _normalize_relative_path(value, field="reviewed_legacy_path")
            for value in reviewed_legacy_paths
        }
        | _DEFAULT_REVIEWED_METADATA_PATHS,
        "root": root,
    }


def _collect_source_rehearsal_candidates(
    root: Path,
    normalized_include_roots: Sequence[str],
) -> tuple[list[dict[str, Any]], set[str]]:
    candidate_roots = []
    candidate_paths: set[str] = set()
    for rel_root in normalized_include_roots:
        abs_root = _resolve_under_root(root, rel_root)
        if not abs_root.exists():
            raise ValueError("phase_1319_include_root_missing")
        candidate_roots.append(
            {
                "allowlist_reason": _include_reason(rel_root),
                "exists": True,
                "root": rel_root,
            }
        )
        candidate_paths.update(_iter_files(root, rel_root))
    return candidate_roots, candidate_paths


def _record_source_rehearsal_exclusion(
    *,
    excluded_files: list[dict[str, Any]],
    legacy_default_excluded: list[dict[str, str]],
    legacy_blocked: list[dict[str, str]],
    blocked_ambiguities: list[dict[str, str]],
    record: dict[str, Any],
    default_reason: str | None = None,
    blocked_reason: str | None = None,
) -> None:
    excluded_files.append(record)
    if record["review_required_before_public_export"] and blocked_reason is None:
        legacy_default_excluded.append(
            {"path": record["path"], "reason": default_reason or record["exclusion_rule"]}
        )
    if record["blocked"]:
        reason = blocked_reason or record["exclusion_rule"]
        legacy_blocked.append({"path": record["path"], "reason": reason})
        blocked_ambiguities.append({"path": record["path"], "reason": reason})


def _classify_source_rehearsal_candidates(
    *,
    root: Path,
    candidate_paths: set[str],
    force_included: set[str],
    normalized_excluded_roots: list[dict[str, Any]],
    reviewed_legacy: set[str],
    stripped_helpers: list[dict[str, str]],
) -> dict[str, Any]:
    included_files: list[dict[str, Any]] = []
    excluded_files: list[dict[str, Any]] = []
    legacy_included: list[dict[str, str]] = []
    legacy_default_excluded: list[dict[str, str]] = []
    legacy_blocked: list[dict[str, str]] = []
    blocked_ambiguities: list[dict[str, str]] = []

    for rel_path in sorted(candidate_paths | force_included):
        abs_path = _absolute_under_root_no_follow(root, rel_path)
        forced = rel_path in force_included
        exclusion = _candidate_exclusion(root, rel_path, abs_path, normalized_excluded_roots)
        if exclusion is not None and (not forced or exclusion["blocked"]):
            _record_source_rehearsal_exclusion(
                excluded_files=excluded_files,
                legacy_default_excluded=legacy_default_excluded,
                legacy_blocked=legacy_blocked,
                blocked_ambiguities=blocked_ambiguities,
                record=exclusion,
            )
            continue

        if not abs_path.is_file():
            continue
        payload = abs_path.read_bytes()
        header_bytes = b"\n".join(payload.split(b"\n")[:_HEADER_LINES])
        marker_hit = bool(_PUBLIC_RC_EXCLUDE_HEADER_PATTERN.search(header_bytes))
        if marker_hit and not forced:
            _record_source_rehearsal_exclusion(
                excluded_files=excluded_files,
                legacy_default_excluded=legacy_default_excluded,
                legacy_blocked=legacy_blocked,
                blocked_ambiguities=blocked_ambiguities,
                record={
                    "blocked": False,
                    "exclusion_rule": "public_rc_exclude_marker_default_excluded",
                    "marker_status": "hit",
                    "path": rel_path,
                    "review_required_before_public_export": True,
                },
                default_reason="public_rc_exclude_marker_default_excluded",
            )
            continue

        legacy_status = _legacy_review_status(rel_path, payload, reviewed_legacy)
        if legacy_status["status"] == "review_required_blocked" and not forced:
            _record_source_rehearsal_exclusion(
                excluded_files=excluded_files,
                legacy_default_excluded=legacy_default_excluded,
                legacy_blocked=legacy_blocked,
                blocked_ambiguities=blocked_ambiguities,
                record={
                    "blocked": True,
                    "exclusion_rule": "legacy_untagged_review_required_blocked",
                    "marker_status": "hit" if marker_hit else "absent",
                    "path": rel_path,
                    "review_required_before_public_export": True,
                },
                blocked_reason=legacy_status["reason"],
            )
            continue

        included_files.append(
            {
                "allowlist_reason": _include_reason(rel_path),
                "byte_size": len(payload),
                "hash_sha256": hashlib.sha256(payload).hexdigest(),
                "marker_status": (
                    "hit_force_included"
                    if (marker_hit and forced)
                    else ("hit" if marker_hit else "absent")
                ),
                "path": rel_path,
                "scanner_status": "included_for_rehearsal_scan",
            }
        )
        if legacy_status["status"] == "included_reviewed":
            legacy_included.append({"path": rel_path, "reason": legacy_status["reason"]})

    return {
        "blocked_ambiguities": blocked_ambiguities,
        "excluded_files": excluded_files,
        "included_files": included_files,
        "legacy_blocked": legacy_blocked,
        "legacy_default_excluded": legacy_default_excluded,
        "legacy_included": legacy_included,
        "stripped_helpers": stripped_helpers,
    }


def _source_rehearsal_counts(
    scan: Mapping[str, Any],
    marker_scan: Mapping[str, Any],
    dependency_scan: Mapping[str, Any],
) -> dict[str, int]:
    return {
        "blocked_ambiguities": len(scan["blocked_ambiguities"]),
        "dependency_hits": dependency_scan["stripped_helper_hit_count"],
        "excluded_files": len(scan["excluded_files"]),
        "included_files": len(scan["included_files"]),
        "legacy_untagged_default_excluded": len(scan["legacy_default_excluded"]),
        "legacy_untagged_included_reviewed": len(scan["legacy_included"]),
        "legacy_untagged_review_required_blocked": len(scan["legacy_blocked"]),
        "marker_hits": marker_scan["hit_count"],
    }


def build_source_allowlist_export_rehearsal(
    *,
    repo_root: Path | str = Path("."),
    include_roots: Sequence[str] = DEFAULT_INCLUDE_ROOTS,
    excluded_roots: Sequence[tuple[str, str]] = DEFAULT_EXCLUDED_ROOTS,
    force_include_paths: Iterable[str] = DEFAULT_FORCE_INCLUDE_PATHS,
    reviewed_legacy_paths: Iterable[str] = (),
    required_included_paths: Iterable[str] = (),
) -> dict[str, Any]:
    prepared = _prepare_source_rehearsal_inputs(
        repo_root,
        include_roots,
        excluded_roots,
        force_include_paths,
        reviewed_legacy_paths,
    )
    root = prepared["root"]
    candidate_roots, candidate_paths = _collect_source_rehearsal_candidates(
        root,
        prepared["normalized_include_roots"],
    )
    helper_inventory = build_public_rc_exclude_disposition_inventory()
    stripped_helpers = _stripped_helper_records(helper_inventory)
    scan = _classify_source_rehearsal_candidates(
        root=root,
        candidate_paths=candidate_paths,
        force_included=prepared["force_included"],
        normalized_excluded_roots=prepared["normalized_excluded_roots"],
        reviewed_legacy=prepared["reviewed_legacy"],
        stripped_helpers=stripped_helpers,
    )
    marker_scan = _marker_scan(scan["included_files"])
    dependency_scan = _dependency_scan(root, scan["included_files"], stripped_helpers)
    required_inclusion = _required_inclusion_scan(
        scan["included_files"],
        scan["excluded_files"],
        required_included_paths,
    )
    negative_matrix = _negative_case_matrix(
        marker_scan,
        dependency_scan,
        scan["blocked_ambiguities"],
    )
    counts = _source_rehearsal_counts(scan, marker_scan, dependency_scan)
    pass_condition = (
        marker_scan["result"] == "pass"
        and dependency_scan["result"] == "pass"
        and counts["blocked_ambiguities"] == 0
    )

    manifest: dict[str, Any] = {
        "blocked_ambiguities": scan["blocked_ambiguities"],
        "candidate_roots": candidate_roots,
        "counts": counts,
        "dependency_scan": dependency_scan,
        "excluded_files": scan["excluded_files"],
        "excluded_roots": prepared["normalized_excluded_roots"],
        "included_files": scan["included_files"],
        "legacy_untagged_review": {
            "ambiguity_count": len(scan["blocked_ambiguities"]),
            "default_excluded_files": scan["legacy_default_excluded"],
            "included_reviewed_files": scan["legacy_included"],
            "review_required_blocked_files": scan["legacy_blocked"],
        },
        "marker_scan": marker_scan,
        "mode": "dry_run_rehearsal_only",
        "negative_case_matrix": negative_matrix,
        "non_claims": [
            "no_public_source_export",
            "no_source_publication",
            "no_package_publication",
            "no_clean_public_tree_materialization",
            "no_release_artifact_production",
            "no_release_key_generation",
            "no_release_envelope_production",
            "no_signing",
            "no_helper_promotion",
            "no_marker_removal",
            "no_helper_stripping_execution",
            "no_public_rc_claim",
            "no_public_claimability_activation",
            "no_public_p2p_or_fetch_serving",
            "no_public_confidential_coordination_serving",
            "public_rc_remains_blocked_after_phase_1319",
        ],
        "phase": 1319,
        "public_rc_remains_blocked": True,
        "required_included_paths": required_inclusion,
        "rerun": {
            "command": (
                "./.venv/bin/python -m ilc_core.rc.source_allowlist_export_rehearsal "
                "--json-out docs/specs/ilc_deterministic_source_allowlist_export_rehearsal_1319_v0.1.json"
            ),
            "determinism": "manifest_hash_must_match_expected_manifest_hash_on_unchanged_inputs",
            "expected_manifest_hash": "",
        },
        "required_tokens": phase_1319_required_tokens(),
        "result": "pass" if pass_condition else "fail_closed",
        "scanner_limitations": [
            "python_import_scan_uses_ast_for_static_imports_only",
            "transitive_python_scan_is_limited_to_included_local_modules",
            "non_python_dependency_scan_uses_exact_path_and_module_text_patterns",
            "dynamic_imports_and_runtime_generated_dependency_edges_remain_out_of_scope",
        ],
        "schema_version": SOURCE_ALLOWLIST_EXPORT_REHEARSAL_VERSION,
        "source_revision_policy": "phase_1319_rehearsal_uses_current_worktree_content_without_publication_authority",
        "stripped_helpers": stripped_helpers,
    }
    manifest["rerun"]["expected_manifest_hash"] = _manifest_hash_without_self_reference(manifest)
    return _validate_manifest(manifest)


def build_adr_0009_source_export_rehearsal_profile(
    *,
    adr_0009_bundle: Mapping[str, Any],
    adr_0009_public_keys_by_layer: Mapping[int, ed25519.Ed25519PublicKey],
    repo_root: Path | str = Path("."),
    include_roots: Sequence[str] = DEFAULT_INCLUDE_ROOTS,
    excluded_roots: Sequence[tuple[str, str]] = DEFAULT_EXCLUDED_ROOTS,
    force_include_paths: Iterable[str] = DEFAULT_FORCE_INCLUDE_PATHS,
    reviewed_legacy_paths: Iterable[str] = (),
) -> dict[str, Any]:
    """Build a dry-run source rehearsal profile gated by ADR-0009 verification.

    This is still a rehearsal-only manifest. It does not materialize a public
    tree, clear ADR-0009 guards, or authorize publication.
    """
    if not isinstance(adr_0009_bundle, Mapping):
        raise ValueError("phase_1519_adr_0009_bundle_required")
    if not isinstance(adr_0009_public_keys_by_layer, Mapping):
        raise ValueError("phase_1519_adr_0009_public_keys_required")

    try:
        verified_bundle = verify_adr_0009_bundle(
            adr_0009_bundle,
            public_keys_by_layer=adr_0009_public_keys_by_layer,
        )
    except ValueError as exc:
        raise ValueError("phase_1519_adr_0009_bundle_verification_failed") from exc

    base_manifest = build_source_allowlist_export_rehearsal(
        repo_root=repo_root,
        include_roots=include_roots,
        excluded_roots=excluded_roots,
        force_include_paths=force_include_paths,
        reviewed_legacy_paths=reviewed_legacy_paths,
    )
    manifest = json.loads(canonical_source_allowlist_export_rehearsal_json(base_manifest))
    manifest[ADR_0009_BUNDLE_CHAIN_VERIFIED_FIELD] = True
    manifest["adr_0009_bundle_verification"] = {
        "field": ADR_0009_BUNDLE_CHAIN_VERIFIED_FIELD,
        "layer_cidv1_chain": [
            {"cidv1": layer.cidv1, "layer": layer.layer}
            for layer in verified_bundle.layers
        ],
        "profile": "phase_1519_source_export_rehearsal_profile",
        "result": "pass",
        "verifier": "ilc_core.bundle.bundle_verifier.verify_adr_0009_bundle",
    }
    manifest["phase_1519_tokens"] = [
        ADR_0009_SOURCE_EXPORT_REHEARSAL_PROFILE_INTEGRATION_TOKEN,
        ADR_0009_PUBLIC_EXPORT_NOT_EXECUTED_TOKEN,
    ]
    manifest["non_claims"] = [
        *manifest["non_claims"],
        "no_adr_0009_public_distribution_authorization",
        "no_adr_0009_guard_clearance",
        ADR_0009_PUBLIC_EXPORT_NOT_EXECUTED_TOKEN,
    ]
    manifest["rerun"]["expected_manifest_hash"] = _manifest_hash_without_self_reference(manifest)
    return _validate_manifest(manifest)


def canonical_source_allowlist_export_rehearsal_json(manifest: Mapping[str, Any]) -> str:
    return json.dumps(manifest, allow_nan=False, separators=(",", ":"), sort_keys=True)


def pretty_source_allowlist_export_rehearsal_json(manifest: Mapping[str, Any]) -> str:
    return json.dumps(manifest, allow_nan=False, indent=2, sort_keys=True) + "\n"


def manifest_hash(manifest: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        canonical_source_allowlist_export_rehearsal_json(manifest).encode("utf-8")
    ).hexdigest()


def render_rehearsal_markdown(manifest: Mapping[str, Any]) -> str:
    counts = manifest["counts"]
    return "\n".join(
        [
            "# ILC Deterministic Source Allowlist Export Rehearsal 1319 v0.1",
            "",
            "**Status:** DRY-RUN REHEARSAL ONLY, NO PUBLICATION.",
            "**Phase:** 1319.",
            "",
            "```text",
            *phase_1319_required_tokens(),
            "```",
            "",
            "## Verdict",
            "",
            f"- Result: `{manifest['result']}`.",
            f"- Included files: `{counts['included_files']}`.",
            f"- Excluded files: `{counts['excluded_files']}`.",
            f"- Exported marker hits: `{counts['marker_hits']}`.",
            f"- Stripped-helper dependency hits: `{counts['dependency_hits']}`.",
            f"- Blocked ambiguities: `{counts['blocked_ambiguities']}`.",
            f"- Expected manifest hash: `{manifest['rerun']['expected_manifest_hash']}`.",
            "",
            "## Scanner Scope",
            "",
            "The rehearsal scans a deterministic source/package candidate set and does not copy files into a public export tree.",
            "Marker scanning is performed on included file bytes after candidate selection.",
            "Dependency scanning uses Python AST static imports for Python files and exact path/module text patterns for non-Python files.",
            "Dynamic imports and runtime-generated dependency edges remain out of scope and are recorded as scanner limitations.",
            "",
            "## Non-Claims",
            "",
            "This rehearsal is not public source export, not source publication, not package publication, not release artifact production, not release signing, and not a public RC claim.",
            "Public RC remains blocked after Phase 1319.",
            "",
        ]
    )


def write_rehearsal_outputs(
    *,
    json_out: Path | None,
    markdown_out: Path | None,
    manifest: Mapping[str, Any],
) -> None:
    if json_out is not None:
        _write_text_atomic(json_out, pretty_source_allowlist_export_rehearsal_json(manifest))
    if markdown_out is not None:
        _write_text_atomic(markdown_out, render_rehearsal_markdown(manifest))


def _validate_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    if manifest.get("schema_version") != SOURCE_ALLOWLIST_EXPORT_REHEARSAL_VERSION:
        raise ValueError("phase_1319_manifest_schema_invalid")
    if manifest.get("required_tokens") != phase_1319_required_tokens():
        raise ValueError("phase_1319_required_tokens_invalid")
    if manifest.get("mode") != "dry_run_rehearsal_only":
        raise ValueError("phase_1319_mode_must_be_dry_run")
    if manifest.get("public_rc_remains_blocked") is not True:
        raise ValueError("phase_1319_public_rc_blocked_flag_required")
    if manifest["marker_scan"]["hit_count"] != manifest["counts"]["marker_hits"]:
        raise ValueError("phase_1319_marker_count_mismatch")
    if (
        manifest["dependency_scan"]["stripped_helper_hit_count"]
        != manifest["counts"]["dependency_hits"]
    ):
        raise ValueError("phase_1319_dependency_count_mismatch")
    if manifest["rerun"]["expected_manifest_hash"] != _manifest_hash_without_self_reference(
        manifest
    ):
        raise ValueError("phase_1319_expected_manifest_hash_mismatch")
    canonical_source_allowlist_export_rehearsal_json(manifest)
    return manifest


def _normalize_relative_path(raw: str, *, field: str) -> str:
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError(f"phase_1319_{field}_invalid")
    if "\\" in raw or raw.startswith("/") or raw.startswith("~"):
        raise ValueError(f"phase_1319_{field}_not_repo_relative")
    path = PurePosixPath(raw)
    if path.is_absolute() or str(path) in {"", "."}:
        raise ValueError(f"phase_1319_{field}_not_repo_relative")
    if any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"phase_1319_{field}_traversal_rejected")
    return path.as_posix()


def _resolve_under_root(repo_root: Path, rel_path: str) -> Path:
    candidate = (repo_root / Path(*PurePosixPath(rel_path).parts)).resolve(strict=False)
    if candidate != repo_root and repo_root not in candidate.parents:
        raise ValueError("phase_1319_path_escape_rejected")
    return candidate


def _absolute_under_root_no_follow(repo_root: Path, rel_path: str) -> Path:
    candidate = repo_root / Path(*PurePosixPath(rel_path).parts)
    parent = candidate.parent.resolve(strict=False)
    if parent != repo_root and repo_root not in parent.parents:
        raise ValueError("phase_1319_path_escape_rejected")
    return candidate


def _count_existing_files(repo_root: Path, rel_root: str) -> int:
    root = _resolve_under_root(repo_root, rel_root)
    if not root.exists():
        return 0
    if root.is_file():
        rel = root.relative_to(repo_root).as_posix()
        return 0 if _is_generated_or_cache_path(rel) else 1
    return sum(
        1
        for path in root.rglob("*")
        if (path.is_file() or path.is_symlink())
        and not _is_generated_or_cache_path(path.relative_to(repo_root).as_posix())
    )


def _iter_files(repo_root: Path, rel_root: str) -> set[str]:
    root = _resolve_under_root(repo_root, rel_root)
    if root.is_file() or root.is_symlink():
        return set() if _is_generated_or_cache_path(rel_root) else {rel_root}
    files = set()
    for path in root.rglob("*"):
        if path.is_file() or path.is_symlink():
            rel = path.relative_to(repo_root).as_posix()
            _normalize_relative_path(rel, field="candidate_path")
            if _is_generated_or_cache_path(rel):
                continue
            files.add(rel)
    return files


def _is_generated_or_cache_path(rel_path: str) -> bool:
    path = PurePosixPath(rel_path)
    return (
        any(part in _EXCLUDED_PATH_PARTS for part in path.parts)
        or path.suffix in _EXCLUDED_SUFFIXES
    )


def _candidate_exclusion(
    repo_root: Path,
    rel_path: str,
    abs_path: Path,
    excluded_roots: Sequence[Mapping[str, Any]],
) -> dict[str, Any] | None:
    for root in excluded_roots:
        selector = root["root"]
        if rel_path == selector or rel_path.startswith(f"{selector}/"):
            return _excluded_record(
                rel_path,
                reason=root["reason"],
                marker_status="not_scanned_default_root_excluded",
                review_required=True,
            )
    if any(part in _EXCLUDED_PATH_PARTS for part in PurePosixPath(rel_path).parts):
        return _excluded_record(
            rel_path,
            reason="generated_or_local_cache_path_default_excluded",
            marker_status="not_scanned_generated_path_excluded",
            blocked=True,
            review_required=True,
        )
    if PurePosixPath(rel_path).suffix in _EXCLUDED_SUFFIXES:
        return _excluded_record(
            rel_path,
            reason="generated_binary_or_bytecode_default_excluded",
            marker_status="not_scanned_generated_path_excluded",
            blocked=True,
            review_required=True,
        )
    if abs_path.is_symlink():
        try:
            target = abs_path.resolve(strict=True)
        except FileNotFoundError:
            target = abs_path.resolve(strict=False)
        reason = (
            "symlink_escape_rejected"
            if target != repo_root and repo_root not in target.parents
            else "symlink_rejected"
        )
        return _excluded_record(
            rel_path,
            reason=reason,
            marker_status="not_scanned_symlink_rejected",
            blocked=True,
            review_required=True,
        )
    return None


def _excluded_record(
    path: str,
    *,
    reason: str,
    marker_status: str,
    blocked: bool = False,
    review_required: bool = False,
) -> dict[str, Any]:
    return {
        "blocked": blocked,
        "exclusion_rule": reason,
        "marker_status": marker_status,
        "path": path,
        "review_required_before_public_export": review_required,
    }


def _legacy_review_status(
    rel_path: str,
    payload: bytes,
    reviewed_legacy_paths: set[str],
) -> dict[str, str]:
    suffix = PurePosixPath(rel_path).suffix
    if rel_path in reviewed_legacy_paths:
        return {"reason": "explicitly_reviewed_metadata_phase_1319", "status": "included_reviewed"}
    if rel_path.startswith("ilc_core/") or rel_path.startswith("ilc_consensus/"):
        return {"reason": "source_code_allowlist_reviewed_phase_1319", "status": "included_reviewed"}
    if suffix not in _LEGACY_REVIEW_EXTENSIONS:
        return {"reason": "non_legacy_source_file", "status": "not_legacy"}
    lowered = payload[:65536].decode("utf-8", errors="ignore").lower()
    if any(term in lowered for term in _REVIEW_REQUIRED_TERMS):
        return {
            "reason": "legacy_untagged_review_required_terms_detected",
            "status": "review_required_blocked",
        }
    return {"reason": "legacy_untagged_without_required_terms", "status": "included_reviewed"}


def _marker_scan(included_files: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    hits = [
        {"marker": PUBLIC_RC_EXCLUDE_MARKER, "path": record["path"]}
        for record in included_files
        if str(record["marker_status"]).startswith("hit")
    ]
    return {
        "exact_marker": PUBLIC_RC_EXCLUDE_MARKER,
        "file_count_scanned": len(included_files),
        "hit_count": len(hits),
        "hits": hits,
        "result": "pass" if not hits else "fail",
        "token": PUBLIC_RC_EXCLUDE_MARKER_SCAN_ZERO_TOKEN if not hits else "marker_hits_block_export",
    }


def _required_inclusion_scan(
    included_files: Sequence[Mapping[str, Any]],
    excluded_files: Sequence[Mapping[str, Any]],
    required_included_paths: Iterable[str],
) -> dict[str, Any]:
    required = sorted(
        {
            _normalize_relative_path(path, field="required_included_path")
            for path in required_included_paths
        }
    )
    included_by_path = {record["path"]: record for record in included_files}
    excluded_by_path = {record["path"]: record for record in excluded_files}
    present: list[dict[str, str]] = []
    missing: list[dict[str, str]] = []
    for path in required:
        included = included_by_path.get(path)
        if included is not None and included.get("marker_status") == "absent":
            present.append({"marker_status": "absent", "path": path})
            continue
        excluded = excluded_by_path.get(path)
        reason = "not_included"
        if excluded is not None:
            reason = str(excluded.get("exclusion_rule") or "excluded")
        elif included is not None:
            reason = f"marker_status:{included.get('marker_status')}"
        missing.append({"path": path, "reason": reason})
    return {
        "checked_count": len(required),
        "missing": missing,
        "present": present,
        "result": "pass" if not missing else "fail_closed",
    }


def _dependency_scan(
    repo_root: Path,
    included_files: Sequence[Mapping[str, Any]],
    stripped_helpers: Sequence[Mapping[str, str]],
) -> dict[str, Any]:
    included_paths = [record["path"] for record in included_files]
    included_modules = {
        _python_module_name(path): path
        for path in included_paths
        if path.endswith(".py") and _python_module_name(path) is not None
    }
    stripped_modules = {record["module"] for record in stripped_helpers}
    stripped_patterns = sorted(
        {
            *(record["path"] for record in stripped_helpers),
            *(record["module"] for record in stripped_helpers),
        }
    )
    edge_list: list[dict[str, str]] = []
    direct_hits: list[dict[str, str]] = []
    text_hits: list[dict[str, str]] = []
    graph: dict[str, set[str]] = defaultdict(set)

    for rel_path in included_paths:
        abs_path = _resolve_under_root(repo_root, rel_path)
        if rel_path.endswith(".py"):
            if abs_path.stat().st_size > MAX_DEPENDENCY_SCAN_FILE_BYTES:
                raise ValueError("phase_1319_dependency_scan_file_too_large")
            imports = _python_imports(abs_path)
            source_module = _python_module_name(rel_path)
            for imported in imports:
                edge = {
                    "edge_type": "python_ast_import",
                    "source": rel_path,
                    "target": imported,
                }
                edge_list.append(edge)
                if source_module is not None:
                    graph[source_module].add(imported)
                if _matches_stripped_module(imported, stripped_modules):
                    direct_hits.append(edge)
        else:
            if PurePosixPath(rel_path).suffix not in DEPENDENCY_SCAN_TEXT_SUFFIXES:
                continue
            if abs_path.stat().st_size > MAX_DEPENDENCY_SCAN_FILE_BYTES:
                raise ValueError("phase_1319_dependency_scan_file_too_large")
            text = abs_path.read_text(encoding="utf-8", errors="ignore")
            for pattern in stripped_patterns:
                if pattern in text:
                    text_hits.append(
                        {
                            "edge_type": "text_dependency_reference",
                            "source": rel_path,
                            "target": pattern,
                        }
                    )

    transitive_hits = _transitive_python_hits(graph, included_modules, stripped_modules)
    hits = sorted(
        [*direct_hits, *text_hits, *transitive_hits],
        key=lambda item: (item["source"], item["target"], item["edge_type"]),
    )
    return {
        "edge_list": sorted(edge_list, key=lambda item: (item["source"], item["target"])),
        "limitations": [
            "python_ast_static_imports_only",
            "transitive_scan_limited_to_included_python_modules",
            "non_python_scan_uses_exact_text_patterns",
            "binary_asset_dependency_scan_skipped_by_suffix",
        ],
        "result": "pass" if not hits else "fail",
        "stripped_helper_hit_count": len(hits),
        "stripped_helper_hits": hits,
        "token": STRIPPED_HELPER_IMPORT_SCAN_ZERO_TOKEN if not hits else "stripped_helper_dependency_hits_block_export",
    }


def _python_imports(path: Path) -> set[str]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except SyntaxError:
        return set()
    imports: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.add(node.module)
    return imports


def _python_module_name(rel_path: str) -> str | None:
    if not rel_path.endswith(".py"):
        return None
    path = PurePosixPath(rel_path)
    without_suffix = path.with_suffix("")
    if without_suffix.name == "__init__":
        without_suffix = without_suffix.parent
    if not without_suffix.parts:
        return None
    return ".".join(without_suffix.parts)


def _matches_stripped_module(imported: str, stripped_modules: set[str]) -> bool:
    return any(imported == module or imported.startswith(f"{module}.") for module in stripped_modules)


def _transitive_python_hits(
    graph: Mapping[str, set[str]],
    included_modules: Mapping[str, str],
    stripped_modules: set[str],
) -> list[dict[str, str]]:
    hits: list[dict[str, str]] = []
    for start_module, start_path in included_modules.items():
        queue: deque[tuple[str, tuple[str, ...]]] = deque(
            (target, (target,)) for target in sorted(graph.get(start_module, set()))
        )
        visited: set[str] = set()
        while queue:
            module, chain = queue.popleft()
            if module in visited:
                continue
            visited.add(module)
            if _matches_stripped_module(module, stripped_modules):
                hits.append(
                    {
                        "edge_type": "python_ast_transitive_import",
                        "source": start_path,
                        "target": " -> ".join(chain),
                    }
                )
                continue
            if module in included_modules:
                queue.extend(
                    (target, (*chain, target)) for target in sorted(graph.get(module, set()))
                )
    return hits


def _stripped_helper_records(inventory: Mapping[str, Any]) -> list[dict[str, str]]:
    records = []
    for helper in inventory["helper_disposition_inventory"]:
        path = helper["path"]
        records.append(
            {
                "disposition": helper["disposition"],
                "helper_id": helper["helper_id"],
                "module": path[:-3].replace("/", ".") if path.endswith(".py") else path,
                "path": path,
                "replacement_boundary": helper["replacement_boundary"],
            }
        )
    return sorted(records, key=lambda record: record["path"])


def _negative_case_matrix(
    marker_scan: Mapping[str, Any],
    dependency_scan: Mapping[str, Any],
    blocked_ambiguities: Sequence[Mapping[str, str]],
) -> list[dict[str, str]]:
    marker_observed = "pass" if marker_scan["hit_count"] == 0 else "fail_closed"
    dependency_observed = (
        "pass" if dependency_scan["stripped_helper_hit_count"] == 0 else "fail_closed"
    )
    ambiguity_observed = "pass" if not blocked_ambiguities else "fail_closed"
    return [
        _matrix_row("direct_PUBLIC_RC_EXCLUDE_marker", "fail_closed", marker_observed, "marker_scan"),
        _matrix_row("direct_python_stripped_helper_import", "fail_closed", dependency_observed, "dependency_scan"),
        _matrix_row("transitive_python_stripped_helper_import", "fail_closed", dependency_observed, "dependency_scan"),
        _matrix_row("metadata_stripped_helper_reference", "fail_closed", dependency_observed, "dependency_scan"),
        _matrix_row("symlink_escape_path", "fail_closed", ambiguity_observed, "excluded_files"),
        _matrix_row("path_traversal_after_normalization", "fail_closed", "enforced_by_path_validator", "path_validator"),
        _matrix_row("raw_chat_monitoring_out_phase_material", "excluded_default", "excluded_default", "excluded_roots"),
        _matrix_row("patent_sensitive_unreviewed_material", "excluded_default", "excluded_default", "excluded_roots"),
        _matrix_row("legacy_untagged_review_required_file", "fail_closed", ambiguity_observed, "legacy_untagged_review"),
        _matrix_row("rerun_manifest_hash_drift", "fail_closed", "not_observed", "rerun.expected_manifest_hash"),
    ]


def _matrix_row(
    case_id: str,
    expected_result: str,
    observed_result: str,
    evidence_path: str,
) -> dict[str, str]:
    return {
        "affected_package_profile": "public_rc_profile_blocked_if_observed",
        "case_id": case_id,
        "evidence_path": evidence_path,
        "expected_result": expected_result,
        "observed_result": observed_result,
    }


def _include_reason(rel_path: str) -> str:
    if rel_path.startswith("ilc_core/"):
        return "python_source_package_profile_candidate_phase_1319"
    if rel_path.startswith("ilc_consensus/"):
        return "rust_consensus_source_package_profile_candidate_phase_1319"
    if rel_path in _DEFAULT_REVIEWED_METADATA_PATHS:
        return "reviewed_package_metadata_candidate_phase_1319"
    return "explicit_allowlist_candidate_phase_1319"


def _manifest_hash_without_self_reference(manifest: Mapping[str, Any]) -> str:
    clone = json.loads(canonical_source_allowlist_export_rehearsal_json(manifest))
    clone["rerun"]["expected_manifest_hash"] = ""
    return manifest_hash(clone)


def _write_text_atomic(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        text=True,
    )
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_path, path)
    except BaseException:
        try:
            tmp_path.unlink()
        except FileNotFoundError:
            pass
        raise


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path("."))
    parser.add_argument("--json-out", type=Path)
    parser.add_argument("--markdown-out", type=Path)
    parser.add_argument(
        "--require-included-path",
        action="append",
        default=[],
        help="Require a normalized relative path to be included and marker-free in the manifest.",
    )
    args = parser.parse_args(argv)

    manifest = build_source_allowlist_export_rehearsal(
        repo_root=args.repo_root,
        required_included_paths=args.require_included_path,
    )
    write_rehearsal_outputs(
        json_out=args.json_out,
        markdown_out=args.markdown_out,
        manifest=manifest,
    )
    if args.json_out is None and args.markdown_out is None:
        print(pretty_source_allowlist_export_rehearsal_json(manifest), end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "ADR_0009_BUNDLE_CHAIN_VERIFIED_FIELD",
    "ADR_0009_PUBLIC_EXPORT_NOT_EXECUTED_TOKEN",
    "ADR_0009_SOURCE_EXPORT_REHEARSAL_PROFILE_INTEGRATION_TOKEN",
    "LEGACY_UNTAGGED_REVIEW_RESULTS_TOKEN",
    "PHASE_1320_NEXT_TOKEN",
    "PUBLIC_RC_EXCLUDE_MARKER_SCAN_ZERO_TOKEN",
    "PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1319_TOKEN",
    "SOURCE_ALLOWLIST_EXPORT_REHEARSAL_VERSION",
    "SOURCE_EXPORT_REHEARSAL_NO_PUBLICATION_TOKEN",
    "STRIPPED_HELPER_IMPORT_SCAN_ZERO_TOKEN",
    "build_adr_0009_source_export_rehearsal_profile",
    "build_source_allowlist_export_rehearsal",
    "canonical_source_allowlist_export_rehearsal_json",
    "manifest_hash",
    "phase_1319_required_tokens",
    "pretty_source_allowlist_export_rehearsal_json",
    "render_rehearsal_markdown",
    "write_rehearsal_outputs",
]
