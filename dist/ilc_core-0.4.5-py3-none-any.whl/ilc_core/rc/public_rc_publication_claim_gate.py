# PUBLIC_RC_EXCLUDE: internal_public_rc_publication_claim_gate_tool_not_public_rc_launch_surface
# PUBLIC_RC_EXCLUDE_REASON: Phase 1341 local publication/claim gate evidence tooling; not part of the public RC tree.
"""Phase 1341 public RC publication/claim gate.

The gate may only publish or claim public RC when explicit Phase 1341 authority
is present and all selected blockers are closed. In the current repository
state, authority is present but blockers remain open, so the deterministic
result is a fail-closed blocker report with no publication action.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
from collections.abc import Mapping
from pathlib import Path
from typing import Any


PHASE_1341_VERSION = "public_rc_publication_claim_gate_phase_1341.v0.1"
PUBLIC_RC_PUBLICATION_REQUIRES_AUTHORITY_TOKEN = (
    "public_rc_publication_requires_explicit_authority_phase_1341"
)
ALL_SELECTED_BLOCKERS_CHECKED_TOKEN = (
    "all_selected_public_rc_blockers_checked_phase_1341"
)
UNSELECTED_PUBLIC_CLAIMS_NOT_IMPLIED_TOKEN = (
    "unselected_public_claims_not_implied_phase_1341"
)
PHASE_1342_WINDOW_CLOSURE_NEXT_TOKEN = "phase_1342_window_1330_1342_closure_next"
PUBLIC_RC_PUBLICATION_VERDICT_RECORDED_TOKEN = (
    "public_rc_publication_verdict_recorded_phase_1341"
)

EXPLICIT_AUTHORITY_PHRASE = "GO Phase 1341: authorize public RC publication/claim"

PHASE_1333_REPORT_PATH = Path(
    "docs/specs/ilc_source_allowlist_export_execution_gate_1333_v0.1.json"
)
PHASE_1334_REPORT_PATH = Path(
    "docs/specs/ilc_release_artifact_production_gate_1334_v0.1.json"
)
PHASE_1335_REPORT_PATH = Path(
    "docs/specs/ilc_release_keys_envelopes_generation_gate_1335_v0.1.json"
)
PHASE_1336_REPORT_PATH = Path(
    "docs/specs/ilc_public_claimability_api_activation_or_carry_forward_gate_1336_v0.1.json"
)
PHASE_1337_REPORT_PATH = Path(
    "docs/specs/ilc_public_path_sidecar_activation_or_exclusion_gate_1337_v0.1.json"
)
PHASE_1338_REPORT_PATH = Path(
    "docs/specs/ilc_wallet_ecu_ilc_activation_or_carry_forward_gate_1338_v0.1.json"
)
PHASE_1340_REPORT_PATH = Path(
    "docs/specs/ilc_v0_2_signing_ceremony_gate_1340_v0.1.json"
)
PHASE_1300_REPORT_PATH = Path(
    "docs/specs/ilc_counsel_ip_publication_clearance_inventory_1300_v0.1.md"
)
CDL_086_COUNSEL_PATH = Path("docs/specs/ilc_cdl_086_counsel_disposition_1220_v0.1.md")
LICENSING_PATH = Path("LICENSING.md")

DEFAULT_JSON_REPORT_OUT = Path(
    "docs/specs/ilc_public_rc_publication_claim_gate_1341_v0.1.json"
)
DEFAULT_MARKDOWN_REPORT_OUT = Path(
    "docs/specs/ilc_public_rc_publication_claim_gate_1341_v0.1.md"
)

_ALLOWED_RESULTS = frozenset(
    {"public_rc_published", "blocked_no_publication_authority", "blocked_with_findings"}
)
_MAX_JSON_DEPTH = 64
_MAX_TEXT_LENGTH = 8192
_MAX_INT_ABS = 10**12


def phase_1341_required_tokens() -> list[str]:
    return [
        PHASE_1341_VERSION,
        PUBLIC_RC_PUBLICATION_REQUIRES_AUTHORITY_TOKEN,
        ALL_SELECTED_BLOCKERS_CHECKED_TOKEN,
        UNSELECTED_PUBLIC_CLAIMS_NOT_IMPLIED_TOKEN,
        PHASE_1342_WINDOW_CLOSURE_NEXT_TOKEN,
        PUBLIC_RC_PUBLICATION_VERDICT_RECORDED_TOKEN,
    ]


def build_public_rc_publication_claim_gate(
    *,
    authority_token: str | None,
    repo_root: Path | str = Path("."),
    publication_target: str | None = None,
    publication_tag: str | None = None,
) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError("phase_1341_repo_root_invalid")

    authority = _authority_record(authority_token)
    dependency_chain = _dependency_chain(root)
    selected_blockers = _selected_blockers(dependency_chain, publication_target, publication_tag)
    result = _gate_result(authority["explicit_authority_present"], selected_blockers)
    publication_action = _publication_action(result, publication_target, publication_tag)

    manifest: dict[str, Any] = {
        "authority_decision": authority,
        "blockers": selected_blockers,
        "claim_matrix": _claim_matrix(dependency_chain, result),
        "dependency_chain": dependency_chain,
        "discovery": _discovery_record(),
        "gate_result": result,
        "graph_delta": _graph_delta(result),
        "manifest_hash": "sha256:" + "0" * 64,
        "mode": "public_rc_publication_claim_gate",
        "next_phase": PHASE_1342_WINDOW_CLOSURE_NEXT_TOKEN,
        "non_authorization_floor": _non_authorization_floor(
            result, authority["explicit_authority_present"]
        ),
        "non_claim_matrix": _non_claim_matrix(),
        "phase": 1341,
        "public_rc_publication_claim_gate_verdict": _binary_verdict(result),
        "publication_action": publication_action,
        "public_rc_remains_blocked": result != "public_rc_published",
        "required_tokens": phase_1341_required_tokens(),
        "schema_version": PHASE_1341_VERSION,
    }
    manifest["manifest_hash"] = _record_hash_without_key(manifest, "manifest_hash")
    return validate_public_rc_publication_claim_gate(manifest)


def validate_public_rc_publication_claim_gate(manifest: Mapping[str, Any]) -> dict[str, Any]:
    active = dict(manifest)
    if active.get("schema_version") != PHASE_1341_VERSION:
        raise ValueError("phase_1341_schema_version_invalid")
    if active.get("required_tokens") != phase_1341_required_tokens():
        raise ValueError("phase_1341_required_tokens_invalid")
    result = active.get("gate_result")
    if result not in _ALLOWED_RESULTS:
        raise ValueError("phase_1341_gate_result_invalid")
    if active.get("public_rc_publication_claim_gate_verdict") != _binary_verdict(str(result)):
        raise ValueError("phase_1341_binary_verdict_invalid")
    if active.get("manifest_hash") != _record_hash_without_key(active, "manifest_hash"):
        raise ValueError("phase_1341_manifest_hash_invalid")
    if active.get("next_phase") != PHASE_1342_WINDOW_CLOSURE_NEXT_TOKEN:
        raise ValueError("phase_1341_next_phase_invalid")

    authority = _require_mapping(active.get("authority_decision"), "phase_1341_authority")
    blockers = _require_list(active.get("blockers"), "phase_1341_blockers")
    if result == "blocked_no_publication_authority":
        if authority.get("explicit_authority_present") is not False:
            raise ValueError("phase_1341_authority_result_mismatch")
    elif authority.get("explicit_authority_present") is not True:
        raise ValueError("phase_1341_authority_required")
    if result == "blocked_with_findings" and not blockers:
        raise ValueError("phase_1341_blocked_result_requires_findings")
    if result == "public_rc_published" and blockers:
        raise ValueError("phase_1341_published_result_forbids_blockers")

    publication_action = _require_mapping(
        active.get("publication_action"), "phase_1341_publication_action"
    )
    if result != "public_rc_published" and publication_action.get("publication_performed") is not False:
        raise ValueError("phase_1341_blocked_publication_forbidden")
    if result == "public_rc_published" and publication_action.get("publication_performed") is not True:
        raise ValueError("phase_1341_published_action_required")
    if active.get("public_rc_remains_blocked") is not (result != "public_rc_published"):
        raise ValueError("phase_1341_public_rc_blocked_flag_invalid")

    non_auth = _require_mapping(
        active.get("non_authorization_floor"), "phase_1341_non_authorization_floor"
    )
    for key, value in non_auth.items():
        if key == "public_rc_publication_claim_authority_present":
            if value is not bool(authority.get("explicit_authority_present")):
                raise ValueError("phase_1341_authority_flag_invalid")
            continue
        if key in (
            "public_rc_publication_claim_performed",
            "public_repository_publication_performed",
            "source_publication_performed",
        ):
            if value is not (result == "public_rc_published"):
                raise ValueError(f"phase_1341_{key}_flag_invalid")
            continue
        if value is not False:
            raise ValueError("phase_1341_non_authorization_floor_invalid")

    canonical_json(active)
    return active


def write_phase_1341_outputs(
    *,
    authority_token: str | None,
    repo_root: Path | str = Path("."),
    json_out: Path | str = DEFAULT_JSON_REPORT_OUT,
    markdown_out: Path | str = DEFAULT_MARKDOWN_REPORT_OUT,
    publication_target: str | None = None,
    publication_tag: str | None = None,
) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    manifest = build_public_rc_publication_claim_gate(
        authority_token=authority_token,
        repo_root=root,
        publication_target=publication_target,
        publication_tag=publication_tag,
    )
    _write_text_atomic(root / Path(json_out), pretty_json(manifest))
    _write_text_atomic(root / Path(markdown_out), render_markdown_report(manifest))
    return manifest


def render_markdown_report(manifest: Mapping[str, Any]) -> str:
    active = validate_public_rc_publication_claim_gate(manifest)
    blockers = active["blockers"]
    blocker_rows = ["| Blocker | Status | Evidence |", "|---|---|---|"]
    for blocker in blockers:
        blocker_rows.append(
            f"| `{blocker['blocker_id']}` | `{blocker['status']}` | {blocker['evidence']} |"
        )
    if len(blocker_rows) == 2:
        blocker_rows.append("| none | `closed` | all selected blockers closed |")

    claim_rows = ["| Claim | Status | Evidence |", "|---|---|---|"]
    for row in active["claim_matrix"]:
        claim_rows.append(f"| `{row['claim_id']}` | `{row['status']}` | {row['evidence']} |")

    non_claim_rows = ["| Non-claim | Status | Evidence |", "|---|---|---|"]
    for row in active["non_claim_matrix"]:
        non_claim_rows.append(
            f"| `{row['claim_id']}` | `{row['status']}` | {row['evidence']} |"
        )

    return "\n".join(
        [
            "# ILC Public RC Publication Claim Gate 1341 v0.1",
            "",
            f"Status: `{active['gate_result']}`",
            "Phase: `1341`",
            "",
            "```text",
            *active["required_tokens"],
            "```",
            "",
            "## 1. Verdict",
            "",
            f"`{active['public_rc_publication_claim_gate_verdict']}`",
            "",
            f"Gate result: `{active['gate_result']}`.",
            f"Manifest hash: `{active['manifest_hash']}`.",
            f"Public RC remains blocked: `{active['public_rc_remains_blocked']}`.",
            "",
            "## 2. Authority Decision",
            "",
            f"Required phrase matched: `{active['authority_decision']['explicit_authority_present']}`.",
            f"Authority token: `{active['authority_decision']['authority_token']}`.",
            "",
            "## 3. Publication Action",
            "",
            f"Publication performed: `{active['publication_action']['publication_performed']}`.",
            f"Publication target: `{active['publication_action']['publication_target']}`.",
            f"Publication tag: `{active['publication_action']['publication_tag']}`.",
            "",
            "## 4. Selected Blockers",
            "",
            *blocker_rows,
            "",
            "## 5. Claim Matrix",
            "",
            *claim_rows,
            "",
            "## 6. Non-Claim Matrix",
            "",
            *non_claim_rows,
            "",
            "## 7. Non-Authorization Boundary",
            "",
            "Phase 1341 did not publish source, push a public repository, upload a",
            "package, publish an OpenClaw/ClawHub listing, claim installability,",
            "activate public serving, activate claimability, activate wallet/ECU/ILC",
            "value paths, mutate a CDL, open CDL-088, approve counsel/legal posture,",
            "file patents, publish trademark policy, or perform release signing.",
            "",
            "## 8. Graph Delta",
            "",
            "```text",
            active["graph_delta"],
            "graph_delta=support_only:docs/specs/ilc_public_rc_publication_claim_gate_1341_v0.1.json -> publication-claim-evidence",
            "graph_delta=support_only:docs/specs/ilc_public_rc_publication_claim_gate_1341_v0.1.md -> publication-claim-evidence",
            "```",
            "",
        ]
    )


def canonical_json(payload: Mapping[str, Any]) -> str:
    _reject_unsafe_json_tree(payload)
    return json.dumps(payload, allow_nan=False, separators=(",", ":"), sort_keys=True)


def pretty_json(payload: Mapping[str, Any]) -> str:
    _reject_unsafe_json_tree(payload)
    return json.dumps(payload, allow_nan=False, indent=2, sort_keys=True) + "\n"


def _authority_record(authority_token: str | None) -> dict[str, Any]:
    explicit = authority_token == EXPLICIT_AUTHORITY_PHRASE
    return {
        "authority_token": (
            "explicit_phase_1341_public_rc_publication_claim_authority"
            if explicit
            else "missing_or_non_matching_phase_1341_publication_authority"
        ),
        "explicit_authority_present": explicit,
        "required_authority_phrase": EXPLICIT_AUTHORITY_PHRASE,
    }


def _dependency_chain(repo_root: Path) -> dict[str, Any]:
    return {
        "counsel_publication_clearance": _counsel_publication_clearance(repo_root),
        "phase_1333_source_export": _phase_1333_dependency(repo_root),
        "phase_1334_release_artifact": _phase_1334_dependency(repo_root),
        "phase_1335_release_key_envelope": _phase_1335_dependency(repo_root),
        "phase_1336_claimability": _phase_1336_dependency(repo_root),
        "phase_1337_public_path": _phase_1337_dependency(repo_root),
        "phase_1338_value_path": _phase_1338_dependency(repo_root),
        "phase_1340_v0_2_signing": _phase_1340_dependency(repo_root),
    }


def _phase_1333_dependency(repo_root: Path) -> dict[str, Any]:
    report = _load_json(repo_root / PHASE_1333_REPORT_PATH)
    scan = _require_mapping(report.get("candidate_scan"), "phase_1333_candidate_scan")
    counts = _require_mapping(scan.get("counts"), "phase_1333_counts")
    materialization = _require_mapping(
        report.get("export_materialization"), "phase_1333_materialization"
    )
    pass_state = (
        report.get("result") == "executed_clean_export"
        and report.get("clean_materialized_public_tree_produced") is True
        and counts.get("marker_hits") == 0
        and counts.get("dependency_hits") == 0
        and counts.get("legacy_untagged_review_required_blocked") == 0
    )
    return {
        "evidence": (
            f"result={report.get('result')}; files={materialization.get('exported_file_count')}; "
            f"tree_hash={materialization.get('tree_sha256')}; "
            f"marker_hits={counts.get('marker_hits')}; dependency_hits={counts.get('dependency_hits')}"
        ),
        "path": PHASE_1333_REPORT_PATH.as_posix(),
        "status": "closed" if pass_state else "open",
    }


def _phase_1334_dependency(repo_root: Path) -> dict[str, Any]:
    report = _load_json(repo_root / PHASE_1334_REPORT_PATH)
    artifacts = _require_list(report.get("artifacts"), "phase_1334_artifacts")
    artifact = _require_mapping(artifacts[0], "phase_1334_artifact") if artifacts else {}
    unsigned_policy = _require_mapping(
        report.get("unsigned_artifact_policy"), "phase_1334_unsigned_policy"
    )
    return {
        "artifact_hash": artifact.get("canonical_hash"),
        "artifact_path": artifact.get("path"),
        "artifact_status": artifact.get("signing_status"),
        "evidence": (
            f"result={report.get('result')}; artifact={artifact.get('path')}; "
            f"hash={artifact.get('canonical_hash')}; signing_status={artifact.get('signing_status')}"
        ),
        "path": PHASE_1334_REPORT_PATH.as_posix(),
        "release_signing_closed": artifact.get("signing_status") == "signed",
        "status": "closed" if report.get("result") == "artifacts_produced_unsigned" else "open",
        "unsigned_policy": unsigned_policy,
    }


def _phase_1335_dependency(repo_root: Path) -> dict[str, Any]:
    report = _load_json(repo_root / PHASE_1335_REPORT_PATH)
    envelope = _require_mapping(
        report.get("release_envelope_candidate"), "phase_1335_release_envelope"
    )
    return {
        "evidence": (
            f"result={report.get('result')}; envelope_hash={envelope.get('envelope_hash')}; "
            f"signing_status={envelope.get('signing_status')}"
        ),
        "path": PHASE_1335_REPORT_PATH.as_posix(),
        "release_envelope_hash": envelope.get("envelope_hash"),
        "release_envelope_status": envelope.get("signing_status"),
        "status": "closed" if report.get("result") == "keys_envelopes_generated" else "open",
    }


def _phase_1336_dependency(repo_root: Path) -> dict[str, Any]:
    report = _load_json(repo_root / PHASE_1336_REPORT_PATH)
    return {
        "blockers": report.get("blockers", []),
        "evidence": f"result={report.get('result')}; blockers={len(report.get('blockers', []))}",
        "path": PHASE_1336_REPORT_PATH.as_posix(),
        "status": "closed" if report.get("result") == "public_claimability_activated" else "open",
    }


def _phase_1337_dependency(repo_root: Path) -> dict[str, Any]:
    report = _load_json(repo_root / PHASE_1337_REPORT_PATH)
    return {
        "blockers": report.get("blockers", []),
        "evidence": f"result={report.get('result')}; blockers={len(report.get('blockers', []))}",
        "path": PHASE_1337_REPORT_PATH.as_posix(),
        "status": "closed" if report.get("result") == "public_path_activated" else "open",
    }


def _phase_1338_dependency(repo_root: Path) -> dict[str, Any]:
    report = _load_json(repo_root / PHASE_1338_REPORT_PATH)
    return {
        "blockers": report.get("blockers", []),
        "evidence": f"result={report.get('result')}; blockers={len(report.get('blockers', []))}",
        "path": PHASE_1338_REPORT_PATH.as_posix(),
        "status": "closed" if report.get("result") == "wallet_ecu_ilc_activated" else "open",
    }


def _phase_1340_dependency(repo_root: Path) -> dict[str, Any]:
    report = _load_json(repo_root / PHASE_1340_REPORT_PATH)
    signature = _require_mapping(report.get("signature"), "phase_1340_signature")
    root = _require_mapping(report.get("root_envelope"), "phase_1340_root_envelope")
    pass_state = (
        report.get("gate_result") == "v0_2_signed"
        and signature.get("verification_result") == "signature_verified"
    )
    return {
        "evidence": (
            f"gate_result={report.get('gate_result')}; envelope_hash={root.get('envelope_hash')}; "
            f"signature_hash={signature.get('signature_sha256')}; verification={signature.get('verification_result')}"
        ),
        "path": PHASE_1340_REPORT_PATH.as_posix(),
        "status": "closed" if pass_state else "open",
    }


def _counsel_publication_clearance(repo_root: Path) -> dict[str, Any]:
    phase_1300 = (repo_root / PHASE_1300_REPORT_PATH).read_text(encoding="utf-8")
    cdl_086 = (repo_root / CDL_086_COUNSEL_PATH).read_text(encoding="utf-8")
    licensing = (repo_root / LICENSING_PATH).read_text(encoding="utf-8")
    closed = (
        "counsel_ip_publication_verdict_phase_1300=inventory_only_no_publication"
        not in phase_1300
        and "NOT COUNSEL-APPROVED LEGAL CONCLUSIONS" not in cdl_086
        and "subject to later counsel review" not in licensing
    )
    return {
        "evidence": (
            "Phase 1300 is inventory-only/no-publication; CDL-086 counsel disposition "
            "is provisional and not counsel-approved; LICENSING remains subject to later counsel review."
        ),
        "paths": [
            PHASE_1300_REPORT_PATH.as_posix(),
            CDL_086_COUNSEL_PATH.as_posix(),
            LICENSING_PATH.as_posix(),
        ],
        "status": "closed" if closed else "open",
    }


def _selected_blockers(
    dependency_chain: Mapping[str, Any],
    publication_target: str | None,
    publication_tag: str | None,
) -> list[dict[str, str]]:
    blockers: list[dict[str, str]] = []

    if publication_target is None or publication_tag is None:
        blockers.append(
            _blocker(
                "publication_target_or_tag_not_selected",
                "No public repository/package destination and immutable public RC tag were supplied.",
                "future_phase_1341_retry_or_window_1342_handoff",
            )
        )
    if dependency_chain["counsel_publication_clearance"]["status"] != "closed":
        blockers.append(
            _blocker(
                "counsel_publication_clearance_missing",
                dependency_chain["counsel_publication_clearance"]["evidence"],
                "window_1369_1390_counsel_public_api_and_publication_clearance",
            )
        )
    if dependency_chain["phase_1334_release_artifact"]["release_signing_closed"] is not True:
        blockers.append(
            _blocker(
                "release_artifact_not_release_signed",
                dependency_chain["phase_1334_release_artifact"]["evidence"],
                "future_release_signing_gate_before_public_distribution",
            )
        )
    if dependency_chain["phase_1336_claimability"]["status"] != "closed":
        blockers.append(
            _blocker(
                "public_claimability_api_not_activated",
                dependency_chain["phase_1336_claimability"]["evidence"],
                "window_1369_1390_public_claimability_activation_lane",
            )
        )
    if dependency_chain["phase_1337_public_path"]["status"] != "closed":
        blockers.append(
            _blocker(
                "public_path_p2p_sidecar_serving_not_activated",
                dependency_chain["phase_1337_public_path"]["evidence"],
                "future_public_path_sidecar_serving_lane",
            )
        )
    if dependency_chain["phase_1338_value_path"]["status"] != "closed":
        blockers.append(
            _blocker(
                "wallet_ecu_ilc_value_path_not_activated",
                dependency_chain["phase_1338_value_path"]["evidence"],
                "window_1343_1368_issuance_value_path_prerequisites",
            )
        )
    for key in ("phase_1333_source_export", "phase_1335_release_key_envelope", "phase_1340_v0_2_signing"):
        if dependency_chain[key]["status"] != "closed":
            blockers.append(
                _blocker(
                    f"{key}_not_closed",
                    dependency_chain[key]["evidence"],
                    "fix_required_before_phase_1341_retry",
                )
            )
    return blockers


def _blocker(blocker_id: str, evidence: str, carry_forward_route: str) -> dict[str, str]:
    return {
        "blocker_id": blocker_id,
        "carry_forward_route": carry_forward_route,
        "evidence": evidence,
        "status": "open",
    }


def _gate_result(explicit_authority: bool, blockers: list[dict[str, str]]) -> str:
    if not explicit_authority:
        return "blocked_no_publication_authority"
    if blockers:
        return "blocked_with_findings"
    return "public_rc_published"


def _publication_action(
    result: str, publication_target: str | None, publication_tag: str | None
) -> dict[str, Any]:
    return {
        "publication_performed": result == "public_rc_published",
        "publication_tag": publication_tag or "not_selected",
        "publication_target": publication_target or "not_selected",
        "source_publication_performed": result == "public_rc_published",
        "public_repository_push_performed": result == "public_rc_published",
        "public_package_upload_performed": False,
        "openclaw_clawhub_listing_performed": False,
    }


def _claim_matrix(dependency_chain: Mapping[str, Any], result: str) -> list[dict[str, str]]:
    return [
        {
            "claim_id": "clean_materialized_source_tree_exists",
            "status": dependency_chain["phase_1333_source_export"]["status"],
            "evidence": dependency_chain["phase_1333_source_export"]["evidence"],
        },
        {
            "claim_id": "unsigned_release_artifact_exists",
            "status": dependency_chain["phase_1334_release_artifact"]["status"],
            "evidence": dependency_chain["phase_1334_release_artifact"]["evidence"],
        },
        {
            "claim_id": "release_key_envelope_metadata_exists",
            "status": dependency_chain["phase_1335_release_key_envelope"]["status"],
            "evidence": dependency_chain["phase_1335_release_key_envelope"]["evidence"],
        },
        {
            "claim_id": "genesis_atlas_v0_2_root_envelope_signed",
            "status": dependency_chain["phase_1340_v0_2_signing"]["status"],
            "evidence": dependency_chain["phase_1340_v0_2_signing"]["evidence"],
        },
        {
            "claim_id": "public_rc_publication_claim",
            "status": "published" if result == "public_rc_published" else "blocked",
            "evidence": "Phase 1341 fail-closed unless all selected blockers are closed.",
        },
    ]


def _non_claim_matrix() -> list[dict[str, str]]:
    non_claims = [
        "public_claimability_api_activation",
        "public_p2p_fetch_sidecar_serving_activation",
        "public_confidential_coordination_serving",
        "wallet_ecu_ilc_value_path_activation",
        "identity_bootstrap_or_agent_birth_attestation",
        "release_signing",
        "counsel_legal_clearance",
        "openclaw_clawhub_public_listing_or_installability",
        "cdl_mutation_or_cdl_088_opening",
    ]
    return [
        {
            "claim_id": claim,
            "evidence": "Not selected or still blocked by prior gate reports.",
            "status": "not_claimed",
        }
        for claim in non_claims
    ]


def _non_authorization_floor(result: str, authority_present: bool) -> dict[str, bool]:
    published = result == "public_rc_published"
    return {
        "cdl_088_opening_authorized": False,
        "cdl_mutation_authorized": False,
        "counsel_approval_authorized_or_recorded": False,
        "identity_bootstrap_authorized": False,
        "openclaw_clawhub_listing_authorized": False,
        "package_publication_authorized_or_performed": False,
        "patent_filing_authorized_or_performed": False,
        "public_claimability_api_authorized": False,
        "public_confidential_coordination_serving_authorized": False,
        "public_p2p_fetch_sidecar_serving_authorized": False,
        "public_rc_publication_claim_authority_present": authority_present,
        "public_rc_publication_claim_performed": published,
        "public_repository_publication_performed": published,
        "release_signing_authorized_or_performed": False,
        "source_publication_performed": published,
        "trademark_policy_publication_authorized_or_performed": False,
        "wallet_ecu_ilc_activation_authorized": False,
    }


def _discovery_record() -> dict[str, Any]:
    return {
        "section_0a": "required tokens searched and anchored in report",
        "section_0b": "searched public RC, publication, repository, package, release, claim, launch, license, counsel, CLA, trademark, patent, OpenClaw, ClawHub, claimability, P2P, sidecar, wallet, ECU, settlement, signing, and Genesis",
        "section_0c": "searched blocked, deferred, not authorized, public rc remains blocked, do not publish, counsel review, patent, not installable, no public, and carry-forward",
        "section_0d": "direct-read current reports and counsel/publication evidence; MemPalace used as advisory recall only",
    }


def _binary_verdict(result: str) -> str:
    if result == "public_rc_published":
        return "public_rc_publication_claim_gate_verdict=pass"
    if result == "blocked_no_publication_authority":
        return "public_rc_publication_claim_gate_verdict=blocked_no_publication_authority"
    return "public_rc_publication_claim_gate_verdict=blocked_with_findings"


def _graph_delta(result: str) -> str:
    if result == "public_rc_published":
        return "graph_delta=load_bearing_artifact_added:public_rc_publication_claim -> public-rc/publication"
    return "graph_delta=deferred:phase_1341_public_rc_publication_claim_blocked"


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_text_atomic(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.replace(tmp_path, path)
    except Exception:
        if tmp_path.exists():
            tmp_path.unlink()
        raise


def _record_hash_without_key(record: Mapping[str, Any], key: str) -> str:
    body = dict(record)
    body[key] = "sha256:" + "0" * 64
    return "sha256:" + hashlib.sha256(canonical_json(body).encode("utf-8")).hexdigest()


def _require_mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{label}_must_be_mapping")
    return value


def _require_list(value: Any, label: str) -> list[Any]:
    if not isinstance(value, list):
        raise ValueError(f"{label}_must_be_list")
    return value


def _require_text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value or value != value.strip():
        raise ValueError(f"{label}_must_be_text")
    if len(value) > _MAX_TEXT_LENGTH or any(ord(char) < 0x20 or char == "\x7f" for char in value):
        raise ValueError(f"{label}_must_be_safe_text")
    return value


def _reject_unsafe_json_tree(payload: Any) -> None:
    seen: set[int] = set()

    def visit(item: Any, depth: int) -> None:
        if depth > _MAX_JSON_DEPTH:
            raise ValueError("phase_1341_json_depth_exceeded")
        marker = id(item)
        if isinstance(item, (dict, list, tuple)):
            if marker in seen:
                raise ValueError("phase_1341_json_cycle_detected")
            seen.add(marker)
        if isinstance(item, Mapping):
            for key, value in item.items():
                _require_text(key, "phase_1341_json_key")
                visit(value, depth + 1)
            seen.remove(marker)
            return
        if isinstance(item, (list, tuple)):
            for value in item:
                visit(value, depth + 1)
            seen.remove(marker)
            return
        if isinstance(item, str):
            _require_text(item, "phase_1341_json_text")
            return
        if isinstance(item, bool) or item is None:
            return
        if isinstance(item, int) and not isinstance(item, bool):
            if abs(item) > _MAX_INT_ABS:
                raise ValueError("phase_1341_json_int_exceeded")
            return
        raise ValueError("phase_1341_json_unsupported_type")

    visit(payload, 0)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--authority-token", default=None)
    parser.add_argument("--repo-root", type=Path, default=Path("."))
    parser.add_argument("--json-out", type=Path, default=DEFAULT_JSON_REPORT_OUT)
    parser.add_argument("--markdown-out", type=Path, default=DEFAULT_MARKDOWN_REPORT_OUT)
    parser.add_argument("--publication-target", default=None)
    parser.add_argument("--publication-tag", default=None)
    args = parser.parse_args()
    manifest = write_phase_1341_outputs(
        authority_token=args.authority_token,
        repo_root=args.repo_root,
        json_out=args.json_out,
        markdown_out=args.markdown_out,
        publication_target=args.publication_target,
        publication_tag=args.publication_tag,
    )
    print(manifest["gate_result"])


if __name__ == "__main__":
    main()
