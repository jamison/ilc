# PUBLIC_RC_EXCLUDE: genesis_atlas_candidate_lmdb_research_only
# PUBLIC_RC_EXCLUDE_REASON: Local research/materialization adapter for unsigned Atlas candidates; not public package runtime.
# SPDX-License-Identifier: AGPL-3.0-only
"""LMDB adapter for unsigned Genesis Atlas candidate materialization.

"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from ilc_core.storage.lmdb_public_runtime import (
    DEFAULT_MAP_SIZE_BYTES,
    _LmdbRuntimeBase,
    _encode_json,
    _encode_key,
)


GENESIS_ATLAS_CANDIDATE_LMDB_ADAPTER_VERSION = "genesis_atlas_candidate_lmdb_adapter_1545p_fix23.v0.1"


class GenesisAtlasCandidateStore(_LmdbRuntimeBase):
    """Local LMDB projection for unsigned Genesis Atlas candidate graphs.

    Named databases:
        b"nodes" - key=candidate_id, value=candidate node JSON
        b"edges" - key=edge_id, value=candidate edge JSON
        b"preimages" - key=node_id or edge_id, value=unsigned candidate preimage JSON
        b"meta" - key=metadata token, value=JSON metadata
        b"nodes_by_tier" - key=tier, value=sorted candidate_id list
        b"nodes_by_source_path" - key=source path, value=sorted candidate_id list

    This adapter intentionally does not sign, publish, gossip, activate, or
    promote any candidate record. It is a local query/materialization substrate.
    """

    def __init__(
        self,
        root: Path | str,
        *,
        allow_synthetic_edge_keys: bool = False,
        map_size: int = DEFAULT_MAP_SIZE_BYTES * 4,
    ) -> None:
        self._allow_synthetic_edge_keys = allow_synthetic_edge_keys
        super().__init__(
            root,
            db_names=(
                b"nodes",
                b"edges",
                b"graph_payload",
                b"preimages",
                b"meta",
                b"nodes_by_tier",
                b"nodes_by_tier_group",
                b"nodes_by_source_path",
            ),
            map_size=map_size,
        )

    def put_meta(self, key: str, payload: dict[str, Any]) -> None:
        self._put_json(b"meta", key, payload)

    def get_meta(self, key: str) -> dict[str, Any] | None:
        payload = self._get_json(b"meta", key)
        return payload if isinstance(payload, dict) else None

    def put_graph_payload(self, graph: dict[str, Any]) -> None:
        self._put_json(b"graph_payload", "candidate", graph)

    def get_graph_payload(self) -> dict[str, Any] | None:
        payload = self._get_json(b"graph_payload", "candidate")
        return payload if isinstance(payload, dict) else None

    def put_nodes(self, nodes: list[dict[str, Any]]) -> None:
        """Bulk-write candidate nodes and deterministic indexes."""
        tier_index: dict[str, list[str]] = {}
        tier_group_index: dict[str, list[str]] = {}
        path_index: dict[str, list[str]] = {}
        with self.env.begin(write=True) as txn:
            nodes_db = self._dbs[b"nodes"]
            for node in nodes:
                node_id = _candidate_id(node)
                txn.put(_encode_key(node_id), _encode_json(node), db=nodes_db)
                tier = str(node.get("tier", "unknown"))
                tier_index.setdefault(tier, []).append(node_id)
                tier_group_index.setdefault(_tier_group(node), []).append(node_id)
                source_path = node.get("source_path")
                if isinstance(source_path, str) and source_path:
                    path_index.setdefault(source_path, []).append(node_id)
        self._write_string_list_index(b"nodes_by_tier", tier_index)
        self._write_string_list_index(b"nodes_by_tier_group", tier_group_index)
        self._write_string_list_index(b"nodes_by_source_path", path_index)

    def replace_nodes(self, nodes: list[dict[str, Any]]) -> None:
        """Replace the full candidate node database and deterministic indexes."""
        tier_index: dict[str, list[str]] = {}
        tier_group_index: dict[str, list[str]] = {}
        path_index: dict[str, list[str]] = {}
        with self.env.begin(write=True) as txn:
            nodes_db = self._dbs[b"nodes"]
            txn.drop(nodes_db, delete=False)
            for node in nodes:
                node_id = _candidate_id(node)
                txn.put(_encode_key(node_id), _encode_json(node), db=nodes_db)
                tier = str(node.get("tier", "unknown"))
                tier_index.setdefault(tier, []).append(node_id)
                tier_group_index.setdefault(_tier_group(node), []).append(node_id)
                source_path = node.get("source_path")
                if isinstance(source_path, str) and source_path:
                    path_index.setdefault(source_path, []).append(node_id)
        self._replace_string_list_index(b"nodes_by_tier", tier_index)
        self._replace_string_list_index(b"nodes_by_tier_group", tier_group_index)
        self._replace_string_list_index(b"nodes_by_source_path", path_index)

    def put_edges(self, edges: list[dict[str, Any]]) -> None:
        """Bulk-write candidate edges."""
        with self.env.begin(write=True, db=self._dbs[b"edges"]) as txn:
            for index, edge in enumerate(edges):
                edge_id = _edge_lmdb_key(
                    edge,
                    index=index,
                    allow_synthetic_edge_keys=self._allow_synthetic_edge_keys,
                )
                txn.put(_encode_key(edge_id), _encode_json(edge))

    def replace_edges(self, edges: list[dict[str, Any]]) -> None:
        """Replace the full candidate edge database.

        This is required for maintenance operations that change an existing
        edge's explicit ``edge_id`` field. With synthetic LMDB keys enabled,
        appending the repaired record would leave the old synthetic-key row in
        place. Full replacement keeps row stores and graph payloads aligned.
        """
        with self.env.begin(write=True) as txn:
            edges_db = self._dbs[b"edges"]
            txn.drop(edges_db, delete=False)
            for index, edge in enumerate(edges):
                edge_id = _edge_lmdb_key(
                    edge,
                    index=index,
                    allow_synthetic_edge_keys=self._allow_synthetic_edge_keys,
                )
                txn.put(_encode_key(edge_id), _encode_json(edge), db=edges_db)

    def put_preimages(self, preimages: list[dict[str, Any]]) -> None:
        """Bulk-write deterministic unsigned node or edge preimages."""
        with self.env.begin(write=True, db=self._dbs[b"preimages"]) as txn:
            for preimage in preimages:
                preimage_id = _preimage_id(preimage)
                txn.put(_encode_key(preimage_id), _encode_json(preimage))

    def get_node(self, candidate_id: str) -> dict[str, Any] | None:
        payload = self._get_json(b"nodes", candidate_id)
        return payload if isinstance(payload, dict) else None

    def get_edge(self, edge_id: str) -> dict[str, Any] | None:
        payload = self._get_json(b"edges", edge_id)
        return payload if isinstance(payload, dict) else None

    def get_preimage(self, preimage_id: str) -> dict[str, Any] | None:
        payload = self._get_json(b"preimages", preimage_id)
        return payload if isinstance(payload, dict) else None

    def iter_nodes(self) -> list[dict[str, Any]]:
        rows = [row for row in self._iter_json(b"nodes") if isinstance(row, dict)]
        return sorted(rows, key=lambda row: str(row.get("candidate_id", "")))

    def iter_edges(self) -> list[dict[str, Any]]:
        rows = [row for row in self._iter_json(b"edges") if isinstance(row, dict)]
        return sorted(
            rows,
            key=lambda row: (
                str(row.get("edge_id", "")),
                str(row.get("source_candidate_id", row.get("source", row.get("from", "")))),
                str(row.get("target_candidate_id", row.get("target", row.get("to", "")))),
            ),
        )

    def iter_preimages(self) -> list[dict[str, Any]]:
        rows = [row for row in self._iter_json(b"preimages") if isinstance(row, dict)]
        return sorted(
            rows,
            key=lambda row: (
                0 if isinstance(row.get("node_id"), str) and row.get("node_id") else 1,
                str(row.get("node_id", row.get("edge_id", ""))),
            ),
        )

    def node_ids_by_tier(self, tier: str) -> list[str]:
        payload = self._get_json(b"nodes_by_tier", tier)
        return sorted(item for item in payload if isinstance(item, str)) if isinstance(payload, list) else []

    def node_ids_by_tier_group(self, tier_group: str) -> list[str]:
        payload = self._get_json(b"nodes_by_tier_group", tier_group)
        return sorted(item for item in payload if isinstance(item, str)) if isinstance(payload, list) else []

    def node_ids_by_source_path(self, source_path: str) -> list[str]:
        payload = self._get_json(b"nodes_by_source_path", source_path)
        return sorted(item for item in payload if isinstance(item, str)) if isinstance(payload, list) else []

    def _write_string_list_index(self, db_name: bytes, index: dict[str, list[str]]) -> None:
        with self.env.begin(write=True, db=self._dbs[db_name]) as txn:
            for key, values in sorted(index.items()):
                txn.put(_encode_key(key), _encode_json(sorted(set(values))))

    def _replace_string_list_index(self, db_name: bytes, index: dict[str, list[str]]) -> None:
        with self.env.begin(write=True) as txn:
            db = self._dbs[db_name]
            txn.drop(db, delete=False)
            for key, values in sorted(index.items()):
                txn.put(_encode_key(key), _encode_json(sorted(set(values))), db=db)


def _candidate_id(node: dict[str, Any]) -> str:
    value = node.get("candidate_id")
    if not isinstance(value, str) or not value:
        raise ValueError("genesis_atlas_candidate_node_missing_candidate_id")
    return value


def _edge_id(edge: dict[str, Any]) -> str:
    value = edge.get("edge_id")
    if not isinstance(value, str) or not value:
        raise ValueError("genesis_atlas_candidate_edge_missing_edge_id")
    return value


def _edge_lmdb_key(edge: dict[str, Any], *, index: int, allow_synthetic_edge_keys: bool) -> str:
    if not allow_synthetic_edge_keys:
        return _edge_id(edge)
    explicit = edge.get("edge_id")
    digest = hashlib.sha256(_encode_json(edge)).hexdigest()[:32]
    if isinstance(explicit, str) and explicit:
        return f"{index:012d}:edge_id:{explicit}:{digest}"
    return f"{index:012d}:synthetic:{digest}"


def _preimage_id(preimage: dict[str, Any]) -> str:
    value = preimage.get("node_id")
    if not isinstance(value, str) or not value:
        value = preimage.get("edge_id")
    if not isinstance(value, str) or not value:
        raise ValueError("genesis_atlas_candidate_preimage_missing_node_or_edge_id")
    return value


def _tier_group(node: dict[str, Any]) -> str:
    tier = str(node.get("tier", "unknown")).lower()
    canonicality_tier = str(node.get("canonicality_tier", "")).lower()
    node_kind = str(node.get("node_kind", "")).lower()
    sensitivity = str(node.get("sensitivity", "")).lower()
    inclusion_status = str(node.get("inclusion_status", "")).lower()
    if tier == "genesis_core" or "genesis_core" in canonicality_tier:
        return "canonical"
    if (
        "private" in tier
        or "excluded" in tier
        or "private" in sensitivity
        or "public_rc_exclude" in sensitivity
        or "excluded" in inclusion_status
    ):
        return "private"
    if "test" in node_kind:
        return "support"
    return "support"


__all__ = [
    "GENESIS_ATLAS_CANDIDATE_LMDB_ADAPTER_VERSION",
    "GenesisAtlasCandidateStore",
]
