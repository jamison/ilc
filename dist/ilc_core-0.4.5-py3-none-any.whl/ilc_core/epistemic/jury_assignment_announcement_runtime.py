# SPDX-License-Identifier: AGPL-3.0-only
# PUBLIC_RC_EXCLUDE: phase_1568_fix2g_jury_assignment_announcement_recovery
"""Phase 1568-Fix2g jury assignment announcement and recovery runtime.

This module defines the lightweight push signal, reviewer-side self-match/ack
contract, and missing-assignment recovery receipt shape for jury assignment.
It intentionally does not start a listener, push full panel membership, write
graph canon, write wallets, issue ECU/ILC, or authorize reviewer payment.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Final, Mapping, Sequence

from ilc_core.network.d2d import gossip_transport

JURY_ASSIGNMENT_ANNOUNCEMENT_RUNTIME_VERSION: Final[str] = (
    "jury_assignment_announcement_recovery_phase_1568_fix2g.v0.1"
)
JURY_ASSIGNMENT_ANNOUNCED_GOSSIP_TYPE: Final[str] = "jury_assignment_announced"
MISSING_REVIEW_ASSIGNMENT_GOSSIP_TYPE: Final[str] = "missing_review_assignment"
JURY_ASSIGNMENT_GOSSIP_CHANNEL: Final[str] = (
    "cid:1568f2a70000000000000000000000000000000000000000000000000000000000"
)
JURY_ASSIGNMENT_DOMAIN: Final[str] = "ILC_JURY_ASSIGNMENT_CONTEXT_V1"
JURY_ASSIGNMENT_ID_DOMAIN: Final[str] = "ILC_JURY_ASSIGNMENT_ID_V1"
JURY_SELECTION_RANK_DOMAIN: Final[str] = "ILC_JURY_SELECT_V1"
JURY_ASSIGNMENT_ACK_DOMAIN: Final[str] = "ILC_JURY_ASSIGNMENT_ACK_V1"
MISSING_REVIEW_ASSIGNMENT_DOMAIN: Final[str] = "ILC_MISSING_REVIEW_ASSIGNMENT_V1"
UNSIGNED_GOSSIP_SIGNATURE: Final[str] = "UNSIGNED"

PHASE_TOKENS: Final[tuple[str, ...]] = (
    "phase_1568_fix2g_jury_assignment_announced_gossip_type_added",
    "phase_1568_fix2g_no_raw_panel_id_broadcast",
    "phase_1568_fix2g_reviewer_pull_ack_contract_recorded",
    "phase_1568_fix2g_missing_review_assignment_recovery_recorded",
    "phase_1568_fix2g_non_response_liveness_only_boundary_recorded",
    "phase_1568_fix2g_no_reward_or_public_serving_activation",
)

ALLOWED_SELECTION_MODES: Final[frozenset[str]] = frozenset(
    {"vrf_proof", "epoch_hash_shadow", "panel_hash_fallback"}
)
ALLOWED_ANNOUNCEMENT_KEYS: Final[frozenset[str]] = frozenset(
    {
        "algorithm_id",
        "announcing_agent_id",
        "assignment_context_hash",
        "assignment_id",
        "cdl_version",
        "node_cid",
        "review_epoch",
        "review_lane",
        "runtime_version",
        "selection_mode",
    }
)
FORBIDDEN_PUSH_KEYS: Final[frozenset[str]] = frozenset(
    {
        "assigned_agent_ids",
        "economic_amounts",
        "full_task_payload",
        "jury_panel_id",
        "outsider_panel",
        "panel_ids",
        "panel_quote",
        "private_reviewer_notes",
        "raw_panel",
        "regular_panel",
        "reviewer_agent_ids",
        "reviewer_ids",
        "reviewer_public_keys",
        "task_payload",
        "treasury",
        "wallet",
    }
)


@dataclass(frozen=True)
class JuryAssignmentAnnouncement:
    """Minimal push signal for an assignment that reviewers can replay locally."""

    assignment_id: str
    node_cid: str
    review_epoch: int
    review_lane: str
    assignment_context_hash: str
    selection_mode: str
    algorithm_id: str
    announcing_agent_id: str
    cdl_version: str
    runtime_version: str = JURY_ASSIGNMENT_ANNOUNCEMENT_RUNTIME_VERSION

    def canonical_payload(self) -> dict[str, object]:
        return {
            "algorithm_id": self.algorithm_id,
            "announcing_agent_id": self.announcing_agent_id,
            "assignment_context_hash": self.assignment_context_hash,
            "assignment_id": self.assignment_id,
            "cdl_version": self.cdl_version,
            "node_cid": self.node_cid,
            "review_epoch": self.review_epoch,
            "review_lane": self.review_lane,
            "runtime_version": self.runtime_version,
            "selection_mode": self.selection_mode,
        }


@dataclass(frozen=True)
class ReviewerAssignmentAck:
    """Reviewer-side acknowledgement receipt with no economic effect."""

    assignment_id: str
    assignment_context_hash: str
    agent_id: str
    review_epoch: int
    review_lane: str
    ack_hash: str
    signature_boundary_ref: str
    economic_effect: bool
    graph_canon_write_authorized: bool
    reviewer_payment_authorized: bool
    treasury_write_authorized: bool
    wallet_write_authorized: bool
    phase_tokens: tuple[str, ...]
    runtime_version: str = JURY_ASSIGNMENT_ANNOUNCEMENT_RUNTIME_VERSION

    def canonical_payload(self) -> dict[str, object]:
        return {
            "ack_hash": self.ack_hash,
            "agent_id": self.agent_id,
            "assignment_context_hash": self.assignment_context_hash,
            "assignment_id": self.assignment_id,
            "economic_effect": self.economic_effect,
            "graph_canon_write_authorized": self.graph_canon_write_authorized,
            "phase_tokens": list(self.phase_tokens),
            "review_epoch": self.review_epoch,
            "review_lane": self.review_lane,
            "reviewer_payment_authorized": self.reviewer_payment_authorized,
            "runtime_version": self.runtime_version,
            "signature_boundary_ref": self.signature_boundary_ref,
            "treasury_write_authorized": self.treasury_write_authorized,
            "wallet_write_authorized": self.wallet_write_authorized,
        }


@dataclass(frozen=True)
class MissingReviewAssignmentRequest:
    """O(1) recovery cursor for missed assignment announcements."""

    request_id: str
    agent_id: str
    latest_known_review_epoch: int
    assignment_cursor: str
    review_lane: str | None
    recovery_type: str
    economic_effect: bool
    runtime_version: str = JURY_ASSIGNMENT_ANNOUNCEMENT_RUNTIME_VERSION

    def canonical_payload(self) -> dict[str, object]:
        return {
            "agent_id": self.agent_id,
            "assignment_cursor": self.assignment_cursor,
            "economic_effect": self.economic_effect,
            "latest_known_review_epoch": self.latest_known_review_epoch,
            "recovery_type": self.recovery_type,
            "request_id": self.request_id,
            "review_lane": self.review_lane,
            "runtime_version": self.runtime_version,
        }


@dataclass(frozen=True)
class MissingReviewAssignmentResponse:
    """Header/hash-only response to a missed-assignment request."""

    request_id: str
    assignment_headers: tuple[dict[str, object], ...]
    full_payload_included: bool
    economic_effect: bool
    runtime_version: str = JURY_ASSIGNMENT_ANNOUNCEMENT_RUNTIME_VERSION

    def canonical_payload(self) -> dict[str, object]:
        return {
            "assignment_headers": list(self.assignment_headers),
            "economic_effect": self.economic_effect,
            "full_payload_included": self.full_payload_included,
            "request_id": self.request_id,
            "runtime_version": self.runtime_version,
        }


@dataclass(frozen=True)
class NonResponseLivenessEvidence:
    """Missed assignment/non-response evidence; never an economic penalty."""

    assignment_id: str
    agent_id: str
    review_epoch: int
    evidence_hash: str
    liveness_only: bool
    ecu_burn_authorized: bool
    slash_authorized: bool
    wallet_debit_authorized: bool
    treasury_event_authorized: bool
    settlement_authorized: bool
    runtime_version: str = JURY_ASSIGNMENT_ANNOUNCEMENT_RUNTIME_VERSION

    def canonical_payload(self) -> dict[str, object]:
        return {
            "agent_id": self.agent_id,
            "assignment_id": self.assignment_id,
            "ecu_burn_authorized": self.ecu_burn_authorized,
            "evidence_hash": self.evidence_hash,
            "liveness_only": self.liveness_only,
            "review_epoch": self.review_epoch,
            "runtime_version": self.runtime_version,
            "settlement_authorized": self.settlement_authorized,
            "slash_authorized": self.slash_authorized,
            "treasury_event_authorized": self.treasury_event_authorized,
            "wallet_debit_authorized": self.wallet_debit_authorized,
        }


def _canonical_json(payload: Mapping[str, object]) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _sha384_hex(payload: Mapping[str, object]) -> str:
    return hashlib.sha384(_canonical_json(payload).encode("utf-8")).hexdigest()


def _require_non_empty_string(value: Any, token: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(token)
    return value.strip()


def _require_non_negative_int(value: Any, token: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(token)
    return value


def _require_sha384_hex(value: Any, token: str) -> str:
    normalized = _require_non_empty_string(value, token)
    if len(normalized) != 96 or any(char not in "0123456789abcdef" for char in normalized):
        raise ValueError(token)
    return normalized


def _assert_no_forbidden_push_keys(value: object) -> None:
    if isinstance(value, Mapping):
        for key, nested in value.items():
            if not isinstance(key, str):
                raise ValueError("jury_assignment_push_key_must_be_string")
            if key in FORBIDDEN_PUSH_KEYS:
                raise ValueError(f"jury_assignment_push_forbidden_key:{key}")
            _assert_no_forbidden_push_keys(nested)
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        for nested in value:
            _assert_no_forbidden_push_keys(nested)


def build_assignment_context_hash(
    *,
    node_cid: str,
    review_epoch: int,
    review_lane: str,
    eligible_set_root: str,
    algorithm_id: str,
    selection_mode: str,
) -> str:
    """Build replayable assignment-context hash without exposing panel members."""

    normalized_epoch = _require_non_negative_int(review_epoch, "review_epoch_invalid")
    normalized_mode = _require_non_empty_string(selection_mode, "selection_mode_invalid")
    if normalized_mode not in ALLOWED_SELECTION_MODES:
        raise ValueError("selection_mode_not_allowed")

    return _sha384_hex(
        {
            "algorithm_id": _require_non_empty_string(algorithm_id, "algorithm_id_invalid"),
            "domain": JURY_ASSIGNMENT_DOMAIN,
            "eligible_set_root": _require_non_empty_string(
                eligible_set_root,
                "eligible_set_root_invalid",
            ),
            "node_cid": _require_non_empty_string(node_cid, "node_cid_invalid"),
            "review_epoch": normalized_epoch,
            "review_lane": _require_non_empty_string(review_lane, "review_lane_invalid"),
            "selection_mode": normalized_mode,
        }
    )


def build_assignment_id(assignment_context_hash: str) -> str:
    """Build deterministic assignment ID from the context commitment."""

    normalized_context = _require_sha384_hex(
        assignment_context_hash,
        "assignment_context_hash_invalid",
    )
    digest = _sha384_hex(
        {
            "assignment_context_hash": normalized_context,
            "domain": JURY_ASSIGNMENT_ID_DOMAIN,
        }
    )
    return f"jury_assignment:{digest[:32]}"


def build_jury_assignment_announcement(
    *,
    node_cid: str,
    review_epoch: int,
    review_lane: str,
    eligible_set_root: str,
    algorithm_id: str,
    selection_mode: str,
    announcing_agent_id: str,
    cdl_version: str,
) -> JuryAssignmentAnnouncement:
    """Create the minimal `jury_assignment_announced` push payload."""

    assignment_context_hash = build_assignment_context_hash(
        node_cid=node_cid,
        review_epoch=review_epoch,
        review_lane=review_lane,
        eligible_set_root=eligible_set_root,
        algorithm_id=algorithm_id,
        selection_mode=selection_mode,
    )
    announcement = JuryAssignmentAnnouncement(
        assignment_id=build_assignment_id(assignment_context_hash),
        node_cid=_require_non_empty_string(node_cid, "node_cid_invalid"),
        review_epoch=_require_non_negative_int(review_epoch, "review_epoch_invalid"),
        review_lane=_require_non_empty_string(review_lane, "review_lane_invalid"),
        assignment_context_hash=assignment_context_hash,
        selection_mode=_require_non_empty_string(selection_mode, "selection_mode_invalid"),
        algorithm_id=_require_non_empty_string(algorithm_id, "algorithm_id_invalid"),
        announcing_agent_id=_require_non_empty_string(
            announcing_agent_id,
            "announcing_agent_id_invalid",
        ),
        cdl_version=_require_non_empty_string(cdl_version, "cdl_version_invalid"),
    )
    verify_assignment_announcement_minimality(announcement)
    return announcement


def announcement_canonical_json(announcement: JuryAssignmentAnnouncement) -> str:
    verify_assignment_announcement_minimality(announcement)
    return _canonical_json(announcement.canonical_payload())


def verify_assignment_announcement_minimality(
    announcement: JuryAssignmentAnnouncement | Mapping[str, object],
) -> bool:
    """Reject raw panel/member/task/economic fields in the push payload."""

    if isinstance(announcement, JuryAssignmentAnnouncement):
        payload = announcement.canonical_payload()
    elif isinstance(announcement, Mapping):
        payload = dict(announcement)
    else:
        raise ValueError("jury_assignment_announcement_invalid")

    if set(payload) != ALLOWED_ANNOUNCEMENT_KEYS:
        unexpected = sorted(set(payload).symmetric_difference(ALLOWED_ANNOUNCEMENT_KEYS))
        raise ValueError(f"jury_assignment_announcement_keyset_invalid:{','.join(unexpected)}")
    _assert_no_forbidden_push_keys(payload)
    _require_non_empty_string(payload["assignment_id"], "assignment_id_invalid")
    _require_non_empty_string(payload["node_cid"], "node_cid_invalid")
    _require_non_negative_int(payload["review_epoch"], "review_epoch_invalid")
    _require_non_empty_string(payload["review_lane"], "review_lane_invalid")
    _require_sha384_hex(payload["assignment_context_hash"], "assignment_context_hash_invalid")
    selection_mode = _require_non_empty_string(payload["selection_mode"], "selection_mode_invalid")
    if selection_mode not in ALLOWED_SELECTION_MODES:
        raise ValueError("selection_mode_not_allowed")
    _require_non_empty_string(payload["algorithm_id"], "algorithm_id_invalid")
    _require_non_empty_string(payload["announcing_agent_id"], "announcing_agent_id_invalid")
    _require_non_empty_string(payload["cdl_version"], "cdl_version_invalid")
    _require_non_empty_string(payload["runtime_version"], "runtime_version_invalid")
    return True


def build_jury_assignment_gossip_headers(
    announcement: JuryAssignmentAnnouncement,
) -> dict[str, str]:
    """Build CDL-061-compatible headers for the assignment announcement."""

    verify_assignment_announcement_minimality(announcement)
    headers = gossip_transport.build_gossip_headers(
        gossip_type=JURY_ASSIGNMENT_ANNOUNCED_GOSSIP_TYPE,
        channel=JURY_ASSIGNMENT_GOSSIP_CHANNEL,
        epoch=announcement.review_epoch,
        hop_count=gossip_transport.HOP_COUNT_SINGLE,
        signature=UNSIGNED_GOSSIP_SIGNATURE,
        content_type="application/json",
    )
    gossip_transport.validate_gossip_headers(headers)
    return headers


def compute_self_selection_rank(
    *,
    assignment_context_hash: str,
    agent_id: str,
) -> str:
    """Compute deterministic per-agent selection rank for local self-match."""

    return _sha384_hex(
        {
            "agent_id": _require_non_empty_string(agent_id, "agent_id_invalid"),
            "assignment_context_hash": _require_sha384_hex(
                assignment_context_hash,
                "assignment_context_hash_invalid",
            ),
            "domain": JURY_SELECTION_RANK_DOMAIN,
        }
    )


def select_locally_assigned_reviewers(
    announcement: JuryAssignmentAnnouncement,
    eligible_agent_ids: Sequence[str],
    *,
    panel_size: int = 8,
) -> tuple[str, ...]:
    """Replay top-k deterministic assignment against an eligible-set snapshot."""

    verify_assignment_announcement_minimality(announcement)
    if isinstance(panel_size, bool) or not isinstance(panel_size, int) or panel_size <= 0:
        raise ValueError("panel_size_invalid")

    normalized_ids = sorted(
        {
            _require_non_empty_string(agent_id, "eligible_agent_id_invalid")
            for agent_id in eligible_agent_ids
        }
    )
    if len(normalized_ids) < panel_size:
        raise ValueError("eligible_set_smaller_than_panel_size")

    ranked = sorted(
        normalized_ids,
        key=lambda agent_id: (
            compute_self_selection_rank(
                assignment_context_hash=announcement.assignment_context_hash,
                agent_id=agent_id,
            ),
            agent_id,
        ),
    )
    return tuple(ranked[:panel_size])


def reviewer_matches_assignment(
    announcement: JuryAssignmentAnnouncement,
    *,
    agent_id: str,
    eligible_agent_ids: Sequence[str] | None = None,
    selected_agent_ids: Sequence[str] | None = None,
    panel_size: int = 8,
) -> bool:
    """Return whether a reviewer is assigned by self-selection or pulled quote.

    `selected_agent_ids` is the pull-controlled fallback for the full assignment
    quote. It must not be broadcast in the general announcement path.
    """

    normalized_agent = _require_non_empty_string(agent_id, "agent_id_invalid")
    if selected_agent_ids is not None:
        return normalized_agent in {
            _require_non_empty_string(candidate, "selected_agent_id_invalid")
            for candidate in selected_agent_ids
        }
    if eligible_agent_ids is None:
        raise ValueError("eligible_agent_ids_required_for_self_selection")
    return normalized_agent in select_locally_assigned_reviewers(
        announcement,
        eligible_agent_ids,
        panel_size=panel_size,
    )


def build_reviewer_assignment_ack(
    announcement: JuryAssignmentAnnouncement,
    *,
    agent_id: str,
    signature_boundary_ref: str,
) -> ReviewerAssignmentAck:
    """Build reviewer ack receipt. Acks are not payment or settlement events."""

    verify_assignment_announcement_minimality(announcement)
    normalized_agent = _require_non_empty_string(agent_id, "agent_id_invalid")
    normalized_boundary = _require_non_empty_string(
        signature_boundary_ref,
        "signature_boundary_ref_invalid",
    )
    ack_core = {
        "agent_id": normalized_agent,
        "assignment_context_hash": announcement.assignment_context_hash,
        "assignment_id": announcement.assignment_id,
        "domain": JURY_ASSIGNMENT_ACK_DOMAIN,
        "review_epoch": announcement.review_epoch,
        "review_lane": announcement.review_lane,
        "signature_boundary_ref": normalized_boundary,
    }
    return ReviewerAssignmentAck(
        assignment_id=announcement.assignment_id,
        assignment_context_hash=announcement.assignment_context_hash,
        agent_id=normalized_agent,
        review_epoch=announcement.review_epoch,
        review_lane=announcement.review_lane,
        ack_hash=_sha384_hex(ack_core),
        signature_boundary_ref=normalized_boundary,
        economic_effect=False,
        graph_canon_write_authorized=False,
        reviewer_payment_authorized=False,
        treasury_write_authorized=False,
        wallet_write_authorized=False,
        phase_tokens=PHASE_TOKENS,
    )


def build_missing_review_assignment_request(
    *,
    agent_id: str,
    latest_known_review_epoch: int,
    assignment_cursor: str,
    review_lane: str | None = None,
) -> MissingReviewAssignmentRequest:
    """Build header/cursor request for missed assignment announcements."""

    normalized_lane = (
        None
        if review_lane is None
        else _require_non_empty_string(review_lane, "review_lane_invalid")
    )
    core = {
        "agent_id": _require_non_empty_string(agent_id, "agent_id_invalid"),
        "assignment_cursor": _require_non_empty_string(
            assignment_cursor,
            "assignment_cursor_invalid",
        ),
        "domain": MISSING_REVIEW_ASSIGNMENT_DOMAIN,
        "latest_known_review_epoch": _require_non_negative_int(
            latest_known_review_epoch,
            "latest_known_review_epoch_invalid",
        ),
        "review_lane": normalized_lane,
    }
    return MissingReviewAssignmentRequest(
        request_id=f"missing_review_assignment:{_sha384_hex(core)[:32]}",
        agent_id=str(core["agent_id"]),
        latest_known_review_epoch=int(core["latest_known_review_epoch"]),
        assignment_cursor=str(core["assignment_cursor"]),
        review_lane=normalized_lane,
        recovery_type=MISSING_REVIEW_ASSIGNMENT_GOSSIP_TYPE,
        economic_effect=False,
    )


def _announcement_header(announcement: JuryAssignmentAnnouncement) -> dict[str, object]:
    verify_assignment_announcement_minimality(announcement)
    return {
        "assignment_context_hash": announcement.assignment_context_hash,
        "assignment_id": announcement.assignment_id,
        "node_cid": announcement.node_cid,
        "review_epoch": announcement.review_epoch,
        "review_lane": announcement.review_lane,
        "selection_mode": announcement.selection_mode,
    }


def build_missing_review_assignment_response(
    request: MissingReviewAssignmentRequest,
    announcements: Sequence[JuryAssignmentAnnouncement],
) -> MissingReviewAssignmentResponse:
    """Return only assignment headers/hashes; full payload is pulled separately."""

    if not isinstance(request, MissingReviewAssignmentRequest):
        raise ValueError("missing_review_assignment_request_invalid")
    headers = tuple(_announcement_header(announcement) for announcement in announcements)
    response = MissingReviewAssignmentResponse(
        request_id=request.request_id,
        assignment_headers=headers,
        full_payload_included=False,
        economic_effect=False,
    )
    _assert_no_forbidden_push_keys(response.canonical_payload())
    return response


def classify_non_response_liveness(
    announcement: JuryAssignmentAnnouncement,
    *,
    agent_id: str,
) -> NonResponseLivenessEvidence:
    """Classify non-response as liveness evidence only, with no penalty effect."""

    verify_assignment_announcement_minimality(announcement)
    normalized_agent = _require_non_empty_string(agent_id, "agent_id_invalid")
    evidence_core = {
        "agent_id": normalized_agent,
        "assignment_id": announcement.assignment_id,
        "domain": "ILC_JURY_NON_RESPONSE_LIVENESS_V1",
        "review_epoch": announcement.review_epoch,
    }
    return NonResponseLivenessEvidence(
        assignment_id=announcement.assignment_id,
        agent_id=normalized_agent,
        review_epoch=announcement.review_epoch,
        evidence_hash=_sha384_hex(evidence_core),
        liveness_only=True,
        ecu_burn_authorized=False,
        slash_authorized=False,
        wallet_debit_authorized=False,
        treasury_event_authorized=False,
        settlement_authorized=False,
    )
