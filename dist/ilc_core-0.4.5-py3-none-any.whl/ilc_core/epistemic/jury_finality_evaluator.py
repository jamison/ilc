# SPDX-License-Identifier: AGPL-3.0-only
# PUBLIC_RC_EXCLUDE: phase_1494p_cdl095_jury_finality_evaluator
# cdl_095_runtime_completions_committed_phase_1494p
# cdl_095_jury_finality_runtime_complete_phase_1494p
# jury_finality_evaluator_not_production_phase_1494p
"""CDL-095 jury verdict finality evaluator.

Evaluates whether a jury verdict has reached local finality under CDL-095
rules. Production use requires JURY_FINALITY_EVALUATOR_NOT_PRODUCTION to be
cleared by separate explicit authority.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Final, Mapping, Any

from ilc_core.schema.verdict_record_schema import VerdictRecord

JURY_FINALITY_EVALUATOR_NOT_PRODUCTION: Final[bool] = True
CDL_095_DEPENDENCY: Final[str] = "cdl_095_ratified_phase_1448c"
CDL_095_JURY_VERDICT_FINALITY_VERSION: Final[str] = "cdl_095_jury_verdict_finality_v0.1"
CDL_095_JURY_FINALITY_EVALUATOR_VERSION: Final[str] = (
    "cdl_095_jury_finality_evaluator_1494p.v0.1"
)

JURY_VERDICT_APPROVE_NUMERATOR: Final[int] = 2
JURY_VERDICT_APPROVE_DENOMINATOR: Final[int] = 3
JURY_VERDICT_REGULAR_REVIEWERS: Final[int] = 7
JURY_VERDICT_PARTICIPATION_FLOOR: Final[int] = 5
JURY_ABSTAIN_EARNS_BASE_FEE: Final[bool] = True
JURY_ABSTAIN_EARNS_ACCURACY_BONUS: Final[bool] = False
JURY_AUTO_ESCALATION_HIGH_STAKES_TAG: Final[str] = "HIGH_STAKES"
JURY_GLOBAL_TIER_ACTIVATION_STATUS: Final[str] = "deferred_to_cdl_096"
JURY_SHARD_ACTIVATION_STATUS: Final[str] = "ratified_not_activated"


@dataclass(frozen=True)
class FinalityVerdict:
    """Local CDL-095 finality result. Shard/global escalation is not executed."""

    is_final: bool
    quorum_satisfied: bool
    escalation_eligible: bool
    reason: str


def _require_finite_decimal(value: Decimal) -> Decimal:
    if not isinstance(value, Decimal):
        raise ValueError("invalid_amount_not_decimal")
    if not value.is_finite():
        raise ValueError("invalid_amount_non_finite")
    return value


def _coerce_verdict_record(verdict_record: VerdictRecord | Mapping[str, Any]) -> VerdictRecord:
    if isinstance(verdict_record, VerdictRecord):
        return verdict_record
    if isinstance(verdict_record, Mapping):
        return VerdictRecord(**dict(verdict_record))
    raise ValueError("jury_verdict_record_invalid")


def _supporting_votes(record: VerdictRecord) -> int:
    if record.verdict in {"upheld", "approved"}:
        return record.approve_votes
    if record.verdict in {"overturned", "rejected"}:
        return record.reject_votes
    return 0


def _threshold_satisfied(record: VerdictRecord) -> bool:
    if record.total_votes <= 0:
        return False
    return (
        _supporting_votes(record) * JURY_VERDICT_APPROVE_DENOMINATOR
        >= record.total_votes * JURY_VERDICT_APPROVE_NUMERATOR
    )


def _escalation_eligible(record: VerdictRecord) -> bool:
    return (
        record.verdict == "escalated"
        or record.high_stakes
        or not record.diversity_floor_satisfied
    )


def evaluate_finality(
    verdict_record: VerdictRecord | Mapping[str, Any],
    *,
    test_mode: bool = False,
) -> FinalityVerdict:
    """Evaluate local jury verdict finality under CDL-095.

    This is intentionally local-tier only. CDL-095 ratified shard-tier shape
    but did not activate shard-tier selection; global tier remains deferred to
    CDL-096.
    """

    if JURY_FINALITY_EVALUATOR_NOT_PRODUCTION and not test_mode:
        raise NotImplementedError("jury_finality_evaluator_not_production")

    record = _coerce_verdict_record(verdict_record)
    _require_finite_decimal(record.ecus_at_stake)

    quorum_satisfied = (
        record.regular_reviewer_count == JURY_VERDICT_REGULAR_REVIEWERS
        and record.quorum_count >= JURY_VERDICT_PARTICIPATION_FLOOR
        and record.total_votes >= JURY_VERDICT_PARTICIPATION_FLOOR
    )
    threshold_satisfied = _threshold_satisfied(record)
    escalation_eligible = _escalation_eligible(record)

    if not quorum_satisfied:
        return FinalityVerdict(
            is_final=False,
            quorum_satisfied=False,
            escalation_eligible=escalation_eligible,
            reason="jury_quorum_not_satisfied",
        )
    if record.verdict == "escalated":
        return FinalityVerdict(
            is_final=False,
            quorum_satisfied=True,
            escalation_eligible=True,
            reason="jury_verdict_escalated",
        )
    if not threshold_satisfied:
        return FinalityVerdict(
            is_final=False,
            quorum_satisfied=True,
            escalation_eligible=escalation_eligible,
            reason="jury_threshold_not_satisfied",
        )
    if not record.diversity_floor_satisfied:
        return FinalityVerdict(
            is_final=False,
            quorum_satisfied=True,
            escalation_eligible=True,
            reason="jury_diversity_floor_not_satisfied",
        )

    return FinalityVerdict(
        is_final=True,
        quorum_satisfied=True,
        escalation_eligible=escalation_eligible,
        reason="jury_local_finality_satisfied",
    )


def evaluate_jury_verdict_finality(
    verdict_record: VerdictRecord | Mapping[str, Any],
    *,
    test_mode: bool = False,
) -> FinalityVerdict:
    """Compatibility alias using the CDL-095 ratification evidence name."""

    return evaluate_finality(verdict_record, test_mode=test_mode)
