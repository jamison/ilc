# PUBLIC_RC_EXCLUDE: pq_agent_sign_bridge
# PUBLIC_RC_EXCLUDE_REASON: Private rehearsal signing bridge. No public endpoint.
# PRIVATE_REHEARSAL_ONLY: Phase 1568-Fix2k local signer bridge.
"""Bridge from Python rehearsal tooling to the Rust ``pq_agent_sign`` binary.

The bridge never accepts seed material as an argument or environment variable.
It reads the operator seed through a TTY-hidden prompt and pipes it directly to
the Rust signer, which validates the derived public key against the Phase 1431
manifest before emitting a signature.
"""

from __future__ import annotations

import os
import getpass
import subprocess
import sys
import tempfile
from pathlib import Path


_REPO_ROOT = Path(__file__).resolve().parents[2]
_DEFAULT_BINARY = _REPO_ROOT / "ilc_consensus" / "target" / "release" / "pq_agent_sign"
_DEFAULT_MANIFEST = _REPO_ROOT / "docs" / "specs" / "ilc_rehearsal_agent_identity_manifest_1431_v0.1.md"
_DEFAULT_SEED_RETRY_LIMIT = 3
_SIGNER_TIMEOUT_SECONDS = 60
_PROCESS_SEED_CACHE_ENV = "ILC_PQ_AGENT_SIGN_PROCESS_SEED_CACHE"
_PROCESS_SEED_CACHE: dict[str, str] = {}


def _agent_loop_error(token: str, message: str) -> Exception:
    from tools.agent_loop_v1 import AgentLoopRuntimeError

    return AgentLoopRuntimeError(token, message)


def _process_seed_cache_enabled() -> bool:
    return os.environ.get(_PROCESS_SEED_CACHE_ENV) == "1"


def clear_process_seed_cache() -> None:
    """Drop rehearsal seed material cached in this Python process."""

    _PROCESS_SEED_CACHE.clear()


def _read_seed_hidden(agent_id_hex: str) -> str:
    """Read seed material without terminal echo and return stdin text for signer."""

    if not sys.stdin.isatty():
        raise _agent_loop_error(
            "pq_agent_sign_seed_tty_required",
            "ML-DSA seed entry requires an interactive TTY; refusing echoed or piped input",
        )
    prompt = (
        "Enter ML-DSA-65 mldsa_seed for agent "
        f"{agent_id_hex[:8]}... (input hidden; press Enter): "
    )
    try:
        seed_text = getpass.getpass(prompt=prompt, stream=sys.stderr)
    except (EOFError, KeyboardInterrupt) as exc:
        raise _agent_loop_error("pq_agent_sign_seed_entry_aborted", "ML-DSA seed entry aborted") from exc
    if not seed_text.strip():
        raise _agent_loop_error("pq_agent_sign_seed_empty", "ML-DSA seed entry was empty")
    return seed_text.strip() + "\n"


def _sanitize_signer_stderr(stderr: str) -> str:
    lines = []
    for line in stderr.splitlines():
        if line.startswith("Enter ML-DSA-65 mldsa_seed for agent "):
            continue
        lines.append(line.replace("then press Ctrl-D", "then retry at the hidden prompt"))
    return "\n".join(lines).strip()


def _is_retryable_seed_error(stderr: str) -> bool:
    normalized = _sanitize_signer_stderr(stderr).lower()
    retry_tokens = (
        "invalid bip-39 mnemonic",
        "mnemonic contains",
        "seed_hex",
        "seed hex",
        "hex_input_odd_length",
        "invalid_hex_character",
        "hex_seed_must_be_32_bytes",
        "mnemonic_entropy_must_be_32_bytes",
        "derived_mldsa_public_key_does_not_match_manifest_record",
    )
    return any(token in normalized for token in retry_tokens)


def sign_agent_submission(
    *,
    agent_id_hex: str,
    payload_bytes: bytes,
    binary_path: str | None = None,
    manifest_path: str | None = None,
) -> str:
    """Sign agent submission payload bytes with ``pq_agent_sign``.

    Security contract:
    - Seed material is read from stdin only by the Rust binary.
    - Seed material is never accepted by this function.
    - Payload bytes are written only to a temporary file outside the repo.
    - The Rust binary verifies the derived public key against the Phase 1431
      manifest before producing a signature.
    """

    if not isinstance(agent_id_hex, str) or not agent_id_hex:
        raise _agent_loop_error("pq_agent_sign_agent_id_required", "agent_id_hex is required")
    if not isinstance(payload_bytes, bytes):
        raise _agent_loop_error("pq_agent_sign_payload_bytes_required", "payload_bytes must be bytes")

    signer = Path(binary_path) if binary_path is not None else _DEFAULT_BINARY
    manifest = Path(manifest_path) if manifest_path is not None else _DEFAULT_MANIFEST
    if not signer.is_file():
        raise _agent_loop_error("pq_agent_sign_binary_missing", f"pq_agent_sign binary missing: {signer}")
    if not manifest.is_file():
        raise _agent_loop_error("pq_agent_sign_manifest_missing", f"manifest missing: {manifest}")

    fd, tmp_path = tempfile.mkstemp(prefix="ilc-agent-sign-", suffix=".json")
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload_bytes)
        result: subprocess.CompletedProcess[str] | None = None
        last_detail = "pq_agent_sign failed without stderr"
        cache_enabled = _process_seed_cache_enabled()

        def run_signer(seed_stdin: str) -> subprocess.CompletedProcess[str]:
            try:
                return subprocess.run(
                    [
                        str(signer),
                        "--agent-id",
                        agent_id_hex,
                        "--input-file",
                        tmp_path,
                        "--manifest",
                        str(manifest),
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    input=seed_stdin,
                    text=True,
                    check=False,
                    timeout=_SIGNER_TIMEOUT_SECONDS,
                )
            except OSError as exc:
                raise _agent_loop_error("pq_agent_sign_bridge_failed", str(exc)) from exc
            except subprocess.TimeoutExpired as exc:
                _PROCESS_SEED_CACHE.pop(agent_id_hex, None)
                raise _agent_loop_error(
                    "pq_agent_sign_bridge_timeout",
                    f"pq_agent_sign exceeded {_SIGNER_TIMEOUT_SECONDS}s timeout",
                ) from exc

        if cache_enabled and agent_id_hex in _PROCESS_SEED_CACHE:
            result = run_signer(_PROCESS_SEED_CACHE[agent_id_hex])
            if result.returncode != 0:
                last_detail = _sanitize_signer_stderr(result.stderr) or "pq_agent_sign failed without stderr"
                if _is_retryable_seed_error(result.stderr):
                    _PROCESS_SEED_CACHE.pop(agent_id_hex, None)
                    result = None
                else:
                    raise _agent_loop_error("pq_agent_sign_bridge_failed", last_detail)

        for attempt in range(1, _DEFAULT_SEED_RETRY_LIMIT + 1):
            if result is not None and result.returncode == 0:
                break
            seed_stdin = _read_seed_hidden(agent_id_hex)
            result = run_signer(seed_stdin)
            if result.returncode == 0:
                if cache_enabled:
                    _PROCESS_SEED_CACHE[agent_id_hex] = seed_stdin
                break
            last_detail = _sanitize_signer_stderr(result.stderr) or "pq_agent_sign failed without stderr"
            if not _is_retryable_seed_error(result.stderr) or attempt >= _DEFAULT_SEED_RETRY_LIMIT:
                break
            print(
                "ML-DSA seed rejected for agent "
                f"{agent_id_hex[:8]}... ({attempt}/{_DEFAULT_SEED_RETRY_LIMIT}); retrying.",
                file=sys.stderr,
                flush=True,
            )
    finally:
        try:
            os.unlink(tmp_path)
        except FileNotFoundError:
            pass

    if result is None or result.returncode != 0:
        raise _agent_loop_error("pq_agent_sign_bridge_failed", last_detail)

    signature_hex = result.stdout.strip().lower()
    if not signature_hex:
        raise _agent_loop_error("pq_agent_sign_empty_signature", "pq_agent_sign returned an empty signature")
    if len(signature_hex) != 3309 * 2 or any(char not in "0123456789abcdef" for char in signature_hex):
        raise _agent_loop_error("pq_agent_sign_signature_hex_invalid", "pq_agent_sign returned invalid signature hex")
    return signature_hex
