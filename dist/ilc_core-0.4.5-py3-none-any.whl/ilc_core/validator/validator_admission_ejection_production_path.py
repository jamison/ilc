# SPDX-License-Identifier: AGPL-3.0-only
"""Phase 1539p default-off validator admission/ejection production path.

This module wraps the existing CDL-017 admission/ejection quote runtime in a
production-capable but non-activating transition surface. It does not mutate a
live validator set, write stake state, deploy validators, or activate production
validator admission.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, fields, is_dataclass
from typing import Any, Mapping

from ilc_core.validator.admission_ejection_runtime import (
    CDL_017_DEPENDENCY,
    ValidatorAdmissionDecision,
    ValidatorEjectionDecision,
    admit_validator,
    eject_validator,
)


VALIDATOR_ADMISSION_NOT_ACTIVATED = True
VALIDATOR_ADMISSION_EJECTION_PRODUCTION_PATH_VERSION = (
    "validator_admission_ejection_production_path_1539p.v0.1"
)
VALIDATOR_ADMISSION_NOT_ACTIVATED_TOKEN = (
    "production_validator_admission_not_activated_phase_1539p"
)
SETTLEMENT_ROOT_SCHEMA_VERSION = (
    "validator_admission_ejection_event_batch_root_1539p.v0.1"
)
CANONICAL_VALIDATOR_SET_TRANSITION_EVENT_SCHEMA_VERSION = (
    "canonical_validator_set_transition_event_1539p.v0.1"
)


@dataclass(frozen=True)
class ValidatorSetTransitionResult:
    runtime_version: str
    cdl_017_dependency: str
    transition_context: str
    admission_decision: ValidatorAdmissionDecision
    ejection_decision: ValidatorEjectionDecision
    production_validator_admission_activated: bool
    guard_token: str

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "admission_decision": self.admission_decision.to_canonical_record(),
            "cdl_017_dependency": self.cdl_017_dependency,
            "ejection_decision": self.ejection_decision.to_canonical_record(),
            "guard_token": self.guard_token,
            "production_validator_admission_activated": (
                self.production_validator_admission_activated
            ),
            "runtime_version": self.runtime_version,
            "transition_context": self.transition_context,
        }


@dataclass(frozen=True)
class ValidatorTransitionSettlementRoot:
    issuance_epoch_or_context: str
    canonical_record_json: str
    root_hex: str
    root_algorithm: str = "sha256_over_canonical_json"

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "canonical_record_json": self.canonical_record_json,
            "issuance_epoch_or_context": self.issuance_epoch_or_context,
            "root_algorithm": self.root_algorithm,
            "root_hex": self.root_hex,
        }


@dataclass(frozen=True)
class CanonicalValidatorSetTransitionEvent:
    event_type: str
    transition_context: str
    validator_id: int
    agent_id: str | None
    exit_reason: str | None
    current_agent_ids: tuple[str, ...]
    next_agent_ids: tuple[str, ...]
    current_validator_ids: tuple[int, ...]
    next_validator_ids: tuple[int, ...]
    trust_tier_consecutive_missed_epochs: int | None
    trust_tier_equivocation_state: bool | None
    decision_token: str
    action_token: str
    cdl_017_dependency: str
    production_validator_admission_activated: bool
    settlement_root_hex: str
    schema_version: str = CANONICAL_VALIDATOR_SET_TRANSITION_EVENT_SCHEMA_VERSION

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "action_token": self.action_token,
            "agent_id": self.agent_id,
            "cdl_017_dependency": self.cdl_017_dependency,
            "current_agent_ids": list(self.current_agent_ids),
            "current_validator_ids": list(self.current_validator_ids),
            "decision_token": self.decision_token,
            "event_type": self.event_type,
            "exit_reason": self.exit_reason,
            "next_agent_ids": list(self.next_agent_ids),
            "next_validator_ids": list(self.next_validator_ids),
            "production_validator_admission_activated": (
                self.production_validator_admission_activated
            ),
            "schema_version": self.schema_version,
            "settlement_root_hex": self.settlement_root_hex,
            "transition_context": self.transition_context,
            "trust_tier_consecutive_missed_epochs": (
                self.trust_tier_consecutive_missed_epochs
            ),
            "trust_tier_equivocation_state": self.trust_tier_equivocation_state,
            "validator_id": self.validator_id,
        }

    def to_canonical_json(self) -> str:
        return _canonical_json_allowing_root(self.to_canonical_record())


def require_validator_admission_production_activation() -> None:
    raise NotImplementedError(VALIDATOR_ADMISSION_NOT_ACTIVATED_TOKEN)


def _reject_non_json_exact_values(value: Any) -> None:
    if isinstance(value, float):
        raise ValueError("float_in_validator_transition_record_rejected")
    if is_dataclass(value) and not isinstance(value, type):
        for field in fields(value):
            _reject_non_json_exact_values(getattr(value, field.name))
        return
    if isinstance(value, dict):
        for key, item in value.items():
            _reject_non_json_exact_values(key)
            _reject_non_json_exact_values(item)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            _reject_non_json_exact_values(item)


def _reject_settlement_root_key(value: Any) -> None:
    if isinstance(value, dict):
        if "settlement_root_hex" in value:
            raise ValueError("settlement_root_hex_must_be_excluded_from_root_payload")
        for item in value.values():
            _reject_settlement_root_key(item)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            _reject_settlement_root_key(item)


def _canonical_json(payload: dict[str, Any]) -> str:
    _reject_non_json_exact_values(payload)
    _reject_settlement_root_key(payload)
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
        ensure_ascii=True,
    )


def _canonical_json_allowing_root(payload: dict[str, Any]) -> str:
    _reject_non_json_exact_values(payload)
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
        ensure_ascii=True,
    )


def _require_mapping(value: Mapping[str, object] | dict[str, object], field_name: str) -> dict[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field_name}_must_be_mapping")
    return dict(value)


def _transition_context(
    admission_decision: ValidatorAdmissionDecision,
    ejection_decision: ValidatorEjectionDecision,
) -> str:
    return (
        "validator_set_transition:"
        f"admit_{admission_decision.validator_id}_epoch_{admission_decision.active_from_epoch}:"
        f"eject_{ejection_decision.validator_id}_epoch_{ejection_decision.active_from_epoch}"
    )


def build_validator_set_transition_result(
    admit_inputs: Mapping[str, object] | dict[str, object],
    eject_inputs: Mapping[str, object] | dict[str, object],
) -> ValidatorSetTransitionResult:
    if not VALIDATOR_ADMISSION_NOT_ACTIVATED:
        raise ValueError("validator_admission_guard_cleared_without_activation_authority_phase_1539p")

    admission_decision = admit_validator(**_require_mapping(admit_inputs, "admit_inputs"))
    ejection_decision = eject_validator(**_require_mapping(eject_inputs, "eject_inputs"))
    context = _transition_context(admission_decision, ejection_decision)
    return ValidatorSetTransitionResult(
        runtime_version=VALIDATOR_ADMISSION_EJECTION_PRODUCTION_PATH_VERSION,
        cdl_017_dependency=CDL_017_DEPENDENCY,
        transition_context=context,
        admission_decision=admission_decision,
        ejection_decision=ejection_decision,
        production_validator_admission_activated=False,
        guard_token=VALIDATOR_ADMISSION_NOT_ACTIVATED_TOKEN,
    )


def build_canonical_validator_set_transition_event_payloads(
    result: ValidatorSetTransitionResult,
) -> list[dict[str, object]]:
    if not isinstance(result, ValidatorSetTransitionResult):
        raise ValueError("validator_set_transition_result_required")
    _reject_non_json_exact_values(result)

    admission = result.admission_decision
    ejection = result.ejection_decision
    return [
        {
            "action_token": admission.admission_token,
            "agent_id": admission.agent_id,
            "cdl_017_dependency": result.cdl_017_dependency,
            "current_agent_ids": list(admission.current_agent_ids),
            "current_validator_ids": list(admission.current_validator_ids),
            "decision_token": admission.decision_token,
            "event_type": "validator_admission",
            "exit_reason": None,
            "next_agent_ids": list(admission.next_agent_ids),
            "next_validator_ids": list(admission.next_validator_ids),
            "production_validator_admission_activated": (
                result.production_validator_admission_activated
            ),
            "schema_version": CANONICAL_VALIDATOR_SET_TRANSITION_EVENT_SCHEMA_VERSION,
            "transition_context": result.transition_context,
            "trust_tier_consecutive_missed_epochs": (
                admission.trust_tier_consecutive_missed_epochs
            ),
            "trust_tier_equivocation_state": admission.trust_tier_equivocation_state,
            "validator_id": admission.validator_id,
        },
        {
            "action_token": ejection.ejection_token,
            "agent_id": None,
            "cdl_017_dependency": result.cdl_017_dependency,
            "current_agent_ids": [],
            "current_validator_ids": list(ejection.current_validator_ids),
            "decision_token": ejection.decision_token,
            "event_type": "validator_ejection",
            "exit_reason": ejection.exit_reason,
            "next_agent_ids": [],
            "next_validator_ids": list(ejection.next_validator_ids),
            "production_validator_admission_activated": (
                result.production_validator_admission_activated
            ),
            "schema_version": CANONICAL_VALIDATOR_SET_TRANSITION_EVENT_SCHEMA_VERSION,
            "transition_context": result.transition_context,
            "trust_tier_consecutive_missed_epochs": None,
            "trust_tier_equivocation_state": None,
            "validator_id": ejection.validator_id,
        },
    ]


def compute_validator_transition_settlement_root(
    result: ValidatorSetTransitionResult,
) -> ValidatorTransitionSettlementRoot:
    if not isinstance(result, ValidatorSetTransitionResult):
        raise ValueError("validator_set_transition_result_required")
    _reject_non_json_exact_values(result)

    payload = {
        "cdl_017_dependency": result.cdl_017_dependency,
        "event_payloads": build_canonical_validator_set_transition_event_payloads(result),
        "guard_token": result.guard_token,
        "production_validator_admission_activated": (
            result.production_validator_admission_activated
        ),
        "runtime_version": result.runtime_version,
        "schema_version": SETTLEMENT_ROOT_SCHEMA_VERSION,
        "transition_context": result.transition_context,
    }
    canonical_record_json = _canonical_json(payload)
    root_hex = hashlib.sha256(canonical_record_json.encode("utf-8")).hexdigest()
    return ValidatorTransitionSettlementRoot(
        issuance_epoch_or_context=result.transition_context,
        canonical_record_json=canonical_record_json,
        root_hex=root_hex,
    )


def emit_canonical_validator_set_transition_events(
    result: ValidatorSetTransitionResult,
    settlement_root: ValidatorTransitionSettlementRoot,
) -> list[CanonicalValidatorSetTransitionEvent]:
    if not isinstance(result, ValidatorSetTransitionResult):
        raise ValueError("validator_set_transition_result_required")
    if not isinstance(settlement_root, ValidatorTransitionSettlementRoot):
        raise ValueError("validator_transition_settlement_root_required")

    root_payload = json.loads(settlement_root.canonical_record_json)
    event_payloads = build_canonical_validator_set_transition_event_payloads(result)
    if root_payload.get("event_payloads") != event_payloads:
        raise ValueError("settlement_root_event_payload_mismatch")
    if root_payload.get("transition_context") != result.transition_context:
        raise ValueError("settlement_root_transition_context_mismatch")

    return [
        CanonicalValidatorSetTransitionEvent(
            event_type=str(payload["event_type"]),
            transition_context=str(payload["transition_context"]),
            validator_id=int(payload["validator_id"]),
            agent_id=payload["agent_id"] if isinstance(payload["agent_id"], str) else None,
            exit_reason=(
                payload["exit_reason"] if isinstance(payload["exit_reason"], str) else None
            ),
            current_agent_ids=tuple(str(value) for value in payload["current_agent_ids"]),
            next_agent_ids=tuple(str(value) for value in payload["next_agent_ids"]),
            current_validator_ids=tuple(int(value) for value in payload["current_validator_ids"]),
            next_validator_ids=tuple(int(value) for value in payload["next_validator_ids"]),
            trust_tier_consecutive_missed_epochs=(
                int(payload["trust_tier_consecutive_missed_epochs"])
                if payload["trust_tier_consecutive_missed_epochs"] is not None
                else None
            ),
            trust_tier_equivocation_state=(
                bool(payload["trust_tier_equivocation_state"])
                if payload["trust_tier_equivocation_state"] is not None
                else None
            ),
            decision_token=str(payload["decision_token"]),
            action_token=str(payload["action_token"]),
            cdl_017_dependency=str(payload["cdl_017_dependency"]),
            production_validator_admission_activated=bool(
                payload["production_validator_admission_activated"]
            ),
            settlement_root_hex=settlement_root.root_hex,
        )
        for payload in event_payloads
    ]


__all__ = [
    "CANONICAL_VALIDATOR_SET_TRANSITION_EVENT_SCHEMA_VERSION",
    "CDL_017_DEPENDENCY",
    "SETTLEMENT_ROOT_SCHEMA_VERSION",
    "VALIDATOR_ADMISSION_EJECTION_PRODUCTION_PATH_VERSION",
    "VALIDATOR_ADMISSION_NOT_ACTIVATED",
    "VALIDATOR_ADMISSION_NOT_ACTIVATED_TOKEN",
    "CanonicalValidatorSetTransitionEvent",
    "ValidatorSetTransitionResult",
    "ValidatorTransitionSettlementRoot",
    "build_canonical_validator_set_transition_event_payloads",
    "build_validator_set_transition_result",
    "compute_validator_transition_settlement_root",
    "emit_canonical_validator_set_transition_events",
    "require_validator_admission_production_activation",
]
