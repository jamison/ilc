# SPDX-License-Identifier: AGPL-3.0-only
"""Productive ECU Expansion Bounty Scaffold — Phase 1542p (OBL-027).

ADR-0016 is Proposed. This module implements the accounting path for
protocol-issued bounties only. Peer-funded bounties and funding requests are
OBL-029 / Block 5 scope. Panel assignment requires full CDL-V3/CDL-V7
governance activation which is not authorized by this module.

Guard: PRODUCTIVE_ECU_EXPANSION_NOT_ACTIVATED = True
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, fields, is_dataclass
from decimal import Decimal, InvalidOperation, ROUND_DOWN
from typing import Any

from ilc_core.epoch.treasury_governance_runtime import (
    BOUNTY_CAP_FRACTION_OF_EPOCH_BUDGET as CDL_047_BOUNTY_CAP_FRACTION,
)


PRODUCTIVE_ECU_EXPANSION_NOT_ACTIVATED = True
PRODUCTIVE_ECU_EXPANSION_NOT_ACTIVATED_TOKEN = (
    "productive_ecu_expansion_not_activated_phase_1542p"
)
PRODUCTIVE_ECU_EXPANSION_BOUNTY_RUNTIME_VERSION = (
    "productive_ecu_expansion_bounty_runtime_1542p.v0.1"
)
SETTLEMENT_ROOT_SCHEMA_VERSION = "bounty_accounting_event_batch_root_1542p.v0.1"
CANONICAL_BOUNTY_ACCOUNTING_EVENT_SCHEMA_VERSION = (
    "canonical_bounty_accounting_event_1542p.v0.1"
)
ADR_0016_STATUS_PROPOSED = (
    "adr_0016_status_proposed_bounty_activation_requires_governance_event"
)
BOUNTY_CAP_FRACTION_OF_EPOCH_BUDGET = Decimal("0.15")
BOUNTY_ACCOUNTING_QUANTUM = Decimal("0.000000001")
BOUNTY_PANEL_ASSIGNMENT_NOT_IMPLEMENTED = (
    "adr_0016_panel_assignment_not_implemented_phase_1542p"
)
PEER_FUNDED_BOUNTIES_EXCLUDED_TOKEN = "peer_funded_bounties_excluded_obl_029_block5"

if BOUNTY_CAP_FRACTION_OF_EPOCH_BUDGET != CDL_047_BOUNTY_CAP_FRACTION:
    raise ValueError("bounty_cap_fraction_must_match_cdl_047")


@dataclass(frozen=True)
class BountyIssuanceQuote:
    runtime_version: str
    adr_0016_status: str
    epoch_budget_ecu: Decimal
    requested_ecu: Decimal
    cap_ecu: Decimal
    approved_ecu: Decimal
    cap_fraction_of_epoch_budget: Decimal
    cap_fraction_applied: bool
    production_bounty_activated: bool
    no_debt_rule_token: str
    guard_token: str

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "adr_0016_status": self.adr_0016_status,
            "approved_ecu_str": _decimal_to_string(self.approved_ecu),
            "cap_ecu_str": _decimal_to_string(self.cap_ecu),
            "cap_fraction_applied": self.cap_fraction_applied,
            "cap_fraction_of_epoch_budget": _decimal_to_string(
                self.cap_fraction_of_epoch_budget
            ),
            "epoch_budget_ecu_str": _decimal_to_string(self.epoch_budget_ecu),
            "guard_token": self.guard_token,
            "no_debt_rule_token": self.no_debt_rule_token,
            "production_bounty_activated": self.production_bounty_activated,
            "requested_ecu_str": _decimal_to_string(self.requested_ecu),
            "runtime_version": self.runtime_version,
        }


@dataclass(frozen=True)
class BountyDeliveryStub:
    bounty_id: str
    panel_assignment_result: str
    cdl_v3_diversity_requirement_recorded: bool
    cdl_v7_popperian_gate_requirement_recorded: bool
    peer_funded_bounty_excluded: bool
    adr_0016_status: str
    production_bounty_activated: bool

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "adr_0016_status": self.adr_0016_status,
            "bounty_id": self.bounty_id,
            "cdl_v3_diversity_requirement_recorded": (
                self.cdl_v3_diversity_requirement_recorded
            ),
            "cdl_v7_popperian_gate_requirement_recorded": (
                self.cdl_v7_popperian_gate_requirement_recorded
            ),
            "panel_assignment_result": self.panel_assignment_result,
            "peer_funded_bounty_excluded": self.peer_funded_bounty_excluded,
            "production_bounty_activated": self.production_bounty_activated,
        }


@dataclass(frozen=True)
class BountyAccountingSettlementRoot:
    context: str
    canonical_record_json: str
    root_hex: str
    root_algorithm: str = "sha256_over_canonical_json"

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "canonical_record_json": self.canonical_record_json,
            "context": self.context,
            "root_algorithm": self.root_algorithm,
            "root_hex": self.root_hex,
        }


@dataclass(frozen=True)
class CanonicalBountyAccountingEvent:
    event_type: str
    bounty_id: str
    approved_ecu_str: str
    requested_ecu_str: str
    cap_ecu_str: str
    cap_fraction_applied: bool
    panel_assignment_result: str
    adr_0016_status: str
    production_activated: bool
    peer_funded_bounty_excluded: bool
    settlement_root_hex: str
    schema_version: str = CANONICAL_BOUNTY_ACCOUNTING_EVENT_SCHEMA_VERSION

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "adr_0016_status": self.adr_0016_status,
            "approved_ecu_str": self.approved_ecu_str,
            "bounty_id": self.bounty_id,
            "cap_ecu_str": self.cap_ecu_str,
            "cap_fraction_applied": self.cap_fraction_applied,
            "event_type": self.event_type,
            "panel_assignment_result": self.panel_assignment_result,
            "peer_funded_bounty_excluded": self.peer_funded_bounty_excluded,
            "production_activated": self.production_activated,
            "requested_ecu_str": self.requested_ecu_str,
            "schema_version": self.schema_version,
            "settlement_root_hex": self.settlement_root_hex,
        }

    def to_canonical_json(self) -> str:
        return _canonical_json_allowing_root(self.to_canonical_record())


def require_productive_ecu_expansion_activation() -> None:
    raise NotImplementedError(PRODUCTIVE_ECU_EXPANSION_NOT_ACTIVATED_TOKEN)


def _reject_non_json_exact_values(value: Any) -> None:
    if isinstance(value, float):
        raise ValueError("float_in_bounty_accounting_record_rejected")
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError("invalid_amount_non_finite")
        return
    if is_dataclass(value) and not isinstance(value, type):
        for field in fields(value):
            _reject_non_json_exact_values(getattr(value, field.name))
        return
    if isinstance(value, dict):
        for key, item in value.items():
            _reject_non_json_exact_values(key)
            _reject_non_json_exact_values(item)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            _reject_non_json_exact_values(item)


def _reject_settlement_root_key(value: Any) -> None:
    if isinstance(value, dict):
        if "settlement_root_hex" in value:
            raise ValueError("settlement_root_hex_must_be_excluded_from_root_payload")
        for item in value.values():
            _reject_settlement_root_key(item)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            _reject_settlement_root_key(item)


def _canonical_json(payload: dict[str, Any]) -> str:
    _reject_non_json_exact_values(payload)
    _reject_settlement_root_key(payload)
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
        ensure_ascii=True,
    )


def _canonical_json_allowing_root(payload: dict[str, Any]) -> str:
    _reject_non_json_exact_values(payload)
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
        ensure_ascii=True,
    )


def _require_decimal_amount(value: object, field_name: str) -> Decimal:
    if isinstance(value, bool) or isinstance(value, float):
        raise ValueError(f"{field_name}_must_be_exact_decimal")
    if not isinstance(value, (Decimal, int, str)):
        raise ValueError(f"{field_name}_must_be_exact_decimal")
    try:
        amount = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"{field_name}_must_be_exact_decimal") from exc
    if not amount.is_finite():
        raise ValueError("invalid_amount_non_finite")
    if amount < Decimal("0"):
        raise ValueError(f"{field_name}_must_be_non_negative")
    return amount.quantize(BOUNTY_ACCOUNTING_QUANTUM, rounding=ROUND_DOWN)


def _decimal_to_string(value: Decimal) -> str:
    if not isinstance(value, Decimal):
        raise ValueError("amount_must_be_decimal")
    if not value.is_finite():
        raise ValueError("invalid_amount_non_finite")
    if value < Decimal("0"):
        raise ValueError("amount_must_be_non_negative")
    return format(value.normalize(), "f")


def _require_bounty_id(value: object) -> str:
    if not isinstance(value, str) or value == "":
        raise ValueError("bounty_id_must_be_non_empty_string")
    return value


def build_bounty_issuance_quote(
    epoch_budget_ecu: Decimal | int | str,
    requested_bounty_ecu: Decimal | int | str,
) -> BountyIssuanceQuote:
    if not PRODUCTIVE_ECU_EXPANSION_NOT_ACTIVATED:
        raise ValueError(
            "productive_ecu_expansion_guard_cleared_without_activation_authority_phase_1542p"
        )

    epoch_budget = _require_decimal_amount(epoch_budget_ecu, "epoch_budget_ecu")
    requested = _require_decimal_amount(requested_bounty_ecu, "requested_bounty_ecu")
    cap = (epoch_budget * BOUNTY_CAP_FRACTION_OF_EPOCH_BUDGET).quantize(
        BOUNTY_ACCOUNTING_QUANTUM,
        rounding=ROUND_DOWN,
    )
    approved = min(requested, cap)
    if approved < Decimal("0"):
        raise ValueError("approved_bounty_ecu_must_not_be_negative")

    return BountyIssuanceQuote(
        runtime_version=PRODUCTIVE_ECU_EXPANSION_BOUNTY_RUNTIME_VERSION,
        adr_0016_status=ADR_0016_STATUS_PROPOSED,
        epoch_budget_ecu=epoch_budget,
        requested_ecu=requested,
        cap_ecu=cap,
        approved_ecu=approved,
        cap_fraction_of_epoch_budget=BOUNTY_CAP_FRACTION_OF_EPOCH_BUDGET,
        cap_fraction_applied=requested > cap,
        production_bounty_activated=False,
        no_debt_rule_token="adr_0016_no_output_no_money_no_debt_rule_phase_1542p",
        guard_token=PRODUCTIVE_ECU_EXPANSION_NOT_ACTIVATED_TOKEN,
    )


def build_bounty_delivery_stub(bounty_id: str) -> BountyDeliveryStub:
    return BountyDeliveryStub(
        bounty_id=_require_bounty_id(bounty_id),
        panel_assignment_result=BOUNTY_PANEL_ASSIGNMENT_NOT_IMPLEMENTED,
        cdl_v3_diversity_requirement_recorded=True,
        cdl_v7_popperian_gate_requirement_recorded=True,
        peer_funded_bounty_excluded=True,
        adr_0016_status=ADR_0016_STATUS_PROPOSED,
        production_bounty_activated=False,
    )


def build_canonical_bounty_accounting_event_payloads(
    issuance_quote: BountyIssuanceQuote,
    delivery_stub: BountyDeliveryStub,
) -> list[dict[str, object]]:
    if not isinstance(issuance_quote, BountyIssuanceQuote):
        raise ValueError("bounty_issuance_quote_required")
    if not isinstance(delivery_stub, BountyDeliveryStub):
        raise ValueError("bounty_delivery_stub_required")
    _reject_non_json_exact_values(issuance_quote)
    _reject_non_json_exact_values(delivery_stub)

    base = {
        "adr_0016_status": issuance_quote.adr_0016_status,
        "approved_ecu_str": _decimal_to_string(issuance_quote.approved_ecu),
        "bounty_id": delivery_stub.bounty_id,
        "cap_ecu_str": _decimal_to_string(issuance_quote.cap_ecu),
        "cap_fraction_applied": issuance_quote.cap_fraction_applied,
        "panel_assignment_result": delivery_stub.panel_assignment_result,
        "peer_funded_bounty_excluded": delivery_stub.peer_funded_bounty_excluded,
        "production_activated": False,
        "requested_ecu_str": _decimal_to_string(issuance_quote.requested_ecu),
        "schema_version": CANONICAL_BOUNTY_ACCOUNTING_EVENT_SCHEMA_VERSION,
    }
    return [
        {
            **base,
            "event_type": "productive_ecu_expansion_bounty_issuance_quote",
        },
        {
            **base,
            "event_type": "productive_ecu_expansion_bounty_delivery_stub",
        },
    ]


def compute_bounty_accounting_settlement_root(
    issuance_quote: BountyIssuanceQuote,
    delivery_stub: BountyDeliveryStub,
) -> BountyAccountingSettlementRoot:
    if not isinstance(issuance_quote, BountyIssuanceQuote):
        raise ValueError("bounty_issuance_quote_required")
    if not isinstance(delivery_stub, BountyDeliveryStub):
        raise ValueError("bounty_delivery_stub_required")
    _reject_non_json_exact_values(issuance_quote)
    _reject_non_json_exact_values(delivery_stub)

    payload = {
        "adr_0016_status": ADR_0016_STATUS_PROPOSED,
        "bounty_id": delivery_stub.bounty_id,
        "event_payloads": build_canonical_bounty_accounting_event_payloads(
            issuance_quote,
            delivery_stub,
        ),
        "guard_token": PRODUCTIVE_ECU_EXPANSION_NOT_ACTIVATED_TOKEN,
        "peer_funded_bounties_excluded_token": PEER_FUNDED_BOUNTIES_EXCLUDED_TOKEN,
        "production_bounty_activated": False,
        "runtime_version": PRODUCTIVE_ECU_EXPANSION_BOUNTY_RUNTIME_VERSION,
        "schema_version": SETTLEMENT_ROOT_SCHEMA_VERSION,
    }
    canonical_record_json = _canonical_json(payload)
    root_hex = hashlib.sha256(canonical_record_json.encode("utf-8")).hexdigest()
    return BountyAccountingSettlementRoot(
        context=f"productive_ecu_expansion_bounty_{delivery_stub.bounty_id}",
        canonical_record_json=canonical_record_json,
        root_hex=root_hex,
    )


def emit_canonical_bounty_accounting_events(
    issuance_quote: BountyIssuanceQuote,
    delivery_stub: BountyDeliveryStub,
    settlement_root: BountyAccountingSettlementRoot,
) -> list[CanonicalBountyAccountingEvent]:
    if not isinstance(settlement_root, BountyAccountingSettlementRoot):
        raise ValueError("bounty_accounting_settlement_root_required")

    root_payload = json.loads(settlement_root.canonical_record_json)
    event_payloads = build_canonical_bounty_accounting_event_payloads(
        issuance_quote,
        delivery_stub,
    )
    if root_payload.get("event_payloads") != event_payloads:
        raise ValueError("settlement_root_event_payload_mismatch")
    if root_payload.get("bounty_id") != delivery_stub.bounty_id:
        raise ValueError("settlement_root_bounty_id_mismatch")

    return [
        CanonicalBountyAccountingEvent(
            event_type=str(payload["event_type"]),
            bounty_id=str(payload["bounty_id"]),
            approved_ecu_str=str(payload["approved_ecu_str"]),
            requested_ecu_str=str(payload["requested_ecu_str"]),
            cap_ecu_str=str(payload["cap_ecu_str"]),
            cap_fraction_applied=bool(payload["cap_fraction_applied"]),
            panel_assignment_result=str(payload["panel_assignment_result"]),
            adr_0016_status=str(payload["adr_0016_status"]),
            production_activated=bool(payload["production_activated"]),
            peer_funded_bounty_excluded=bool(payload["peer_funded_bounty_excluded"]),
            settlement_root_hex=settlement_root.root_hex,
        )
        for payload in event_payloads
    ]


__all__ = [
    "ADR_0016_STATUS_PROPOSED",
    "BOUNTY_ACCOUNTING_QUANTUM",
    "BOUNTY_CAP_FRACTION_OF_EPOCH_BUDGET",
    "BOUNTY_PANEL_ASSIGNMENT_NOT_IMPLEMENTED",
    "CANONICAL_BOUNTY_ACCOUNTING_EVENT_SCHEMA_VERSION",
    "PEER_FUNDED_BOUNTIES_EXCLUDED_TOKEN",
    "PRODUCTIVE_ECU_EXPANSION_BOUNTY_RUNTIME_VERSION",
    "PRODUCTIVE_ECU_EXPANSION_NOT_ACTIVATED",
    "PRODUCTIVE_ECU_EXPANSION_NOT_ACTIVATED_TOKEN",
    "SETTLEMENT_ROOT_SCHEMA_VERSION",
    "BountyAccountingSettlementRoot",
    "BountyDeliveryStub",
    "BountyIssuanceQuote",
    "CanonicalBountyAccountingEvent",
    "build_bounty_delivery_stub",
    "build_bounty_issuance_quote",
    "build_canonical_bounty_accounting_event_payloads",
    "compute_bounty_accounting_settlement_root",
    "emit_canonical_bounty_accounting_events",
    "require_productive_ecu_expansion_activation",
]
