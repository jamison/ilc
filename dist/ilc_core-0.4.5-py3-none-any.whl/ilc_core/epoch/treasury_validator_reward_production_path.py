# SPDX-License-Identifier: AGPL-3.0-only
"""Phase 1540p default-off treasury and validator reward production path.

This module wraps existing CDL-047 and CDL-054 quote runtimes in a
production-capable but non-activating distribution surface. It does not execute
treasury transfers, validator payouts, ledger writes, wallet writes, or live
ILC settlement.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, fields, is_dataclass
from decimal import Decimal
from typing import Any, Mapping

from ilc_core.epoch.issuance_economics_integration_gate import (
    IssuanceEconomicsIntegrationGateReport,
    verify_issuance_economics_integration_gate,
)
from ilc_core.epoch.treasury_governance_runtime import (
    CDL_047_DEPENDENCY,
    EpochTreasuryGovernanceQuote,
    build_treasury_governance_quote,
)
from ilc_core.epoch.validator_reward_pool_routing_runtime import (
    CDL_054_DEPENDENCY,
    EpochValidatorRewardPoolRoutingQuote,
    build_validator_reward_pool_routing_quote,
)


TREASURY_DISTRIBUTION_NOT_ACTIVATED = True
TREASURY_DISTRIBUTION_NOT_ACTIVATED_TOKEN = (
    "production_treasury_distribution_not_activated_phase_1540p"
)
TREASURY_VALIDATOR_REWARD_PRODUCTION_PATH_VERSION = (
    "treasury_validator_reward_production_path_1540p.v0.1"
)
SETTLEMENT_ROOT_SCHEMA_VERSION = "treasury_validator_reward_event_batch_root_1540p.v0.1"
CANONICAL_TREASURY_DISTRIBUTION_EVENT_SCHEMA_VERSION = (
    "canonical_treasury_distribution_event_1540p.v0.1"
)


@dataclass(frozen=True)
class TreasuryValidatorRewardProductionResult:
    runtime_version: str
    cdl_047_dependency: str
    cdl_054_dependency: str
    issuance_epoch: int
    gate_report: IssuanceEconomicsIntegrationGateReport
    integration_gate_result: str
    treasury_quote: EpochTreasuryGovernanceQuote
    reward_routing_quote: EpochValidatorRewardPoolRoutingQuote
    production_treasury_distribution_activated: bool
    guard_token: str

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "cdl_047_dependency": self.cdl_047_dependency,
            "cdl_054_dependency": self.cdl_054_dependency,
            "gate_report": self.gate_report.to_canonical_record(),
            "guard_token": self.guard_token,
            "integration_gate_result": self.integration_gate_result,
            "issuance_epoch": self.issuance_epoch,
            "production_treasury_distribution_activated": (
                self.production_treasury_distribution_activated
            ),
            "reward_routing_quote": self.reward_routing_quote.to_canonical_record(),
            "runtime_version": self.runtime_version,
            "treasury_quote": self.treasury_quote.to_canonical_record(),
        }


@dataclass(frozen=True)
class TreasuryDistributionSettlementRoot:
    issuance_epoch_or_context: str
    canonical_record_json: str
    root_hex: str
    root_algorithm: str = "sha256_over_canonical_json"

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "canonical_record_json": self.canonical_record_json,
            "issuance_epoch_or_context": self.issuance_epoch_or_context,
            "root_algorithm": self.root_algorithm,
            "root_hex": self.root_hex,
        }


@dataclass(frozen=True)
class CanonicalTreasuryDistributionEvent:
    event_type: str
    issuance_epoch: int
    amount_role: str
    amount_ilc_str: str
    source_label: str
    cdl_dependency: str
    decision_token: str
    integration_gate_result: str
    production_treasury_distribution_activated: bool
    settlement_root_hex: str
    schema_version: str = CANONICAL_TREASURY_DISTRIBUTION_EVENT_SCHEMA_VERSION

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "amount_ilc_str": self.amount_ilc_str,
            "amount_role": self.amount_role,
            "cdl_dependency": self.cdl_dependency,
            "decision_token": self.decision_token,
            "event_type": self.event_type,
            "integration_gate_result": self.integration_gate_result,
            "issuance_epoch": self.issuance_epoch,
            "production_treasury_distribution_activated": (
                self.production_treasury_distribution_activated
            ),
            "schema_version": self.schema_version,
            "settlement_root_hex": self.settlement_root_hex,
            "source_label": self.source_label,
        }

    def to_canonical_json(self) -> str:
        return _canonical_json_allowing_root(self.to_canonical_record())


def require_treasury_distribution_production_activation() -> None:
    raise NotImplementedError(TREASURY_DISTRIBUTION_NOT_ACTIVATED_TOKEN)


def _reject_non_json_exact_values(value: Any) -> None:
    if isinstance(value, float):
        raise ValueError("float_in_treasury_distribution_record_rejected")
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError("invalid_amount_non_finite")
        return
    if is_dataclass(value) and not isinstance(value, type):
        for field in fields(value):
            _reject_non_json_exact_values(getattr(value, field.name))
        return
    if isinstance(value, dict):
        for key, item in value.items():
            _reject_non_json_exact_values(key)
            _reject_non_json_exact_values(item)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            _reject_non_json_exact_values(item)


def _reject_settlement_root_key(value: Any) -> None:
    if isinstance(value, dict):
        if "settlement_root_hex" in value:
            raise ValueError("settlement_root_hex_must_be_excluded_from_root_payload")
        for item in value.values():
            _reject_settlement_root_key(item)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            _reject_settlement_root_key(item)


def _canonical_json(payload: dict[str, Any]) -> str:
    _reject_non_json_exact_values(payload)
    _reject_settlement_root_key(payload)
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
        ensure_ascii=True,
    )


def _canonical_json_allowing_root(payload: dict[str, Any]) -> str:
    # Event payloads legitimately include their settlement root; root payloads
    # must use _canonical_json() so the root cannot hash itself.
    _reject_non_json_exact_values(payload)
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
        ensure_ascii=True,
    )


def _decimal_to_string(value: Decimal) -> str:
    if not isinstance(value, Decimal):
        raise ValueError("amount_must_be_decimal")
    if not value.is_finite():
        raise ValueError("invalid_amount_non_finite")
    if value < Decimal("0"):
        raise ValueError("amount_must_be_non_negative")
    return format(value.normalize(), "f")


def _require_mapping(value: Mapping[str, object] | dict[str, object]) -> dict[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError("epoch_inputs_must_be_mapping")
    return dict(value)


def _required(inputs: dict[str, object], key: str) -> object:
    if key not in inputs:
        raise ValueError(f"{key}_required")
    return inputs[key]


def _require_epoch(value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError("issuance_epoch_must_be_non_negative_int")
    return value


def build_treasury_validator_reward_result(
    epoch_inputs: Mapping[str, object] | dict[str, object],
) -> TreasuryValidatorRewardProductionResult:
    if not TREASURY_DISTRIBUTION_NOT_ACTIVATED:
        raise ValueError("treasury_distribution_guard_cleared_without_activation_authority_phase_1540p")

    inputs = _require_mapping(epoch_inputs)
    issuance_epoch = _require_epoch(_required(inputs, "issuance_epoch"))
    gate_report = verify_issuance_economics_integration_gate()
    treasury_quote = build_treasury_governance_quote(
        issuance_epoch=issuance_epoch,
        epoch_budget_ilc=_required(inputs, "epoch_budget_ilc"),
        requested_bounty_ilc=_required(inputs, "requested_bounty_ilc"),
        planned_burn_ilc=_required(inputs, "planned_burn_ilc"),
        observed_velocity=_required(inputs, "observed_velocity"),
    )
    reward_routing_quote = build_validator_reward_pool_routing_quote(
        issuance_epoch=issuance_epoch,
        write_fee_burn_pool_ilc=_required(inputs, "write_fee_burn_pool_ilc"),
        cumulative_issued_before_epoch_ilc=_required(
            inputs,
            "cumulative_issued_before_epoch_ilc",
        ),
        treasury_planned_burn_ilc=_required(inputs, "treasury_planned_burn_ilc"),
        observed_velocity=_required(inputs, "observed_velocity"),
    )
    return TreasuryValidatorRewardProductionResult(
        runtime_version=TREASURY_VALIDATOR_REWARD_PRODUCTION_PATH_VERSION,
        cdl_047_dependency=CDL_047_DEPENDENCY,
        cdl_054_dependency=CDL_054_DEPENDENCY,
        issuance_epoch=issuance_epoch,
        gate_report=gate_report,
        integration_gate_result=gate_report.verdict,
        treasury_quote=treasury_quote,
        reward_routing_quote=reward_routing_quote,
        production_treasury_distribution_activated=False,
        guard_token=TREASURY_DISTRIBUTION_NOT_ACTIVATED_TOKEN,
    )


def build_canonical_treasury_validator_reward_event_payloads(
    result: TreasuryValidatorRewardProductionResult,
) -> list[dict[str, object]]:
    if not isinstance(result, TreasuryValidatorRewardProductionResult):
        raise ValueError("treasury_validator_reward_result_required")
    _reject_non_json_exact_values(result)

    treasury = result.treasury_quote
    reward = result.reward_routing_quote
    event_specs = [
        (
            "treasury_distribution",
            "treasury_bounty_cap",
            treasury.bounty_cap_ilc,
            "cdl_047_treasury_governance",
            result.cdl_047_dependency,
            treasury.decision_token,
        ),
        (
            "treasury_distribution",
            "treasury_planned_burn",
            treasury.planned_burn_ilc,
            "cdl_047_treasury_governance",
            result.cdl_047_dependency,
            treasury.decision_token,
        ),
        (
            "treasury_distribution",
            "treasury_remaining_budget",
            treasury.treasury_remaining_budget_ilc,
            "cdl_047_treasury_governance",
            result.cdl_047_dependency,
            treasury.decision_token,
        ),
        (
            "validator_reward_distribution",
            "validator_reward_pool",
            reward.validator_reward_pool_ilc,
            "cdl_054_validator_reward_pool",
            result.cdl_054_dependency,
            reward.decision_token,
        ),
    ]
    return [
        {
            "amount_ilc_str": _decimal_to_string(amount),
            "amount_role": amount_role,
            "cdl_dependency": cdl_dependency,
            "decision_token": decision_token,
            "event_type": event_type,
            "integration_gate_result": result.integration_gate_result,
            "issuance_epoch": result.issuance_epoch,
            "production_treasury_distribution_activated": (
                result.production_treasury_distribution_activated
            ),
            "schema_version": CANONICAL_TREASURY_DISTRIBUTION_EVENT_SCHEMA_VERSION,
            "source_label": source_label,
        }
        for (
            event_type,
            amount_role,
            amount,
            source_label,
            cdl_dependency,
            decision_token,
        ) in event_specs
    ]


def compute_treasury_distribution_settlement_root(
    result: TreasuryValidatorRewardProductionResult,
) -> TreasuryDistributionSettlementRoot:
    if not isinstance(result, TreasuryValidatorRewardProductionResult):
        raise ValueError("treasury_validator_reward_result_required")
    _reject_non_json_exact_values(result)

    payload = {
        "cdl_047_dependency": result.cdl_047_dependency,
        "cdl_054_dependency": result.cdl_054_dependency,
        "event_payloads": build_canonical_treasury_validator_reward_event_payloads(result),
        "guard_token": result.guard_token,
        "integration_gate_result": result.integration_gate_result,
        "issuance_epoch": result.issuance_epoch,
        "production_treasury_distribution_activated": (
            result.production_treasury_distribution_activated
        ),
        "runtime_version": result.runtime_version,
        "schema_version": SETTLEMENT_ROOT_SCHEMA_VERSION,
    }
    canonical_record_json = _canonical_json(payload)
    root_hex = hashlib.sha256(canonical_record_json.encode("utf-8")).hexdigest()
    return TreasuryDistributionSettlementRoot(
        issuance_epoch_or_context=f"treasury_validator_reward_epoch_{result.issuance_epoch}",
        canonical_record_json=canonical_record_json,
        root_hex=root_hex,
    )


def emit_canonical_treasury_distribution_events(
    result: TreasuryValidatorRewardProductionResult,
    settlement_root: TreasuryDistributionSettlementRoot,
) -> list[CanonicalTreasuryDistributionEvent]:
    if not isinstance(result, TreasuryValidatorRewardProductionResult):
        raise ValueError("treasury_validator_reward_result_required")
    if not isinstance(settlement_root, TreasuryDistributionSettlementRoot):
        raise ValueError("treasury_distribution_settlement_root_required")

    root_payload = json.loads(settlement_root.canonical_record_json)
    event_payloads = build_canonical_treasury_validator_reward_event_payloads(result)
    if root_payload.get("event_payloads") != event_payloads:
        raise ValueError("settlement_root_event_payload_mismatch")
    if root_payload.get("issuance_epoch") != result.issuance_epoch:
        raise ValueError("settlement_root_issuance_epoch_mismatch")

    return [
        CanonicalTreasuryDistributionEvent(
            event_type=str(payload["event_type"]),
            issuance_epoch=int(payload["issuance_epoch"]),
            amount_role=str(payload["amount_role"]),
            amount_ilc_str=str(payload["amount_ilc_str"]),
            source_label=str(payload["source_label"]),
            cdl_dependency=str(payload["cdl_dependency"]),
            decision_token=str(payload["decision_token"]),
            integration_gate_result=str(payload["integration_gate_result"]),
            production_treasury_distribution_activated=bool(
                payload["production_treasury_distribution_activated"]
            ),
            settlement_root_hex=settlement_root.root_hex,
        )
        for payload in event_payloads
    ]


__all__ = [
    "CANONICAL_TREASURY_DISTRIBUTION_EVENT_SCHEMA_VERSION",
    "CDL_047_DEPENDENCY",
    "CDL_054_DEPENDENCY",
    "SETTLEMENT_ROOT_SCHEMA_VERSION",
    "TREASURY_DISTRIBUTION_NOT_ACTIVATED",
    "TREASURY_DISTRIBUTION_NOT_ACTIVATED_TOKEN",
    "TREASURY_VALIDATOR_REWARD_PRODUCTION_PATH_VERSION",
    "CanonicalTreasuryDistributionEvent",
    "TreasuryDistributionSettlementRoot",
    "TreasuryValidatorRewardProductionResult",
    "build_canonical_treasury_validator_reward_event_payloads",
    "build_treasury_validator_reward_result",
    "compute_treasury_distribution_settlement_root",
    "emit_canonical_treasury_distribution_events",
    "require_treasury_distribution_production_activation",
]
