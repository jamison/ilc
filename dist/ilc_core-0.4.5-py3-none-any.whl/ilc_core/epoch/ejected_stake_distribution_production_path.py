# SPDX-License-Identifier: AGPL-3.0-only
"""Phase 1541p default-off ejected-stake distribution production path.

This module wraps the existing CDL-083/H-CON-02 ejected-stake quote runtime in
a production-capable but non-activating distribution surface. It does not
execute stake liquidation, treasury transfers, validator payouts, ledger
writes, wallet writes, or live ILC settlement.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, fields, is_dataclass
from decimal import Decimal
from typing import Any, Mapping

from ilc_core.economics.epoch_attribution_settle_runtime import (
    CDL_083_DEPENDENCY,
    EjectedStakeTreasuryDistributionQuote,
    build_ejected_stake_treasury_distribution_quote,
)


EJECTED_STAKE_DISTRIBUTION_PRODUCTION_NOT_ACTIVATED = True
EJECTED_STAKE_DISTRIBUTION_PRODUCTION_NOT_ACTIVATED_TOKEN = (
    "production_ejected_stake_distribution_not_activated_phase_1541p"
)
EJECTED_STAKE_DISTRIBUTION_PRODUCTION_PATH_VERSION = (
    "ejected_stake_distribution_production_path_1541p.v0.1"
)
SETTLEMENT_ROOT_SCHEMA_VERSION = "ejected_stake_distribution_event_batch_root_1541p.v0.1"
CANONICAL_EJECTED_STAKE_DISTRIBUTION_EVENT_SCHEMA_VERSION = (
    "canonical_ejected_stake_distribution_event_1541p.v0.1"
)


@dataclass(frozen=True)
class EjectedStakeDistributionProductionResult:
    runtime_version: str
    cdl_083_dependency: str
    distribution_epoch: int
    distribution_quote: EjectedStakeTreasuryDistributionQuote
    hcon02_quorum_validated: bool
    production_ejected_stake_distribution_activated: bool
    guard_token: str

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "cdl_083_dependency": self.cdl_083_dependency,
            "distribution_epoch": self.distribution_epoch,
            "distribution_quote": self.distribution_quote.to_canonical_record(),
            "guard_token": self.guard_token,
            "hcon02_quorum_validated": self.hcon02_quorum_validated,
            "production_ejected_stake_distribution_activated": (
                self.production_ejected_stake_distribution_activated
            ),
            "runtime_version": self.runtime_version,
        }


@dataclass(frozen=True)
class EjectedStakeSettlementRoot:
    issuance_epoch_or_context: str
    canonical_record_json: str
    root_hex: str
    root_algorithm: str = "sha256_over_canonical_json"

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "canonical_record_json": self.canonical_record_json,
            "issuance_epoch_or_context": self.issuance_epoch_or_context,
            "root_algorithm": self.root_algorithm,
            "root_hex": self.root_hex,
        }


@dataclass(frozen=True)
class CanonicalEjectedStakeDistributionEvent:
    event_type: str
    distribution_epoch: int
    recipient_agent_id: str
    amount_ilc_str: str
    cdl_dependency: str
    distribution_token: str
    h_con_02_guard_token: str
    decision_token: str
    hcon02_quorum_validated: bool
    production_ejected_stake_distribution_activated: bool
    settlement_root_hex: str
    schema_version: str = CANONICAL_EJECTED_STAKE_DISTRIBUTION_EVENT_SCHEMA_VERSION

    def to_canonical_record(self) -> dict[str, Any]:
        return {
            "amount_ilc_str": self.amount_ilc_str,
            "cdl_dependency": self.cdl_dependency,
            "decision_token": self.decision_token,
            "distribution_epoch": self.distribution_epoch,
            "distribution_token": self.distribution_token,
            "event_type": self.event_type,
            "h_con_02_guard_token": self.h_con_02_guard_token,
            "hcon02_quorum_validated": self.hcon02_quorum_validated,
            "production_ejected_stake_distribution_activated": (
                self.production_ejected_stake_distribution_activated
            ),
            "recipient_agent_id": self.recipient_agent_id,
            "schema_version": self.schema_version,
            "settlement_root_hex": self.settlement_root_hex,
        }

    def to_canonical_json(self) -> str:
        return _canonical_json_allowing_root(self.to_canonical_record())


def require_ejected_stake_distribution_production_activation() -> None:
    raise NotImplementedError(EJECTED_STAKE_DISTRIBUTION_PRODUCTION_NOT_ACTIVATED_TOKEN)


def _reject_non_json_exact_values(value: Any) -> None:
    if isinstance(value, float):
        raise ValueError("float_in_ejected_stake_distribution_record_rejected")
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError("invalid_amount_non_finite")
        return
    if is_dataclass(value) and not isinstance(value, type):
        for field in fields(value):
            _reject_non_json_exact_values(getattr(value, field.name))
        return
    if isinstance(value, dict):
        for key, item in value.items():
            _reject_non_json_exact_values(key)
            _reject_non_json_exact_values(item)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            _reject_non_json_exact_values(item)


def _reject_settlement_root_key(value: Any) -> None:
    if isinstance(value, dict):
        if "settlement_root_hex" in value:
            raise ValueError("settlement_root_hex_must_be_excluded_from_root_payload")
        for item in value.values():
            _reject_settlement_root_key(item)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            _reject_settlement_root_key(item)


def _canonical_json(payload: dict[str, Any]) -> str:
    _reject_non_json_exact_values(payload)
    _reject_settlement_root_key(payload)
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
        ensure_ascii=True,
    )


def _canonical_json_allowing_root(payload: dict[str, Any]) -> str:
    _reject_non_json_exact_values(payload)
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
        ensure_ascii=True,
    )


def _decimal_to_string(value: Decimal) -> str:
    if not isinstance(value, Decimal):
        raise ValueError("amount_must_be_decimal")
    if not value.is_finite():
        raise ValueError("invalid_amount_non_finite")
    if value < Decimal("0"):
        raise ValueError("amount_must_be_non_negative")
    return format(value.normalize(), "f")


def _require_mapping(value: Mapping[str, object] | dict[str, object]) -> dict[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError("ejection_inputs_must_be_mapping")
    return dict(value)


def _required(inputs: dict[str, object], key: str) -> object:
    if key not in inputs:
        raise ValueError(f"{key}_required")
    return inputs[key]


def _require_epoch(value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError("distribution_epoch_must_be_non_negative_int")
    return value


def build_ejected_stake_distribution_result(
    ejection_inputs: Mapping[str, object] | dict[str, object],
) -> EjectedStakeDistributionProductionResult:
    if not EJECTED_STAKE_DISTRIBUTION_PRODUCTION_NOT_ACTIVATED:
        raise ValueError(
            "ejected_stake_distribution_guard_cleared_without_activation_authority_phase_1541p"
        )

    inputs = _require_mapping(ejection_inputs)
    distribution_epoch = _require_epoch(_required(inputs, "distribution_epoch"))
    distribution_quote = build_ejected_stake_treasury_distribution_quote(
        distribution_epoch=distribution_epoch,
        ejected_stake_ilc=_required(inputs, "ejected_stake_ilc"),
        remaining_member_stakes=_required(inputs, "remaining_member_stakes"),
        approve_votes=_required(inputs, "approve_votes"),
        participating_voters=_required(inputs, "participating_voters"),
    )
    return EjectedStakeDistributionProductionResult(
        runtime_version=EJECTED_STAKE_DISTRIBUTION_PRODUCTION_PATH_VERSION,
        cdl_083_dependency=CDL_083_DEPENDENCY,
        distribution_epoch=distribution_epoch,
        distribution_quote=distribution_quote,
        hcon02_quorum_validated=True,
        production_ejected_stake_distribution_activated=False,
        guard_token=EJECTED_STAKE_DISTRIBUTION_PRODUCTION_NOT_ACTIVATED_TOKEN,
    )


def build_canonical_ejected_stake_event_payloads(
    result: EjectedStakeDistributionProductionResult,
) -> list[dict[str, object]]:
    if not isinstance(result, EjectedStakeDistributionProductionResult):
        raise ValueError("ejected_stake_distribution_result_required")
    _reject_non_json_exact_values(result)

    quote = result.distribution_quote
    return [
        {
            "amount_ilc_str": _decimal_to_string(amount),
            "cdl_dependency": result.cdl_083_dependency,
            "decision_token": quote.decision_token,
            "distribution_epoch": result.distribution_epoch,
            "distribution_token": quote.distribution_token,
            "event_type": "ejected_stake_distribution",
            "h_con_02_guard_token": quote.h_con_02_guard_token,
            "hcon02_quorum_validated": result.hcon02_quorum_validated,
            "production_ejected_stake_distribution_activated": (
                result.production_ejected_stake_distribution_activated
            ),
            "recipient_agent_id": agent_id,
            "schema_version": CANONICAL_EJECTED_STAKE_DISTRIBUTION_EVENT_SCHEMA_VERSION,
        }
        for agent_id, amount in quote.payouts
    ]


def compute_ejected_stake_settlement_root(
    result: EjectedStakeDistributionProductionResult,
) -> EjectedStakeSettlementRoot:
    if not isinstance(result, EjectedStakeDistributionProductionResult):
        raise ValueError("ejected_stake_distribution_result_required")
    _reject_non_json_exact_values(result)

    payload = {
        "cdl_083_dependency": result.cdl_083_dependency,
        "distribution_epoch": result.distribution_epoch,
        "event_payloads": build_canonical_ejected_stake_event_payloads(result),
        "guard_token": result.guard_token,
        "hcon02_quorum_validated": result.hcon02_quorum_validated,
        "production_ejected_stake_distribution_activated": (
            result.production_ejected_stake_distribution_activated
        ),
        "runtime_version": result.runtime_version,
        "schema_version": SETTLEMENT_ROOT_SCHEMA_VERSION,
    }
    canonical_record_json = _canonical_json(payload)
    root_hex = hashlib.sha256(canonical_record_json.encode("utf-8")).hexdigest()
    return EjectedStakeSettlementRoot(
        issuance_epoch_or_context=f"ejected_stake_distribution_epoch_{result.distribution_epoch}",
        canonical_record_json=canonical_record_json,
        root_hex=root_hex,
    )


def emit_canonical_ejected_stake_distribution_events(
    result: EjectedStakeDistributionProductionResult,
    settlement_root: EjectedStakeSettlementRoot,
) -> list[CanonicalEjectedStakeDistributionEvent]:
    if not isinstance(result, EjectedStakeDistributionProductionResult):
        raise ValueError("ejected_stake_distribution_result_required")
    if not isinstance(settlement_root, EjectedStakeSettlementRoot):
        raise ValueError("ejected_stake_settlement_root_required")

    root_payload = json.loads(settlement_root.canonical_record_json)
    event_payloads = build_canonical_ejected_stake_event_payloads(result)
    if root_payload.get("event_payloads") != event_payloads:
        raise ValueError("settlement_root_event_payload_mismatch")
    if root_payload.get("distribution_epoch") != result.distribution_epoch:
        raise ValueError("settlement_root_distribution_epoch_mismatch")

    return [
        CanonicalEjectedStakeDistributionEvent(
            event_type=str(payload["event_type"]),
            distribution_epoch=int(payload["distribution_epoch"]),
            recipient_agent_id=str(payload["recipient_agent_id"]),
            amount_ilc_str=str(payload["amount_ilc_str"]),
            cdl_dependency=str(payload["cdl_dependency"]),
            distribution_token=str(payload["distribution_token"]),
            h_con_02_guard_token=str(payload["h_con_02_guard_token"]),
            decision_token=str(payload["decision_token"]),
            hcon02_quorum_validated=bool(payload["hcon02_quorum_validated"]),
            production_ejected_stake_distribution_activated=bool(
                payload["production_ejected_stake_distribution_activated"]
            ),
            settlement_root_hex=settlement_root.root_hex,
        )
        for payload in event_payloads
    ]


__all__ = [
    "CANONICAL_EJECTED_STAKE_DISTRIBUTION_EVENT_SCHEMA_VERSION",
    "CDL_083_DEPENDENCY",
    "EJECTED_STAKE_DISTRIBUTION_PRODUCTION_NOT_ACTIVATED",
    "EJECTED_STAKE_DISTRIBUTION_PRODUCTION_NOT_ACTIVATED_TOKEN",
    "EJECTED_STAKE_DISTRIBUTION_PRODUCTION_PATH_VERSION",
    "CanonicalEjectedStakeDistributionEvent",
    "EjectedStakeDistributionProductionResult",
    "EjectedStakeSettlementRoot",
    "SETTLEMENT_ROOT_SCHEMA_VERSION",
    "build_canonical_ejected_stake_event_payloads",
    "build_ejected_stake_distribution_result",
    "compute_ejected_stake_settlement_root",
    "emit_canonical_ejected_stake_distribution_events",
    "require_ejected_stake_distribution_production_activation",
]
