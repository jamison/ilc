# SPDX-License-Identifier: AGPL-3.0-only
# PUBLIC_RC_EXCLUDE: economic_activation_pending_1575b
"""Phase 1534p canonical economic event record schema and emitter.

CDL-029 governs the 80/15/5 allocation split that these records capture. This
module defines the implementation-level canonical economic event record schema
anchored to CDL-025/027/028/029 parameters computed by the default-off emission
path. Production emission is not activated; the guard is retained in
``epoch_emission_production_path.py`` until a separate production activation
authority phase is executed.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from ilc_core.epoch.epoch_emission_production_path import (
    CANONICAL_ECONOMIC_EVENT_RECORD_SCHEMA_VERSION,
    CANONICAL_ECONOMIC_EVENT_ROLES,
    CDL_ECONOMIC_EVENT_AUTHORITY_TOKENS,
    EpochEmissionProductionResult,
    EpochSettlementRoot,
    build_canonical_economic_event_payloads,
)


CDL_AUTHORITY_TOKENS: list[str] = list(CDL_ECONOMIC_EVENT_AUTHORITY_TOKENS)
VALID_CANONICAL_ECONOMIC_EVENT_ROLES = frozenset(CANONICAL_ECONOMIC_EVENT_ROLES)
_ZERO = Decimal("0")
_LOWER_HEX = frozenset("0123456789abcdef")


@dataclass(frozen=True)
class CanonicalEconomicEventRecord:
    schema_version: str
    issuance_epoch: int
    role: str
    amount_ilc_str: str
    settlement_root_hex: str
    cdl_authority: list[str]
    production_emission_activated: bool

    def to_canonical_record(self) -> dict[str, object]:
        return {
            "amount_ilc_str": self.amount_ilc_str,
            "cdl_authority": sorted(self.cdl_authority),
            "issuance_epoch": self.issuance_epoch,
            "production_emission_activated": self.production_emission_activated,
            "role": self.role,
            "schema_version": self.schema_version,
            "settlement_root_hex": self.settlement_root_hex,
        }

    def to_canonical_json(self) -> str:
        return json.dumps(
            self.to_canonical_record(),
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
            ensure_ascii=True,
        )


def _decimal_to_string(value: Decimal) -> str:
    return format(value.normalize(), "f")


def _require_finite_decimal(value: object, field_name: str) -> Decimal:
    if isinstance(value, float):
        raise ValueError("float_in_canonical_economic_event_rejected")
    if not isinstance(value, Decimal):
        raise ValueError(f"{field_name}_must_be_decimal")
    if not value.is_finite():
        raise ValueError("invalid_amount_non_finite")
    if value < _ZERO:
        raise ValueError(f"{field_name}_must_be_non_negative")
    return value


def _require_settlement_root_hex(value: object) -> str:
    if not isinstance(value, str) or len(value) != 64:
        raise ValueError("settlement_root_hex_invalid")
    if any(char not in _LOWER_HEX for char in value):
        raise ValueError("settlement_root_hex_invalid")
    return value


def _event_from_payload(
    payload: dict[str, object],
    *,
    settlement_root_hex: str,
) -> CanonicalEconomicEventRecord:
    role = payload.get("role")
    if role not in VALID_CANONICAL_ECONOMIC_EVENT_ROLES:
        raise ValueError("canonical_economic_event_role_invalid")
    amount = payload.get("amount_ilc_str")
    if not isinstance(amount, str):
        raise ValueError("canonical_economic_event_amount_invalid")
    try:
        parsed_amount = Decimal(amount)
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("canonical_economic_event_amount_invalid") from exc
    decimal_amount = _require_finite_decimal(parsed_amount, str(role))
    cdl_authority = payload.get("cdl_authority")
    if not isinstance(cdl_authority, list) or not all(
        isinstance(token, str) for token in cdl_authority
    ):
        raise ValueError("canonical_economic_event_authority_invalid")
    issuance_epoch = payload.get("issuance_epoch")
    if isinstance(issuance_epoch, bool) or not isinstance(issuance_epoch, int):
        raise ValueError("canonical_economic_event_epoch_invalid")
    production_emission_activated = payload.get("production_emission_activated")
    if not isinstance(production_emission_activated, bool):
        raise ValueError("canonical_economic_event_activation_flag_invalid")
    schema_version = payload.get("schema_version")
    if schema_version != CANONICAL_ECONOMIC_EVENT_RECORD_SCHEMA_VERSION:
        raise ValueError("canonical_economic_event_schema_version_invalid")
    return CanonicalEconomicEventRecord(
        schema_version=CANONICAL_ECONOMIC_EVENT_RECORD_SCHEMA_VERSION,
        issuance_epoch=issuance_epoch,
        role=str(role),
        amount_ilc_str=_decimal_to_string(decimal_amount),
        settlement_root_hex=settlement_root_hex,
        cdl_authority=list(cdl_authority),
        production_emission_activated=production_emission_activated,
    )


def _root_payload(settlement_root: EpochSettlementRoot) -> dict[str, object]:
    digest = hashlib.sha256(
        settlement_root.canonical_record_json.encode("utf-8")
    ).hexdigest()
    if digest != settlement_root.root_hex:
        raise ValueError("settlement_root_digest_mismatch")
    payload = json.loads(settlement_root.canonical_record_json)
    if not isinstance(payload, dict):
        raise ValueError("settlement_root_payload_invalid")
    return payload


def emit_canonical_economic_event_records(
    result: EpochEmissionProductionResult,
    settlement_root: EpochSettlementRoot,
) -> list[CanonicalEconomicEventRecord]:
    """Emit canonical economic event records for an epoch emission result.

    The already-computed settlement root is injected after the root payload was
    hashed, preserving anti-circularity. The emitter performs no ledger, wallet,
    treasury, graph, or external-state writes.
    """

    if not isinstance(result, EpochEmissionProductionResult):
        raise ValueError("epoch_emission_production_result_required")
    if not isinstance(settlement_root, EpochSettlementRoot):
        raise ValueError("epoch_settlement_root_required")
    if settlement_root.issuance_epoch != result.issuance_epoch:
        raise ValueError("settlement_root_epoch_mismatch")

    settlement_root_hex = _require_settlement_root_hex(settlement_root.root_hex)
    event_payloads = build_canonical_economic_event_payloads(result)
    root_payload = _root_payload(settlement_root)
    if root_payload.get("economic_event_payloads") != event_payloads:
        raise ValueError("settlement_root_event_payload_mismatch")
    return [
        _event_from_payload(payload, settlement_root_hex=settlement_root_hex)
        for payload in event_payloads
    ]


__all__ = [
    "CANONICAL_ECONOMIC_EVENT_RECORD_SCHEMA_VERSION",
    "CDL_AUTHORITY_TOKENS",
    "VALID_CANONICAL_ECONOMIC_EVENT_ROLES",
    "CanonicalEconomicEventRecord",
    "emit_canonical_economic_event_records",
]
