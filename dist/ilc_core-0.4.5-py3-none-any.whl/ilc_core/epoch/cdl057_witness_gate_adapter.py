# SPDX-License-Identifier: AGPL-3.0-only
# PUBLIC_RC_EXCLUDE: economic_activation_pending_1575b
"""Minimal CDL-057 witness-gate adapter.

This adapter bridges ``record_epoch_boundary_witness()`` output into the
``attach_cdl057_witness_ref()`` interface from the distributed conversion
schema. It only determines conversion-batch certification eligibility; it does
not grant minting, settlement, wallet-write, or public-serving authority.
"""

from __future__ import annotations

from collections import deque
from collections.abc import Mapping
import hashlib
import json
import re
from typing import Any

from ilc_core.ledger.distributed_conversion_schema import CDL057_WITNESS_ABSENT_TOKEN


CDL057_WITNESS_GATE_ADAPTER_VERSION = "cdl057_witness_gate_adapter_fix8a.v0.1"
CDL057_DEPENDENCY = "cdl_057_ratified_511.v0.1"
CDL089_DEPENDENCY = "cdl_089_ratified_phase_1364.v0.1"
CDL057_WITNESS_REF_PREFIX = "cdl057_witness_sha256:"
_PROVENANCE_EPOCH_RE = re.compile(r"@epoch_([0-9]+)$")


class EpochWitnessGateAdapter:
    """Adapter implementing ``get_latest_witness_ref()`` for conversion candidates."""

    def __init__(self, *, max_records: int = 1024) -> None:
        if isinstance(max_records, bool) or not isinstance(max_records, int) or max_records <= 0:
            raise ValueError("witness_gate_max_records_invalid")
        self._records: deque[dict[str, Any]] = deque(maxlen=max_records)
        self._payload_by_ref: dict[str, dict[str, Any]] = {}

    def add_witness_record(self, record: dict[str, Any]) -> None:
        """Register a witness record produced by ``record_epoch_boundary_witness()``."""

        if not isinstance(record, dict):
            raise ValueError("witness_record_must_be_dict")
        if record.get("status") != "witnessed":
            raise ValueError("witness_record_status_must_be_witnessed")
        batch_cid = _require_non_empty_text(record.get("batch_cid"), "witness_record_batch_cid_required")
        provenance_tag = _require_non_empty_text(
            record.get("provenance_tag"),
            "witness_record_provenance_tag_required",
        )
        witness_epoch = _extract_epoch_from_provenance_tag(provenance_tag)
        payload = {
            "batch_cid": batch_cid,
            "provenance_tag": provenance_tag,
            "status": "witnessed",
            "witness_epoch": witness_epoch,
        }
        evicted_ref = None
        if len(self._records) == self._records.maxlen:
            evicted_ref = self._records[0]["witness_ref"]
        witness_ref = canonical_witness_ref(payload)
        self._records.append({**payload, "witness_ref": witness_ref})
        self._payload_by_ref[witness_ref] = payload
        if evicted_ref is not None and not any(record["witness_ref"] == evicted_ref for record in self._records):
            self._payload_by_ref.pop(evicted_ref, None)

    def get_latest_witness_ref(self) -> str | None:
        """Return the latest canonical witness ref, or ``None`` when empty."""

        if not self._records:
            return None
        return self._records[-1]["witness_ref"]

    def get_witness_ref_for_candidate(self, candidate: Any) -> str | None:
        """Return the newest witness ref bound to this candidate's epoch and batch."""

        lot_id = getattr(candidate, "lot_id", None)
        conversion_epoch = getattr(candidate, "conversion_epoch", None)
        if not isinstance(lot_id, str) or not lot_id.strip():
            return None
        if isinstance(conversion_epoch, bool) or not isinstance(conversion_epoch, int):
            return None
        for record in reversed(self._records):
            if record["batch_cid"] == lot_id.strip() and record["witness_epoch"] == conversion_epoch:
                return record["witness_ref"]
        return None

    def get_witness_payload(self, witness_ref: str) -> dict[str, Any] | None:
        """Return a copy of the payload committed by ``witness_ref``."""

        if not is_canonical_witness_ref(witness_ref):
            return None
        payload = self._payload_by_ref.get(witness_ref.strip())
        if payload is None:
            return None
        return dict(payload)

    def record_count(self) -> int:
        """Return the number of retained witness records."""

        return len(self._records)


def is_batch_eligible_for_public_rc_certification(
    resolution: Any,
    witness_runtime: Any | None = None,
) -> bool:
    """Return whether a resolution has a valid batch-bound CDL-057 witness."""

    if isinstance(resolution, Mapping):
        witness_ref = resolution.get("cdl057_witness_ref")
        lot_id = resolution.get("lot_id")
        conversion_epoch = resolution.get("conversion_epoch")
    else:
        witness_ref = getattr(resolution, "cdl057_witness_ref", None)
        lot_id = getattr(resolution, "lot_id", None)
        conversion_epoch = getattr(resolution, "conversion_epoch", None)
    if not is_canonical_witness_ref(witness_ref):
        return False
    payload = _resolve_witness_payload(resolution, witness_ref, witness_runtime)
    if not _payload_matches_ref(payload, witness_ref):
        return False
    if not isinstance(lot_id, str) or payload["batch_cid"] != lot_id.strip():
        return False
    if isinstance(conversion_epoch, bool) or not isinstance(conversion_epoch, int):
        return False
    return payload["witness_epoch"] == conversion_epoch


def canonical_witness_ref(payload: Mapping[str, Any]) -> str:
    """Return the canonical ref for a validated CDL-057 witness payload."""

    canonical_payload = _canonical_witness_payload(payload)
    digest = hashlib.sha256(_stable_json_bytes(canonical_payload)).hexdigest()
    return f"{CDL057_WITNESS_REF_PREFIX}{digest}"


def is_canonical_witness_ref(value: Any) -> bool:
    """Return whether ``value`` is a syntactically canonical witness ref."""

    if not isinstance(value, str):
        return False
    witness_ref = value.strip()
    if witness_ref == CDL057_WITNESS_ABSENT_TOKEN:
        return False
    if not witness_ref.startswith(CDL057_WITNESS_REF_PREFIX):
        return False
    digest = witness_ref.removeprefix(CDL057_WITNESS_REF_PREFIX)
    return len(digest) == 64 and all(char in "0123456789abcdef" for char in digest)


def _require_non_empty_text(value: Any, token: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(token)
    return value.strip()


def _extract_epoch_from_provenance_tag(provenance_tag: str) -> int:
    match = _PROVENANCE_EPOCH_RE.search(provenance_tag)
    if match is None:
        raise ValueError("witness_record_provenance_epoch_required")
    return int(match.group(1))


def _canonical_witness_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise ValueError("witness_payload_must_be_mapping")
    status = _require_non_empty_text(payload.get("status"), "witness_payload_status_required")
    if status != "witnessed":
        raise ValueError("witness_payload_status_must_be_witnessed")
    batch_cid = _require_non_empty_text(payload.get("batch_cid"), "witness_payload_batch_cid_required")
    provenance_tag = _require_non_empty_text(
        payload.get("provenance_tag"),
        "witness_payload_provenance_tag_required",
    )
    witness_epoch = payload.get("witness_epoch")
    if isinstance(witness_epoch, bool) or not isinstance(witness_epoch, int) or witness_epoch < 0:
        raise ValueError("witness_payload_epoch_invalid")
    if _extract_epoch_from_provenance_tag(provenance_tag) != witness_epoch:
        raise ValueError("witness_payload_epoch_mismatch")
    return {
        "batch_cid": batch_cid,
        "provenance_tag": provenance_tag,
        "status": status,
        "witness_epoch": witness_epoch,
    }


def _stable_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
        ensure_ascii=True,
    ).encode("utf-8")


def _resolve_witness_payload(
    resolution: Any,
    witness_ref: str,
    witness_runtime: Any | None,
) -> dict[str, Any] | None:
    if witness_runtime is not None:
        getter = getattr(witness_runtime, "get_witness_payload", None)
        if callable(getter):
            try:
                payload = getter(witness_ref.strip())
            except Exception:
                return None
            return payload if isinstance(payload, Mapping) else None
    if isinstance(resolution, Mapping):
        payload = resolution.get("cdl057_witness_payload")
    else:
        payload = getattr(resolution, "cdl057_witness_payload", None)
    return payload if isinstance(payload, Mapping) else None


def _payload_matches_ref(payload: Mapping[str, Any] | None, witness_ref: str) -> bool:
    if payload is None:
        return False
    try:
        return canonical_witness_ref(payload) == witness_ref.strip()
    except ValueError:
        return False


__all__ = [
    "CDL057_DEPENDENCY",
    "CDL057_WITNESS_GATE_ADAPTER_VERSION",
    "CDL057_WITNESS_REF_PREFIX",
    "CDL089_DEPENDENCY",
    "EpochWitnessGateAdapter",
    "canonical_witness_ref",
    "is_batch_eligible_for_public_rc_certification",
    "is_canonical_witness_ref",
]
