# SPDX-License-Identifier: AGPL-3.0-only
# PUBLIC_RC_EXCLUDE: phase_1494p_cdl095_petition_node_type
# cdl_095_runtime_completions_committed_phase_1494p
# cdl_095_jury_finality_runtime_complete_phase_1494p
"""CDL-095 petition node type.

Graph Node subtype representing a CDL-095 escalation petition. A petition
is the entry point for escalating a jury verdict to a higher-tier panel.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Final

PETITION_NODE_TYPE_VERSION: Final[str] = "cdl_095_petition_node_type_1494p.v0.1"
PETITION_NODE_TYPE_TAG: Final[str] = "ilc:petition:cdl_095"
JURY_PETITION_WINDOW_VALIDATION_EPOCHS: Final[int] = 1440
JURY_PETITION_BOND_MULTIPLIER: Final[int] = 3

_VALID_ESCALATION_GROUNDS: Final[frozenset[str]] = frozenset(
    {
        "petition",
        "procedural_error",
        "evidence_error",
        "diversity_fail",
        "high_stakes",
    }
)


def _require_non_empty_str(value: str, token: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(token)
    return value


def _require_non_negative_int(value: int, token: str) -> int:
    if type(value) is not int or value < 0:
        raise ValueError(token)
    return value


@dataclass(frozen=True)
class PetitionNodeType:
    """CDL-095 escalation petition graph-node payload."""

    petition_id: str
    petitioner_agent_id: str
    original_verdict_id: str
    escalation_grounds: str
    epoch_submitted: int
    petition_window_validation_epochs: int = JURY_PETITION_WINDOW_VALIDATION_EPOCHS
    petition_bond_multiplier: int = JURY_PETITION_BOND_MULTIPLIER
    node_type_tag: str = PETITION_NODE_TYPE_TAG

    def __post_init__(self) -> None:
        _require_non_empty_str(self.petition_id, "petition_node_id_invalid")
        _require_non_empty_str(self.petitioner_agent_id, "petition_node_petitioner_invalid")
        _require_non_empty_str(self.original_verdict_id, "petition_node_original_verdict_invalid")
        if self.escalation_grounds not in _VALID_ESCALATION_GROUNDS:
            raise ValueError("petition_node_escalation_grounds_invalid")
        _require_non_negative_int(self.epoch_submitted, "petition_node_epoch_submitted_invalid")
        _require_non_negative_int(
            self.petition_window_validation_epochs,
            "petition_node_window_invalid",
        )
        _require_non_negative_int(
            self.petition_bond_multiplier,
            "petition_node_bond_multiplier_invalid",
        )
        _require_non_empty_str(self.node_type_tag, "petition_node_type_tag_invalid")
        if self.petition_window_validation_epochs == 0:
            raise ValueError("petition_node_window_invalid")
        if self.petition_bond_multiplier == 0:
            raise ValueError("petition_node_bond_multiplier_invalid")

    def canonical_payload(self) -> dict[str, object]:
        """Return deterministic JSON-ready payload for hashing/export tests."""

        return {
            "epoch_submitted": self.epoch_submitted,
            "escalation_grounds": self.escalation_grounds,
            "node_type_tag": self.node_type_tag,
            "original_verdict_id": self.original_verdict_id,
            "petition_bond_multiplier": self.petition_bond_multiplier,
            "petition_id": self.petition_id,
            "petition_window_validation_epochs": self.petition_window_validation_epochs,
            "petitioner_agent_id": self.petitioner_agent_id,
            "schema_version": PETITION_NODE_TYPE_VERSION,
        }

    def canonical_json(self) -> str:
        """Serialize deterministically for content addressing."""

        return json.dumps(
            self.canonical_payload(),
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
