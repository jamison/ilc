# SPDX-License-Identifier: AGPL-3.0-only
# PUBLIC_RC_EXCLUDE: phase_1494p_cdl095_verdict_record_schema
# cdl_095_runtime_completions_committed_phase_1494p
# cdl_095_jury_finality_runtime_complete_phase_1494p
"""CDL-095 verdict record schema.

Canonical schema for a committed jury verdict record. Content-addressed;
immutable once committed.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from decimal import Decimal
from typing import Final

CDL_095_VERDICT_SCHEMA_VERSION: Final[str] = "cdl_095_verdict_record_schema_1494p.v0.1"

_VALID_VERDICTS: Final[frozenset[str]] = frozenset(
    {
        "upheld",
        "approved",
        "overturned",
        "rejected",
        "escalated",
    }
)


def _require_non_empty_str(value: str, token: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(token)
    return value


def _require_non_negative_int(value: int, token: str) -> int:
    if type(value) is not int or value < 0:
        raise ValueError(token)
    return value


def _require_bool(value: bool, token: str) -> bool:
    if type(value) is not bool:
        raise ValueError(token)
    return value


def _require_finite_decimal(value: Decimal) -> Decimal:
    if not isinstance(value, Decimal):
        raise ValueError("invalid_amount_not_decimal")
    if not value.is_finite():
        raise ValueError("invalid_amount_non_finite")
    if value < Decimal("0"):
        raise ValueError("invalid_amount_negative")
    return value


@dataclass(frozen=True)
class VerdictRecord:
    """Committed local jury verdict record under CDL-095 local-tier rules."""

    verdict_id: str
    jury_panel_id: str
    petition_node_id: str
    verdict: str
    quorum_count: int
    total_votes: int
    approve_votes: int
    reject_votes: int
    abstain_votes: int
    epoch_committed: int
    ecus_at_stake: Decimal
    high_stakes: bool = False
    diversity_floor_satisfied: bool = True
    regular_reviewer_count: int = 7

    def __post_init__(self) -> None:
        _require_non_empty_str(self.verdict_id, "verdict_record_id_invalid")
        _require_non_empty_str(self.jury_panel_id, "verdict_record_jury_panel_id_invalid")
        _require_non_empty_str(self.petition_node_id, "verdict_record_petition_node_id_invalid")
        if self.verdict not in _VALID_VERDICTS:
            raise ValueError("verdict_record_outcome_invalid")

        _require_non_negative_int(self.quorum_count, "verdict_record_quorum_count_invalid")
        _require_non_negative_int(self.total_votes, "verdict_record_total_votes_invalid")
        _require_non_negative_int(self.approve_votes, "verdict_record_approve_votes_invalid")
        _require_non_negative_int(self.reject_votes, "verdict_record_reject_votes_invalid")
        _require_non_negative_int(self.abstain_votes, "verdict_record_abstain_votes_invalid")
        _require_non_negative_int(self.epoch_committed, "verdict_record_epoch_committed_invalid")
        _require_non_negative_int(
            self.regular_reviewer_count,
            "verdict_record_regular_reviewer_count_invalid",
        )
        _require_bool(self.high_stakes, "verdict_record_high_stakes_invalid")
        _require_bool(
            self.diversity_floor_satisfied,
            "verdict_record_diversity_floor_satisfied_invalid",
        )
        _require_finite_decimal(self.ecus_at_stake)

        if self.regular_reviewer_count <= 0:
            raise ValueError("verdict_record_regular_reviewer_count_invalid")
        if self.quorum_count > self.regular_reviewer_count:
            raise ValueError("verdict_record_quorum_exceeds_regular_reviewers")
        if self.total_votes > self.regular_reviewer_count:
            raise ValueError("verdict_record_total_votes_exceeds_regular_reviewers")
        if self.quorum_count != self.total_votes:
            raise ValueError("verdict_record_quorum_total_mismatch")
        if self.approve_votes + self.reject_votes + self.abstain_votes != self.total_votes:
            raise ValueError("verdict_record_vote_breakdown_mismatch")

    def canonical_payload(self) -> dict[str, object]:
        """Return deterministic JSON-ready payload for hashing/export tests."""

        return {
            "abstain_votes": self.abstain_votes,
            "approve_votes": self.approve_votes,
            "diversity_floor_satisfied": self.diversity_floor_satisfied,
            "ecus_at_stake": str(self.ecus_at_stake),
            "epoch_committed": self.epoch_committed,
            "high_stakes": self.high_stakes,
            "jury_panel_id": self.jury_panel_id,
            "petition_node_id": self.petition_node_id,
            "quorum_count": self.quorum_count,
            "regular_reviewer_count": self.regular_reviewer_count,
            "reject_votes": self.reject_votes,
            "schema_version": CDL_095_VERDICT_SCHEMA_VERSION,
            "total_votes": self.total_votes,
            "verdict": self.verdict,
            "verdict_id": self.verdict_id,
        }

    def canonical_json(self) -> str:
        """Serialize deterministically for content addressing."""

        return json.dumps(
            self.canonical_payload(),
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
