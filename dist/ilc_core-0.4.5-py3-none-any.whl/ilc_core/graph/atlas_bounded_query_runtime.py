# SPDX-License-Identifier: AGPL-3.0-only
"""Read-only bounded Atlas graph queries for Graph Viz.

"""

from __future__ import annotations

import hashlib
import json
import re
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

import lmdb

from ilc_core.bundle.atlas_sidecar_profile import ALLOWED_BOUNDED_QUERY_TYPES
from ilc_core.storage.lmdb_public_runtime import _decode_json, _encode_key


GRAPH_VIZ_BOUNDED_QUERY_VERSION = "graph_viz_bounded_query_1576_fix11.v0.1"

MAX_NEIGHBORHOOD_HOPS = 3
MAX_NEIGHBORHOOD_NODES = 200
MAX_NEIGHBORHOOD_EDGES = 500
MAX_MEMBERSHIP_CHUNK_NODES = 1_000
MAX_AUTHORITY_PATH_DEPTH = 10
MAX_AUTHORITY_PATH_NODES = 50
MAX_HYPEREDGE_EXPANSION_EDGES = 200
MAX_STRING_LENGTH = 512
MAX_NODE_SCAN_ROWS = 250_000
MAX_EDGE_SCAN_ROWS = 250_000

GRAPH_VIZ_BOUNDED_QUERY_TOKEN = "graph_viz_bounded_query_api_committed_phase_1576_fix11"
GRAPH_VIZ_STARTUP_TOKEN = "graph_viz_installed_slice_startup_committed_phase_1576_fix11"
GRAPH_VIZ_TESTS_TOKEN = "graph_viz_bounded_query_tests_committed_phase_1576_fix11"
GRAPH_VIZ_NO_WHOLE_LMDB_TOKEN = "graph_viz_no_whole_lmdb_default_phase_1576_fix11"
GRAPH_VIZ_OUTPUT_TOKENS = (
    GRAPH_VIZ_BOUNDED_QUERY_TOKEN,
    GRAPH_VIZ_STARTUP_TOKEN,
    GRAPH_VIZ_TESTS_TOKEN,
    GRAPH_VIZ_NO_WHOLE_LMDB_TOKEN,
)

NON_CLAIMS = {
    "no_epoch_transition": True,
    "no_guard_clearance": True,
    "no_lmdb_write": True,
    "no_public_api_endpoint": True,
    "no_role_grant": True,
    "no_settlement": True,
    "no_wallet_write": True,
    "no_whole_lmdb_load_in_bounded_mode": True,
}
AUTHORITY_EDGE_TYPES = frozenset({"GOVERNS", "REFERENCES_AUTHORITY"})
NODE0 = "artifact:genesis_intent_attestation_init_authority_map"
_RECEIPT_PREFIX = "graph_viz_bounded_query_receipt:"
_HEX_96_RE = re.compile(r"^[0-9a-f]{96}$")
_RECEIPT_FIELDS = frozenset(
    {
        "generated_at_utc",
        "non_claims",
        "query_mode",
        "receipt_body_sha384",
        "receipt_id",
        "result_sha384",
        "schema_version",
        "tokens",
        "verdict",
    }
)
_RECEIPT_BODY_FIELDS = _RECEIPT_FIELDS - {"receipt_body_sha384", "receipt_id"}


class AtlasBoundedQueryError(ValueError):
    """Stable Graph Viz bounded query error."""


@dataclass
class _NeighborhoodAccumulator:
    visited: set[str]
    frontier: set[str]
    edge_rows: dict[str, dict[str, Any]]
    truncated: bool = False


class _ReadOnlyAtlasStore:
    """Read-only view over the Atlas candidate named DBs used by Graph Viz."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        self._closed = False
        try:
            self.env = lmdb.open(
                str(self.root),
                create=False,
                lock=False,
                max_dbs=8,
                readonly=True,
                readahead=False,
                subdir=True,
            )
        except lmdb.Error as exc:
            raise AtlasBoundedQueryError("graph_viz_lmdb_open_failed") from exc
        try:
            self._dbs = {
                b"nodes": self.env.open_db(b"nodes", create=False),
                b"edges": self.env.open_db(b"edges", create=False),
            }
        except lmdb.NotFoundError as exc:
            self.close()
            raise AtlasBoundedQueryError("graph_viz_lmdb_named_db_missing") from exc
        except lmdb.Error as exc:
            self.close()
            raise AtlasBoundedQueryError("graph_viz_lmdb_named_db_open_failed") from exc

    def close(self) -> None:
        if self._closed:
            return
        self.env.close()
        self._closed = True

    def get_node(self, candidate_id: str) -> dict[str, Any] | None:
        with self.env.begin(db=self._dbs[b"nodes"]) as txn:
            payload = _decode_json(txn.get(_encode_key(candidate_id)))
        return payload if isinstance(payload, dict) else None

    def get_edge(self, edge_id: str) -> dict[str, Any] | None:
        with self.env.begin(db=self._dbs[b"edges"]) as txn:
            payload = _decode_json(txn.get(_encode_key(edge_id)))
        if isinstance(payload, dict):
            return {**payload, "__lmdb_edge_key": edge_id}
        return None


def neighborhood(
    lmdb_path: str | Path,
    *,
    center_node_id: str,
    hops: int = 1,
    max_nodes: int = MAX_NEIGHBORHOOD_NODES,
    max_edges: int = MAX_NEIGHBORHOOD_EDGES,
) -> dict[str, Any]:
    """Return a capped undirected neighborhood around one Atlas node."""

    center = _required_str(center_node_id, "center_node_id")
    _validate_int(hops, "hops", minimum=0, maximum=MAX_NEIGHBORHOOD_HOPS)
    _validate_int(max_nodes, "max_nodes", minimum=1, maximum=MAX_NEIGHBORHOOD_NODES)
    _validate_int(max_edges, "max_edges", minimum=1, maximum=MAX_NEIGHBORHOOD_EDGES)
    store = _open_store(lmdb_path)
    try:
        center_node = store.get_node(center)
        if center_node is None:
            raise AtlasBoundedQueryError("graph_viz_center_node_not_found")
        state = _NeighborhoodAccumulator(
            visited={center},
            frontier={center},
            edge_rows={},
        )
        for _ in range(hops):
            if not state.frontier:
                break
            state.frontier = _collect_neighborhood_hop(
                store,
                state,
                max_nodes=max_nodes,
                max_edges=max_edges,
            )
        nodes = _load_nodes_by_id(store, state.visited)
        return _query_result(
            "neighborhood",
            nodes=nodes,
            edges=state.edge_rows.values(),
            truncated=state.truncated,
            parameters={
                "center_node_id": center,
                "hops": hops,
                "max_edges": max_edges,
                "max_nodes": max_nodes,
            },
        )
    finally:
        store.close()


def _collect_neighborhood_hop(
    store: _ReadOnlyAtlasStore,
    state: _NeighborhoodAccumulator,
    *,
    max_nodes: int,
    max_edges: int,
) -> set[str]:
    next_frontier: set[str] = set()
    for edge in _iter_edges(store):
        step = _neighborhood_step(edge, state.frontier)
        if step is None:
            continue
        source, target, neighbor = step
        if _try_add_neighborhood_neighbor(store, state, neighbor, max_nodes):
            next_frontier.add(neighbor)
        _record_internal_neighborhood_edge(edge, source, target, state, max_edges)
    return next_frontier


def _try_add_neighborhood_neighbor(
    store: _ReadOnlyAtlasStore,
    state: _NeighborhoodAccumulator,
    neighbor: str,
    max_nodes: int,
) -> bool:
    if neighbor in state.visited:
        return False
    if len(state.visited) >= max_nodes:
        state.truncated = True
        return False
    if store.get_node(neighbor) is None:
        return False
    state.visited.add(neighbor)
    return True


def _record_internal_neighborhood_edge(
    edge: dict[str, Any],
    source: str,
    target: str,
    state: _NeighborhoodAccumulator,
    max_edges: int,
) -> None:
    if source not in state.visited or target not in state.visited:
        return
    edge_key = _edge_identity(edge)
    if edge_key in state.edge_rows:
        return
    if len(state.edge_rows) >= max_edges:
        state.truncated = True
        return
    state.edge_rows[edge_key] = edge


def _neighborhood_step(
    edge: Mapping[str, Any],
    frontier: set[str],
) -> tuple[str, str, str] | None:
    source = _source(edge)
    target = _target(edge)
    if not source or not target:
        return None
    if source not in frontier and target not in frontier:
        return None
    neighbor = target if source in frontier else source
    return source, target, neighbor


def membership_chunk(
    lmdb_path: str | Path,
    *,
    stable_id: str,
    max_nodes: int = MAX_MEMBERSHIP_CHUNK_NODES,
) -> dict[str, Any]:
    """Return a capped local membership chunk for a projection or exact node ID."""

    stable = _required_str(stable_id, "stable_id")
    _validate_int(max_nodes, "max_nodes", minimum=1, maximum=MAX_MEMBERSHIP_CHUNK_NODES)
    store = _open_store(lmdb_path)
    try:
        nodes: list[dict[str, Any]] = []
        truncated = False
        for node in _iter_nodes(store):
            if not _node_matches_membership(node, stable):
                continue
            if len(nodes) >= max_nodes:
                truncated = True
                break
            nodes.append(node)
        return _query_result(
            "membership_chunk",
            nodes=nodes,
            edges=(),
            truncated=truncated,
            parameters={"max_nodes": max_nodes, "stable_id": stable},
        )
    finally:
        store.close()


def authority_path(
    lmdb_path: str | Path,
    *,
    node_id: str,
    max_depth: int = MAX_AUTHORITY_PATH_DEPTH,
    max_nodes: int = MAX_AUTHORITY_PATH_NODES,
) -> dict[str, Any]:
    """Trace a bounded authority path from a node toward Node 0."""

    start = _required_str(node_id, "node_id")
    _validate_int(max_depth, "max_depth", minimum=0, maximum=MAX_AUTHORITY_PATH_DEPTH)
    _validate_int(max_nodes, "max_nodes", minimum=1, maximum=MAX_AUTHORITY_PATH_NODES)
    store = _open_store(lmdb_path)
    try:
        if store.get_node(start) is None:
            raise AtlasBoundedQueryError("graph_viz_authority_node_not_found")
        seen = {start}
        queue: deque[tuple[str, list[str], list[dict[str, Any]]]] = deque([(start, [start], [])])
        best_path = [start]
        best_edges: list[dict[str, Any]] = []
        truncated = False
        while queue:
            current, path, path_edges = queue.popleft()
            if current == NODE0:
                best_path = path
                best_edges = path_edges
                break
            if len(path) - 1 >= max_depth:
                truncated = True
                continue
            for edge in _iter_edges(store):
                if _edge_type(edge) not in AUTHORITY_EDGE_TYPES:
                    continue
                source = _source(edge)
                target = _target(edge)
                if current not in {source, target}:
                    continue
                neighbor = target if source == current else source
                if not neighbor or neighbor in seen:
                    continue
                if len(path) + 1 > max_nodes or len(seen) >= max_nodes:
                    truncated = True
                    continue
                if store.get_node(neighbor) is None:
                    continue
                seen.add(neighbor)
                next_path = [*path, neighbor]
                next_edges = [*path_edges, edge]
                if len(next_path) > len(best_path):
                    best_path = next_path
                    best_edges = next_edges
                queue.append((neighbor, next_path, next_edges))
        nodes = _load_nodes_by_id(store, best_path)
        return _query_result(
            "authority_path",
            nodes=nodes,
            edges=best_edges,
            truncated=truncated,
            parameters={"max_depth": max_depth, "max_nodes": max_nodes, "node_id": start},
            path_node_ids=best_path,
        )
    finally:
        store.close()


def hyperedge_expansion(
    lmdb_path: str | Path,
    *,
    edge_id: str,
    max_edges: int = MAX_HYPEREDGE_EXPANSION_EDGES,
) -> dict[str, Any]:
    """Return a capped edge neighborhood around one edge identity."""

    target_edge_id = _required_str(edge_id, "edge_id")
    _validate_int(max_edges, "max_edges", minimum=1, maximum=MAX_HYPEREDGE_EXPANSION_EDGES)
    store = _open_store(lmdb_path)
    try:
        seed = _find_edge(store, target_edge_id)
        if seed is None:
            raise AtlasBoundedQueryError("graph_viz_edge_not_found")
        seed_source = _source(seed)
        seed_target = _target(seed)
        seed_hyperedge = _hyperedge_id(seed)
        edges: list[dict[str, Any]] = []
        truncated = False
        node_ids: set[str] = set()
        for edge in _iter_edges(store):
            related = (
                _edge_identity(edge) == target_edge_id
                or bool(seed_hyperedge and _hyperedge_id(edge) == seed_hyperedge)
                or _source(edge) in {seed_source, seed_target}
                or _target(edge) in {seed_source, seed_target}
            )
            if not related:
                continue
            if len(edges) >= max_edges:
                truncated = True
                break
            edges.append(edge)
            if _source(edge):
                node_ids.add(_source(edge))
            if _target(edge):
                node_ids.add(_target(edge))
        return _query_result(
            "hyperedge_expansion",
            nodes=_load_nodes_by_id(store, node_ids),
            edges=edges,
            truncated=truncated,
            parameters={"edge_id": target_edge_id, "max_edges": max_edges},
        )
    finally:
        store.close()


def execute_bounded_query(
    *,
    query_mode: str,
    lmdb_path: str | Path,
    node_id: str = "",
    stable_id: str = "",
    edge_id: str = "",
    hops: int = 1,
    max_depth: int = MAX_AUTHORITY_PATH_DEPTH,
    max_nodes: int = MAX_NEIGHBORHOOD_NODES,
    max_edges: int = MAX_NEIGHBORHOOD_EDGES,
) -> dict[str, Any]:
    """Dispatch one ratified Graph Viz bounded query type."""

    if query_mode not in ALLOWED_BOUNDED_QUERY_TYPES:
        raise AtlasBoundedQueryError("graph_viz_query_mode_invalid")
    if query_mode == "neighborhood":
        return neighborhood(
            lmdb_path,
            center_node_id=node_id,
            hops=hops,
            max_nodes=max_nodes,
            max_edges=max_edges,
        )
    if query_mode == "membership_chunk":
        return membership_chunk(lmdb_path, stable_id=stable_id, max_nodes=max_nodes)
    if query_mode == "authority_path":
        return authority_path(
            lmdb_path,
            node_id=node_id,
            max_depth=max_depth,
            max_nodes=max_nodes,
        )
    if query_mode == "hyperedge_expansion":
        return hyperedge_expansion(lmdb_path, edge_id=edge_id, max_edges=max_edges)
    raise AtlasBoundedQueryError("graph_viz_query_dispatch_incomplete")


def build_graph_viz_query_receipt(
    result: Mapping[str, Any],
    *,
    generated_at_utc: str | None = None,
) -> dict[str, Any]:
    """Build a deterministic local Graph Viz bounded-query status receipt."""

    if generated_at_utc is None:
        generated_at_utc = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    _validate_timestamp(generated_at_utc)
    body = {
        "generated_at_utc": generated_at_utc,
        "non_claims": dict(NON_CLAIMS),
        "query_mode": _required_str(result.get("query_type"), "query_type"),
        "result_sha384": _sha384_canonical(result),
        "schema_version": GRAPH_VIZ_BOUNDED_QUERY_VERSION,
        "tokens": list(GRAPH_VIZ_OUTPUT_TOKENS),
        "verdict": "pass",
    }
    body_sha384 = _sha384_canonical(body)
    return {**body, "receipt_body_sha384": body_sha384, "receipt_id": f"{_RECEIPT_PREFIX}{body_sha384}"}


def validate_graph_viz_query_receipt(receipt: Mapping[str, Any]) -> dict[str, Any]:
    """Validate a local bounded-query receipt without re-reading query output."""

    _reject_float_tree(receipt)
    normalized = dict(receipt)
    if set(normalized) != _RECEIPT_FIELDS:
        raise AtlasBoundedQueryError("graph_viz_receipt_fields_invalid")
    _validate_timestamp(normalized["generated_at_utc"])
    if normalized["schema_version"] != GRAPH_VIZ_BOUNDED_QUERY_VERSION:
        raise AtlasBoundedQueryError("graph_viz_receipt_schema_version_invalid")
    if normalized["query_mode"] not in ALLOWED_BOUNDED_QUERY_TYPES:
        raise AtlasBoundedQueryError("graph_viz_receipt_query_mode_invalid")
    if normalized["tokens"] != list(GRAPH_VIZ_OUTPUT_TOKENS):
        raise AtlasBoundedQueryError("graph_viz_receipt_tokens_invalid")
    if normalized["non_claims"] != dict(NON_CLAIMS):
        raise AtlasBoundedQueryError("graph_viz_receipt_non_claims_invalid")
    if normalized["verdict"] != "pass":
        raise AtlasBoundedQueryError("graph_viz_receipt_verdict_invalid")
    _validate_sha384_hex(normalized["result_sha384"], "result_sha384")
    expected_body = {key: normalized[key] for key in sorted(_RECEIPT_BODY_FIELDS)}
    expected_body_sha384 = _sha384_canonical(expected_body)
    if normalized["receipt_body_sha384"] != expected_body_sha384:
        raise AtlasBoundedQueryError("graph_viz_receipt_body_sha384_invalid")
    if normalized["receipt_id"] != f"{_RECEIPT_PREFIX}{expected_body_sha384}":
        raise AtlasBoundedQueryError("graph_viz_receipt_id_invalid")
    return {**expected_body, "receipt_body_sha384": expected_body_sha384, "receipt_id": normalized["receipt_id"]}


def _open_store(lmdb_path: str | Path) -> _ReadOnlyAtlasStore:
    path = Path(lmdb_path)
    if not path.exists():
        raise AtlasBoundedQueryError("graph_viz_lmdb_path_missing")
    if not path.is_dir():
        raise AtlasBoundedQueryError("graph_viz_lmdb_path_not_directory")
    if not (path / "data.mdb").exists():
        raise AtlasBoundedQueryError("graph_viz_lmdb_data_missing")
    return _ReadOnlyAtlasStore(path)


def _iter_nodes(store: _ReadOnlyAtlasStore) -> Iterable[dict[str, Any]]:
    with store.env.begin(db=store._dbs[b"nodes"]) as txn:
        cursor = txn.cursor()
        for count, (_, value) in enumerate(cursor, start=1):
            if count > MAX_NODE_SCAN_ROWS:
                raise AtlasBoundedQueryError("graph_viz_node_scan_limit_exceeded")
            row = _decode_json(value)
            if isinstance(row, dict):
                yield row


def _iter_edges(store: _ReadOnlyAtlasStore) -> Iterable[dict[str, Any]]:
    with store.env.begin(db=store._dbs[b"edges"]) as txn:
        cursor = txn.cursor()
        for count, (key, value) in enumerate(cursor, start=1):
            if count > MAX_EDGE_SCAN_ROWS:
                raise AtlasBoundedQueryError("graph_viz_edge_scan_limit_exceeded")
            row = _decode_json(value)
            if isinstance(row, dict):
                storage_key = key.decode("utf-8", errors="replace")
                yield {**row, "__lmdb_edge_key": storage_key}


def _load_nodes_by_id(store: _ReadOnlyAtlasStore, node_ids: Iterable[str]) -> list[dict[str, Any]]:
    nodes = []
    for node_id in sorted(set(node_ids)):
        node = store.get_node(node_id)
        if node is not None:
            nodes.append(node)
    return nodes


def _find_edge(store: _ReadOnlyAtlasStore, edge_id: str) -> dict[str, Any] | None:
    direct = store.get_edge(edge_id)
    if direct is not None:
        return direct
    for edge in _iter_edges(store):
        if _edge_identity(edge) == edge_id:
            return edge
    return None


def _query_result(
    query_type: str,
    *,
    nodes: Iterable[Mapping[str, Any]],
    edges: Iterable[Mapping[str, Any]],
    truncated: bool,
    parameters: Mapping[str, Any],
    path_node_ids: list[str] | None = None,
) -> dict[str, Any]:
    node_rows = sorted((_project_node(node) for node in nodes), key=_node_sort_key)
    edge_rows = sorted((_project_edge(edge) for edge in edges), key=_edge_sort_key)
    result = {
        "edge_count": len(edge_rows),
        "edges": edge_rows,
        "non_claims": dict(NON_CLAIMS),
        "node_count": len(node_rows),
        "nodes": node_rows,
        "parameters": dict(sorted(parameters.items())),
        "query_type": query_type,
        "truncated": truncated,
        "version": GRAPH_VIZ_BOUNDED_QUERY_VERSION,
    }
    if path_node_ids is not None:
        result["path_node_ids"] = path_node_ids
    return result


def _project_node(node: Mapping[str, Any]) -> dict[str, str]:
    """Project raw LMDB node rows to a bounded display-safe schema."""

    return {
        "candidate_id": _node_id(node),
        "canonicality_tier": _string_field(node, "canonicality_tier"),
        "graph_projection": _string_field(node, "graph_projection"),
        "label": _string_field(node, "label"),
        "node_kind": _string_field(node, "node_kind"),
        "source_path": _string_field(node, "source_path"),
        "tier": _string_field(node, "tier"),
    }


def _project_edge(edge: Mapping[str, Any]) -> dict[str, str]:
    """Project raw LMDB edge rows to a bounded display-safe schema."""

    return {
        "edge_id": _edge_identity(edge),
        "edge_type": _edge_type(edge),
        "hyperedge_id": _hyperedge_id(edge),
        "source": _source(edge),
        "target": _target(edge),
    }


def _string_field(row: Mapping[str, Any], key: str) -> str:
    value = row.get(key)
    if isinstance(value, str):
        return value[:MAX_STRING_LENGTH]
    return ""


def _node_matches_membership(node: Mapping[str, Any], stable_id: str) -> bool:
    return stable_id in {
        str(node.get("candidate_id", "")),
        str(node.get("graph_projection", "")),
        str(node.get("tier", "")),
        str(node.get("canonicality_tier", "")),
    }


def _node_sort_key(node: Mapping[str, Any]) -> tuple[str, str]:
    return (_node_id(node), str(node.get("source_path", "")))


def _edge_sort_key(edge: Mapping[str, Any]) -> tuple[str, str, str, str]:
    return (_edge_identity(edge), _source(edge), _target(edge), _edge_type(edge))


def _node_id(node: Mapping[str, Any]) -> str:
    value = node.get("candidate_id") or node.get("id") or node.get("node_id")
    return value if isinstance(value, str) else ""


def _source(edge: Mapping[str, Any]) -> str:
    value = edge.get("source_candidate_id") or edge.get("source") or edge.get("src") or edge.get("from")
    return value if isinstance(value, str) else ""


def _target(edge: Mapping[str, Any]) -> str:
    value = edge.get("target_candidate_id") or edge.get("target") or edge.get("tgt") or edge.get("to")
    return value if isinstance(value, str) else ""


def _edge_type(edge: Mapping[str, Any]) -> str:
    value = edge.get("edge_type") or edge.get("type")
    return value if isinstance(value, str) else ""


def _edge_identity(edge: Mapping[str, Any]) -> str:
    value = edge.get("edge_id") or edge.get("canonical_id") or edge.get("id")
    if isinstance(value, str) and value:
        return value
    storage_key = edge.get("__lmdb_edge_key")
    if isinstance(storage_key, str) and storage_key:
        identity_basis = {"lmdb_edge_key": storage_key}
        digest = hashlib.sha384(_canonical_json_bytes(identity_basis)).hexdigest()[:24]
        return f"edge:synthetic:{digest}"
    identity_basis = {
        "edge_type": _edge_type(edge),
        "hyperedge_id": _hyperedge_id(edge),
        "source": _source(edge),
        "target": _target(edge),
    }
    digest = hashlib.sha384(_canonical_json_bytes(identity_basis)).hexdigest()[:24]
    return f"edge:synthetic:{digest}"


def _hyperedge_id(edge: Mapping[str, Any]) -> str:
    value = edge.get("hyperedge_id") or edge.get("canonical_hyperedge_id")
    return value if isinstance(value, str) else ""


def _validate_int(value: Any, label: str, *, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise AtlasBoundedQueryError(f"graph_viz_{label}_invalid")
    if value < minimum:
        raise AtlasBoundedQueryError(f"graph_viz_{label}_below_minimum")
    if value > maximum:
        raise AtlasBoundedQueryError(f"graph_viz_{label}_exceeds_cap")
    return value


def _required_str(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise AtlasBoundedQueryError(f"graph_viz_{label}_required")
    if len(value) > MAX_STRING_LENGTH:
        raise AtlasBoundedQueryError(f"graph_viz_{label}_too_long")
    return value


def _validate_timestamp(value: Any) -> None:
    if not isinstance(value, str) or not value:
        raise AtlasBoundedQueryError("graph_viz_timestamp_invalid")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise AtlasBoundedQueryError("graph_viz_timestamp_invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() != timezone.utc.utcoffset(parsed):
        raise AtlasBoundedQueryError("graph_viz_timestamp_not_utc")


def _validate_sha384_hex(value: Any, label: str) -> str:
    if not isinstance(value, str) or _HEX_96_RE.fullmatch(value) is None:
        raise AtlasBoundedQueryError(f"graph_viz_{label}_invalid")
    return value


def _canonical_json_bytes(payload: Any) -> bytes:
    _reject_float_tree(payload)
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _sha384_canonical(payload: Any) -> str:
    return hashlib.sha384(_canonical_json_bytes(payload)).hexdigest()


def _reject_float_tree(value: Any) -> None:
    if isinstance(value, float):
        raise AtlasBoundedQueryError("graph_viz_float_not_allowed")
    if isinstance(value, Mapping):
        for child in value.values():
            _reject_float_tree(child)
    elif isinstance(value, list | tuple):
        for child in value:
            _reject_float_tree(child)


__all__ = [
    "ALLOWED_BOUNDED_QUERY_TYPES",
    "AtlasBoundedQueryError",
    "AUTHORITY_EDGE_TYPES",
    "GRAPH_VIZ_BOUNDED_QUERY_VERSION",
    "GRAPH_VIZ_OUTPUT_TOKENS",
    "MAX_AUTHORITY_PATH_DEPTH",
    "MAX_AUTHORITY_PATH_NODES",
    "MAX_HYPEREDGE_EXPANSION_EDGES",
    "MAX_EDGE_SCAN_ROWS",
    "MAX_MEMBERSHIP_CHUNK_NODES",
    "MAX_NEIGHBORHOOD_EDGES",
    "MAX_NEIGHBORHOOD_HOPS",
    "MAX_NEIGHBORHOOD_NODES",
    "MAX_NODE_SCAN_ROWS",
    "NON_CLAIMS",
    "authority_path",
    "build_graph_viz_query_receipt",
    "execute_bounded_query",
    "hyperedge_expansion",
    "membership_chunk",
    "neighborhood",
    "validate_graph_viz_query_receipt",
]
