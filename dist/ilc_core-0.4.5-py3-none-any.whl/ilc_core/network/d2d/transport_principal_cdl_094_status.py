# PUBLIC_RC_EXCLUDE: phase_1435_cdl_ratification_status_scaffold
# PUBLIC_RC_EXCLUDE_REASON: Records CDL-094 governance status only; no public TransportPrincipal runtime activation.
# PUBLIC_RC_INCLUDE_REQUIRES: public-path runtime activation authority and release allowlist review.

"""Phase 1434-1435 CDL-094 TransportPrincipal governance status constants.

This module is a machine-readable non-activation status record. It does not
bind sockets, expose public P2P, enable public fetch serving, or authorize
non-loopback sidecar/projection serving.
"""

from __future__ import annotations


TRANSPORT_PRINCIPAL_CDL_094_STATUS_VERSION = (
    "transport_principal_cdl_094_governance_status_phase_1435.v0.2"
)
TRANSPORT_PRINCIPAL_CDL_OPENED_PHASE_1434_TOKEN = (
    "transport_principal_cdl_opened_phase_1434"
)
CDL_094_TRANSPORT_PRINCIPAL_OPENED_PHASE_1434_TOKEN = (
    "cdl_094_transport_principal_opened_phase_1434"
)
GAP_10_CDL_OPENING_COMMITTED_PHASE_1434_TOKEN = (
    "gap_10_cdl_opening_committed_phase_1434"
)
CDL_094_OPENING_ONLY_NOT_RATIFIED_PHASE_1434_TOKEN = (
    "cdl_094_opening_only_not_ratified_phase_1434"
)
TRANSPORT_PRINCIPAL_CDL_RATIFIED_PHASE_1435_TOKEN = (
    "transport_principal_cdl_ratified_phase_1435"
)
CDL_094_TRANSPORT_PRINCIPAL_RATIFIED_PHASE_1435_TOKEN = (
    "cdl_094_transport_principal_ratified_phase_1435"
)
GAP_10_CDL_GOVERNANCE_CLOSED_PHASE_1435_TOKEN = (
    "gap_10_cdl_governance_closed_phase_1435"
)
CDL_094_RATIFIED_GOVERNANCE_ONLY_NOT_ACTIVATED_PHASE_1435_TOKEN = (
    "cdl_094_ratified_governance_only_not_activated_phase_1435"
)
CDL_094_PRELOCK_COMMITTED_PHASE_1435_TOKEN = "cdl_094_prelock_committed_phase_1435"
CDL_094_SCOPE_CONSTANTS_LOCKED_PHASE_1435_TOKEN = (
    "cdl_094_scope_constants_locked_phase_1435"
)

TRANSPORT_PRINCIPAL_CDL_RATIFIED = True
TRANSPORT_PRINCIPAL_CDL_RATIFIED_CONSTANT_NAME = "TRANSPORT_PRINCIPAL_CDL_RATIFIED"
CDL_094_STATUS = "ratified"
CDL_094_RATIFIED = True
GAP_10_CDL_GOVERNANCE_CLOSED = True
GAP_10_CLOSED = True
AUTHENTICATED_PRINCIPAL_REQUIRED_FOR_NON_LOOPBACK = True
TRANSPORT_PRINCIPAL_REQUIRED_FOR_NON_LOOPBACK = True
IP_ONLY_AUTHENTICATION_ALLOWED = False
JSON_REQUESTER_ID_AUTHENTICATION_ALLOWED = False
REQUESTER_ID_FALLBACK_ALLOWED = False
RAW_AGENT_ID_DEFAULT_RATE_LIMIT_KEY_ALLOWED = False
CLIENT_IP_PRIMARY_RATE_LIMIT_KEY_ALLOWED = False
RATE_LIMIT_POLICY_ID = "per_agent_id_bound_transport_principal_epoch_window"
RATE_LIMIT_IDENTITY_SOURCE = "authenticated_transport_principal"
RATE_LIMIT_WINDOW_BASIS = "epoch_sequence"
RATE_LIMIT_NUMERIC_LIMITS_STATUS = "deferred_to_phase_1436_runtime_config"
RATE_LIMIT_SURFACE_BUCKETS = (
    "fetch",
    "verifier",
    "sidecar_projection",
    "p2p",
)
BAN_REVOCATION_INTERFACE_REQUIRED = True
BAN_REVOCATION_KEY_SOURCE = "authenticated_transport_principal"
PUBLIC_FETCH_SERVING_ENABLED = False
PUBLIC_P2P_ENABLED = False
NON_LOOPBACK_SIDECAR_PROJECTION_ENABLED = False
PUBLIC_CONFIDENTIAL_COORDINATION_ENABLED = False
JAMISON_CONFIDENTIAL_SIDECAR_STATUS = "planned_not_live"
LIVE_CONFIDENTIAL_CONTACT_INSTRUCTION_ADDED = False


def transport_principal_cdl_094_opening_status() -> dict[str, object]:
    """Return the CDL-094 governance status without side effects."""

    return {
        "version": TRANSPORT_PRINCIPAL_CDL_094_STATUS_VERSION,
        "cdl": "CDL-094",
        "status": CDL_094_STATUS,
        "ratified": CDL_094_RATIFIED,
        "gap_10_closed": GAP_10_CLOSED,
        "gap_10_cdl_governance_closed": GAP_10_CDL_GOVERNANCE_CLOSED,
        "policy_boundary_constant": TRANSPORT_PRINCIPAL_CDL_RATIFIED_CONSTANT_NAME,
        "transport_principal_cdl_ratified": TRANSPORT_PRINCIPAL_CDL_RATIFIED,
        "authenticated_principal_required_for_non_loopback": (
            AUTHENTICATED_PRINCIPAL_REQUIRED_FOR_NON_LOOPBACK
        ),
        "transport_principal_required_for_non_loopback": (
            TRANSPORT_PRINCIPAL_REQUIRED_FOR_NON_LOOPBACK
        ),
        "ip_only_authentication_allowed": IP_ONLY_AUTHENTICATION_ALLOWED,
        "json_requester_id_authentication_allowed": (
            JSON_REQUESTER_ID_AUTHENTICATION_ALLOWED
        ),
        "requester_id_fallback_allowed": REQUESTER_ID_FALLBACK_ALLOWED,
        "raw_agent_id_default_rate_limit_key_allowed": (
            RAW_AGENT_ID_DEFAULT_RATE_LIMIT_KEY_ALLOWED
        ),
        "client_ip_primary_rate_limit_key_allowed": (
            CLIENT_IP_PRIMARY_RATE_LIMIT_KEY_ALLOWED
        ),
        "rate_limit_policy_id": RATE_LIMIT_POLICY_ID,
        "rate_limit_identity_source": RATE_LIMIT_IDENTITY_SOURCE,
        "rate_limit_window_basis": RATE_LIMIT_WINDOW_BASIS,
        "rate_limit_numeric_limits_status": RATE_LIMIT_NUMERIC_LIMITS_STATUS,
        "rate_limit_surface_buckets": RATE_LIMIT_SURFACE_BUCKETS,
        "ban_revocation_interface_required": BAN_REVOCATION_INTERFACE_REQUIRED,
        "ban_revocation_key_source": BAN_REVOCATION_KEY_SOURCE,
        "public_fetch_serving_enabled": PUBLIC_FETCH_SERVING_ENABLED,
        "public_p2p_enabled": PUBLIC_P2P_ENABLED,
        "non_loopback_sidecar_projection_enabled": (
            NON_LOOPBACK_SIDECAR_PROJECTION_ENABLED
        ),
        "public_confidential_coordination_enabled": (
            PUBLIC_CONFIDENTIAL_COORDINATION_ENABLED
        ),
        "jamison_confidential_sidecar": JAMISON_CONFIDENTIAL_SIDECAR_STATUS,
        "live_confidential_contact_instruction_added": (
            LIVE_CONFIDENTIAL_CONTACT_INSTRUCTION_ADDED
        ),
        "tokens": (
            TRANSPORT_PRINCIPAL_CDL_OPENED_PHASE_1434_TOKEN,
            CDL_094_TRANSPORT_PRINCIPAL_OPENED_PHASE_1434_TOKEN,
            GAP_10_CDL_OPENING_COMMITTED_PHASE_1434_TOKEN,
            CDL_094_OPENING_ONLY_NOT_RATIFIED_PHASE_1434_TOKEN,
            CDL_094_PRELOCK_COMMITTED_PHASE_1435_TOKEN,
            CDL_094_SCOPE_CONSTANTS_LOCKED_PHASE_1435_TOKEN,
            TRANSPORT_PRINCIPAL_CDL_RATIFIED_PHASE_1435_TOKEN,
            CDL_094_TRANSPORT_PRINCIPAL_RATIFIED_PHASE_1435_TOKEN,
            GAP_10_CDL_GOVERNANCE_CLOSED_PHASE_1435_TOKEN,
            CDL_094_RATIFIED_GOVERNANCE_ONLY_NOT_ACTIVATED_PHASE_1435_TOKEN,
        ),
    }
