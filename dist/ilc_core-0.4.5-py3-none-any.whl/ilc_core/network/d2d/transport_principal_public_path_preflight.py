# PUBLIC_RC_EXCLUDE: internal_phase_helper_not_public_rc_launch_surface
# PUBLIC_RC_EXCLUDE_REASON: Phase 1277 public-path preflight scaffold; no listener or public transport activation.
# PUBLIC_RC_INCLUDE_REQUIRES: explicit public-path ADR, CDL-087 disposition, release allowlist review, and hostile-network hardening.

"""Phase 1277 TransportPrincipal public-path integration preflight.

This module validates the policy bindings needed before a future public path can
use TransportPrincipal. It deliberately does not open sockets, expose public
P2P, enable public fetch serving, or authorize non-loopback sidecar projection.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Collection, Mapping

from ilc_core.network.d2d.transport_principal_pre_public_path import (
    validate_transport_principal_context,
)


TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION = (
    "transport_principal_public_path_adr_runtime_preflight_phase_1277.v0.1"
)
TRANSPORT_PRINCIPAL_PUBLIC_P2P_NOT_ACTIVATED_TOKEN = (
    "transport_principal_public_p2p_not_activated_phase_1277"
)
REQUESTER_ID_FALLBACK_STILL_FORBIDDEN_TOKEN = (
    "requester_id_fallback_still_forbidden_phase_1277"
)
NON_LOOPBACK_PROJECTION_STILL_BLOCKED_TOKEN = (
    "non_loopback_projection_still_blocked_phase_1277"
)
PUBLIC_FETCH_SERVING_NOT_ENABLED_TOKEN = "public_fetch_serving_not_enabled_phase_1277"
CDL087_NOT_RATIFIED_BY_PHASE_1277_TOKEN = "cdl087_not_ratified_by_phase_1277"
SIDECAR_PUBLIC_PATH_NOT_AUTHORIZED_TOKEN = "sidecar_public_path_not_authorized_phase_1277"
RUST_PUBLIC_P2P_HARDENING_STILL_OPEN_TOKEN = (
    "rust_public_p2p_hardening_still_open_phase_1277"
)
GENESIS_ATLAS_V02_SIGNING_DEFERRED_TOKEN = (
    "genesis_atlas_v0_2_signing_deferred_until_atlas_g_tail_phase_1277"
)
CDL087_FIX_AFTER_1278_PLANNED_TOKEN = (
    "cdl087_ratification_fix_phase_planned_after_1277_1278_if_both_pass_phase_1277"
)

PREFLIGHT_STATE = "public_path_preflight_only"
PREFLIGHT_REF_PREFIX = "transport_principal_public_path_preflight_sha256"
_HEX_DIGEST_LENGTH = 64
_HEX = frozenset("0123456789abcdef")
_MAX_PREFLIGHT_PAYLOAD_DEPTH = 32
_MAX_PREFLIGHT_PAYLOAD_NODES = 100_000
_ALLOWED_PRIVACY_MODES = frozenset(
    {
        "ephemeral_principal_no_agentid_default",
        "rotating_pseudonymous_transport_principal",
    }
)
_REQUIRED_TOKENS = frozenset(
    {
        TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION,
        TRANSPORT_PRINCIPAL_PUBLIC_P2P_NOT_ACTIVATED_TOKEN,
        REQUESTER_ID_FALLBACK_STILL_FORBIDDEN_TOKEN,
        NON_LOOPBACK_PROJECTION_STILL_BLOCKED_TOKEN,
        PUBLIC_FETCH_SERVING_NOT_ENABLED_TOKEN,
        CDL087_NOT_RATIFIED_BY_PHASE_1277_TOKEN,
        SIDECAR_PUBLIC_PATH_NOT_AUTHORIZED_TOKEN,
        RUST_PUBLIC_P2P_HARDENING_STILL_OPEN_TOKEN,
        GENESIS_ATLAS_V02_SIGNING_DEFERRED_TOKEN,
        CDL087_FIX_AFTER_1278_PLANNED_TOKEN,
    }
)


def _reject_float_values(
    value: Any,
    *,
    _depth: int = 0,
    _seen: set[int] | None = None,
    _counter: list[int] | None = None,
) -> None:
    if _depth > _MAX_PREFLIGHT_PAYLOAD_DEPTH:
        raise ValueError("transport_principal_public_path_payload_too_deep")
    if _seen is None:
        _seen = set()
    if _counter is None:
        _counter = [0]
    _counter[0] += 1
    if _counter[0] > _MAX_PREFLIGHT_PAYLOAD_NODES:
        raise ValueError("transport_principal_public_path_payload_too_large")
    if isinstance(value, float):
        raise ValueError("transport_principal_public_path_float_values_forbidden")
    if isinstance(value, Mapping):
        object_id = id(value)
        if object_id in _seen:
            raise ValueError("transport_principal_public_path_payload_cycle_forbidden")
        _seen.add(object_id)
        try:
            for key, item in value.items():
                if not isinstance(key, str):
                    raise ValueError("transport_principal_public_path_payload_key_invalid")
                _reject_float_values(
                    item,
                    _depth=_depth + 1,
                    _seen=_seen,
                    _counter=_counter,
                )
        finally:
            _seen.remove(object_id)
        return
    if isinstance(value, (list, tuple)):
        object_id = id(value)
        if object_id in _seen:
            raise ValueError("transport_principal_public_path_payload_cycle_forbidden")
        _seen.add(object_id)
        try:
            for item in value:
                _reject_float_values(
                    item,
                    _depth=_depth + 1,
                    _seen=_seen,
                    _counter=_counter,
                )
        finally:
            _seen.remove(object_id)


def _canonical_json(value: Mapping[str, Any]) -> str:
    _reject_float_values(value)
    return json.dumps(value, sort_keys=True, allow_nan=False, separators=(",", ":"))


def _sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _require_epoch(name: str, value: Any) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"transport_principal_public_path_{name}_epoch_invalid")
    return value


def _require_false(name: str, value: Any, token: str) -> bool:
    if value is not False:
        raise ValueError(token)
    return False


def _require_text(name: str, value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"transport_principal_public_path_{name}_invalid")
    return value


def _require_hex_digest(name: str, value: Any) -> str:
    if (
        not isinstance(value, str)
        or len(value) != _HEX_DIGEST_LENGTH
        or any(char not in _HEX for char in value)
    ):
        raise ValueError(f"transport_principal_public_path_{name}_invalid")
    return value


def _require_prefixed_digest(name: str, value: Any, prefix: str) -> str:
    expected_prefix = f"{prefix}:"
    if not isinstance(value, str) or not value.startswith(expected_prefix):
        raise ValueError(f"transport_principal_public_path_{name}_invalid")
    _require_hex_digest(name, value[len(expected_prefix) :])
    return value


def _preflight_sha256(preflight: Mapping[str, Any]) -> str:
    payload = dict(preflight)
    payload.pop("preflight_sha256", None)
    return _sha256_hex(_canonical_json(payload))


def build_transport_principal_public_path_preflight(
    *,
    transport_principal_context: Mapping[str, Any],
    current_epoch: int,
    privacy_mode: str = "ephemeral_principal_no_agentid_default",
    revoked_credential_fingerprints: Collection[str] = (),
    replay_cache: Collection[str] = (),
    public_p2p_enabled: bool = False,
    public_fetch_serving_enabled: bool = False,
    non_loopback_projection_enabled: bool = False,
    requester_id_fallback_allowed: bool = False,
    client_ip_rate_limit_key_allowed: bool = False,
    agent_id_rate_limit_key_allowed: bool = False,
    harness_identity_rate_limit_key_allowed: bool = False,
    cdl087_ratified: bool = False,
    sidecar_public_path_authorized: bool = False,
    rust_public_p2p_hardening_complete: bool = False,
    release_artifact_authorized: bool = False,
) -> dict[str, Any]:
    """Build a fail-closed public-path preflight record from a principal context."""

    current = _require_epoch("current", current_epoch)
    mode = _require_text("privacy_mode", privacy_mode)
    if mode not in _ALLOWED_PRIVACY_MODES:
        raise ValueError("transport_principal_public_path_privacy_mode_invalid")

    validated_context = validate_transport_principal_context(
        transport_principal_context,
        current_epoch=current,
        revoked_credential_fingerprints=revoked_credential_fingerprints,
        replay_cache=replay_cache,
    )

    _require_false(
        "public_p2p_enabled",
        public_p2p_enabled,
        TRANSPORT_PRINCIPAL_PUBLIC_P2P_NOT_ACTIVATED_TOKEN,
    )
    _require_false(
        "public_fetch_serving_enabled",
        public_fetch_serving_enabled,
        PUBLIC_FETCH_SERVING_NOT_ENABLED_TOKEN,
    )
    _require_false(
        "non_loopback_projection_enabled",
        non_loopback_projection_enabled,
        NON_LOOPBACK_PROJECTION_STILL_BLOCKED_TOKEN,
    )
    _require_false(
        "requester_id_fallback_allowed",
        requester_id_fallback_allowed,
        REQUESTER_ID_FALLBACK_STILL_FORBIDDEN_TOKEN,
    )
    _require_false(
        "client_ip_rate_limit_key_allowed",
        client_ip_rate_limit_key_allowed,
        "client_ip_rate_limit_key_still_devnet_only_phase_1277",
    )
    _require_false(
        "agent_id_rate_limit_key_allowed",
        agent_id_rate_limit_key_allowed,
        "agent_id_rate_limit_key_still_forbidden_phase_1277",
    )
    _require_false(
        "harness_identity_rate_limit_key_allowed",
        harness_identity_rate_limit_key_allowed,
        "harness_identity_rate_limit_key_still_forbidden_phase_1277",
    )
    _require_false("cdl087_ratified", cdl087_ratified, CDL087_NOT_RATIFIED_BY_PHASE_1277_TOKEN)
    _require_false(
        "sidecar_public_path_authorized",
        sidecar_public_path_authorized,
        SIDECAR_PUBLIC_PATH_NOT_AUTHORIZED_TOKEN,
    )
    _require_false(
        "rust_public_p2p_hardening_complete",
        rust_public_p2p_hardening_complete,
        RUST_PUBLIC_P2P_HARDENING_STILL_OPEN_TOKEN,
    )
    _require_false(
        "release_artifact_authorized",
        release_artifact_authorized,
        "release_artifact_not_authorized_phase_1277",
    )

    preflight: dict[str, Any] = {
        "version": TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION,
        "state": PREFLIGHT_STATE,
        "current_epoch": current,
        "principal_id": validated_context["principal_id"],
        "credential_fingerprint": validated_context["credential_fingerprint"],
        "credential_kind": validated_context["credential_kind"],
        "context_version": validated_context["version"],
        "context_scope": validated_context["scope"],
        "context_tokens": list(validated_context["tokens"]),
        "issued_epoch": validated_context["issued_epoch"],
        "expires_epoch": validated_context["expires_epoch"],
        "rate_limit_key": validated_context["rate_limit_key"],
        "admission_key": validated_context["admission_key"],
        "ban_key": validated_context["ban_key"],
        "replay_key": validated_context["replay_key"],
        "authorization_flags": {
            "public_p2p_enabled": False,
            "public_fetch_serving_enabled": False,
            "non_loopback_projection_enabled": False,
            "cdl087_ratified": False,
            "sidecar_public_path_authorized": False,
            "rust_public_p2p_hardening_complete": False,
            "release_artifact_authorized": False,
        },
        "fallback_policy": {
            "requester_id_fallback_allowed": False,
            "client_ip_rate_limit_key_allowed": False,
            "agent_id_rate_limit_key_allowed": False,
            "harness_identity_rate_limit_key_allowed": False,
            "rate_limit_identity_source": "authenticated_transport_principal",
        },
        "security_controls": {
            "revocation_checked": True,
            "replay_checked": True,
            "privacy_mode": mode,
            "epoch_rotation_required": True,
            "full_hash_binding_required": True,
        },
        "carry_forward_requirements": [
            "cdl087_explicit_ratification_after_phase_1278_if_1277_1278_pass",
            "sidecar_public_path_authorization_preflight_phase_1278",
            "rust_m5_public_p2p_hardening_before_public_p2p_claim",
            "genesis_atlas_v0_2_signing_deferred_until_atlas_g_tail",
        ],
        "tokens": sorted(_REQUIRED_TOKENS),
    }
    preflight["preflight_sha256"] = _preflight_sha256(preflight)
    return validate_transport_principal_public_path_preflight(preflight, current_epoch=current)


def validate_transport_principal_public_path_preflight(
    preflight: Mapping[str, Any],
    *,
    current_epoch: int,
    revoked_credential_fingerprints: Collection[str] = (),
    replay_cache: Collection[str] = (),
) -> dict[str, Any]:
    """Validate a Phase 1277 public-path preflight payload."""

    if not isinstance(preflight, Mapping):
        raise ValueError("transport_principal_public_path_preflight_invalid")
    _reject_float_values(preflight)
    current = _require_epoch("current", current_epoch)
    if preflight.get("version") != TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION:
        raise ValueError("transport_principal_public_path_preflight_version_invalid")
    if preflight.get("state") != PREFLIGHT_STATE:
        raise ValueError("transport_principal_public_path_preflight_state_invalid")
    if _require_epoch("current", preflight.get("current_epoch")) != current:
        raise ValueError("transport_principal_public_path_current_epoch_mismatch")

    credential_fingerprint = _require_hex_digest(
        "credential_fingerprint",
        preflight.get("credential_fingerprint"),
    )
    principal_id = _require_prefixed_digest("principal_id", preflight.get("principal_id"), "tp")
    _require_text("credential_kind", preflight.get("credential_kind"))
    _require_text("context_version", preflight.get("context_version"))
    if preflight.get("context_scope") != "pre_public_path":
        raise ValueError("transport_principal_public_path_context_scope_invalid")
    issued = _require_epoch("issued", preflight.get("issued_epoch"))
    expires = _require_epoch("expires", preflight.get("expires_epoch"))
    if issued > current or current > expires:
        raise ValueError("transport_principal_public_path_epoch_window_invalid")
    rate_limit_key = _require_prefixed_digest(
        "rate_limit_key",
        preflight.get("rate_limit_key"),
        "tp_rate",
    )
    admission_key = _require_prefixed_digest(
        "admission_key",
        preflight.get("admission_key"),
        "tp_admission",
    )
    ban_key = _require_prefixed_digest("ban_key", preflight.get("ban_key"), "tp_ban")
    replay_key = _require_prefixed_digest(
        "replay_key",
        preflight.get("replay_key"),
        "tp_replay",
    )

    if (
        credential_fingerprint in revoked_credential_fingerprints
        or principal_id in revoked_credential_fingerprints
    ):
        raise ValueError("transport_principal_public_path_revoked")
    if replay_key in replay_cache:
        raise ValueError("transport_principal_public_path_replay_detected")

    authorization_flags = preflight.get("authorization_flags")
    if not isinstance(authorization_flags, Mapping):
        raise ValueError("transport_principal_public_path_authorization_flags_invalid")
    _require_false(
        "public_p2p_enabled",
        authorization_flags.get("public_p2p_enabled"),
        TRANSPORT_PRINCIPAL_PUBLIC_P2P_NOT_ACTIVATED_TOKEN,
    )
    _require_false(
        "public_fetch_serving_enabled",
        authorization_flags.get("public_fetch_serving_enabled"),
        PUBLIC_FETCH_SERVING_NOT_ENABLED_TOKEN,
    )
    _require_false(
        "non_loopback_projection_enabled",
        authorization_flags.get("non_loopback_projection_enabled"),
        NON_LOOPBACK_PROJECTION_STILL_BLOCKED_TOKEN,
    )
    _require_false(
        "cdl087_ratified",
        authorization_flags.get("cdl087_ratified"),
        CDL087_NOT_RATIFIED_BY_PHASE_1277_TOKEN,
    )
    _require_false(
        "sidecar_public_path_authorized",
        authorization_flags.get("sidecar_public_path_authorized"),
        SIDECAR_PUBLIC_PATH_NOT_AUTHORIZED_TOKEN,
    )
    _require_false(
        "rust_public_p2p_hardening_complete",
        authorization_flags.get("rust_public_p2p_hardening_complete"),
        RUST_PUBLIC_P2P_HARDENING_STILL_OPEN_TOKEN,
    )
    _require_false(
        "release_artifact_authorized",
        authorization_flags.get("release_artifact_authorized"),
        "release_artifact_not_authorized_phase_1277",
    )

    fallback_policy = preflight.get("fallback_policy")
    if not isinstance(fallback_policy, Mapping):
        raise ValueError("transport_principal_public_path_fallback_policy_invalid")
    _require_false(
        "requester_id_fallback_allowed",
        fallback_policy.get("requester_id_fallback_allowed"),
        REQUESTER_ID_FALLBACK_STILL_FORBIDDEN_TOKEN,
    )
    _require_false(
        "client_ip_rate_limit_key_allowed",
        fallback_policy.get("client_ip_rate_limit_key_allowed"),
        "client_ip_rate_limit_key_still_devnet_only_phase_1277",
    )
    _require_false(
        "agent_id_rate_limit_key_allowed",
        fallback_policy.get("agent_id_rate_limit_key_allowed"),
        "agent_id_rate_limit_key_still_forbidden_phase_1277",
    )
    _require_false(
        "harness_identity_rate_limit_key_allowed",
        fallback_policy.get("harness_identity_rate_limit_key_allowed"),
        "harness_identity_rate_limit_key_still_forbidden_phase_1277",
    )
    if fallback_policy.get("rate_limit_identity_source") != "authenticated_transport_principal":
        raise ValueError("transport_principal_public_path_rate_limit_identity_source_invalid")

    security_controls = preflight.get("security_controls")
    if not isinstance(security_controls, Mapping):
        raise ValueError("transport_principal_public_path_security_controls_invalid")
    if security_controls.get("revocation_checked") is not True:
        raise ValueError("transport_principal_public_path_revocation_check_required")
    if security_controls.get("replay_checked") is not True:
        raise ValueError("transport_principal_public_path_replay_check_required")
    if security_controls.get("epoch_rotation_required") is not True:
        raise ValueError("transport_principal_public_path_epoch_rotation_required")
    if security_controls.get("full_hash_binding_required") is not True:
        raise ValueError("transport_principal_public_path_full_hash_binding_required")
    if security_controls.get("privacy_mode") not in _ALLOWED_PRIVACY_MODES:
        raise ValueError("transport_principal_public_path_privacy_mode_invalid")

    tokens = preflight.get("tokens")
    if not isinstance(tokens, list) or not all(isinstance(token, str) for token in tokens):
        raise ValueError("transport_principal_public_path_tokens_invalid")
    if not _REQUIRED_TOKENS.issubset(set(tokens)):
        raise ValueError("transport_principal_public_path_required_tokens_missing")

    context_tokens = preflight.get("context_tokens")
    if not isinstance(context_tokens, list) or not all(
        isinstance(token, str) for token in context_tokens
    ):
        raise ValueError("transport_principal_public_path_context_tokens_invalid")
    carry_forward_requirements = preflight.get("carry_forward_requirements")
    if not isinstance(carry_forward_requirements, list) or not all(
        isinstance(item, str) for item in carry_forward_requirements
    ):
        raise ValueError("transport_principal_public_path_carry_forward_requirements_invalid")

    if preflight.get("preflight_sha256") != _preflight_sha256(preflight):
        raise ValueError("transport_principal_public_path_preflight_hash_mismatch")

    validated = {
        "admission_key": admission_key,
        "authorization_flags": dict(authorization_flags),
        "ban_key": ban_key,
        "carry_forward_requirements": list(carry_forward_requirements),
        "context_scope": "pre_public_path",
        "context_tokens": list(context_tokens),
        "context_version": preflight["context_version"],
        "credential_fingerprint": credential_fingerprint,
        "credential_kind": preflight["credential_kind"],
        "current_epoch": current,
        "expires_epoch": expires,
        "fallback_policy": dict(fallback_policy),
        "issued_epoch": issued,
        "preflight_sha256": preflight["preflight_sha256"],
        "principal_id": principal_id,
        "rate_limit_key": rate_limit_key,
        "replay_key": replay_key,
        "security_controls": dict(security_controls),
        "state": PREFLIGHT_STATE,
        "tokens": sorted(_REQUIRED_TOKENS),
        "version": TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION,
    }
    _reject_float_values(validated)
    return validated


def transport_principal_public_path_preflight_ref(preflight: Mapping[str, Any]) -> str:
    validated = validate_transport_principal_public_path_preflight(
        preflight,
        current_epoch=_require_epoch("current", preflight.get("current_epoch")),
    )
    return f"{PREFLIGHT_REF_PREFIX}:{validated['preflight_sha256']}"


def export_transport_principal_public_path_preflight_json(preflight: Mapping[str, Any]) -> str:
    validated = validate_transport_principal_public_path_preflight(
        preflight,
        current_epoch=_require_epoch("current", preflight.get("current_epoch")),
    )
    return _canonical_json(validated)
