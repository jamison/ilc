# PUBLIC_RC_EXCLUDE: phase_1483p_rust_p2p_bridge_stub
# PUBLIC_RC_EXCLUDE_REASON: Private pre-public subprocess bridge stub. Not activated for public RC.
"""Private Rust P2P bridge stub for Window 1481p.

This module is intentionally disabled. It records the Python-side subprocess
shape for a future Rust P2P bridge without activating native Rust P2P from the
Python runtime.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Final


RUST_P2P_BRIDGE_NOT_ACTIVATED: Final[bool] = True
CDL_094_ADMISSION_WIRE_NOT_ACTIVATED: Final[bool] = True
MAX_PAYLOAD_BYTES: Final[int] = 65_536
DEFAULT_TIMEOUT_S: Final[float] = 5.0
_REPO_ROOT = Path(__file__).resolve().parents[2]
_BRIDGE_BINARY_REL = Path("ilc_consensus") / "target" / "debug" / "ilc_p2p_bridge"


class RustP2PBridge:
    """Disabled subprocess wrapper for future Rust P2P sends."""

    def transport_principal_admission_check(self, endpoint_id: str) -> bool:
        """CDL-094 admission check hook for future Rust P2P sends.

        cdl_094_transport_principal_admission_wired_phase_1490p
        werner_condition_4_transport_principal_admission_covered_phase_1490p
        """
        _require_endpoint_id(endpoint_id)
        if CDL_094_ADMISSION_WIRE_NOT_ACTIVATED:
            raise NotImplementedError("cdl_094_admission_wire_not_activated")
        raise NotImplementedError("cdl_094_admission_logic_not_implemented")

    def send_via_rust_p2p(
        self,
        endpoint_id: str,
        payload: bytes,
        timeout_s: float = DEFAULT_TIMEOUT_S,
    ) -> bool:
        clean_endpoint_id = _require_endpoint_id(endpoint_id)
        clean_payload = _require_payload(payload)
        clean_timeout = _require_timeout(timeout_s)

        if RUST_P2P_BRIDGE_NOT_ACTIVATED:
            return False

        command = [
            str(_BRIDGE_BINARY_REL),
            "send",
            "--request-json",
            json.dumps(
                {
                    "endpoint_id": clean_endpoint_id,
                    "payload_hex": clean_payload.hex(),
                },
                allow_nan=False,
                separators=(",", ":"),
                sort_keys=True,
            ),
        ]
        completed = subprocess.run(
            command,
            check=False,
            shell=False,
            timeout=clean_timeout,
            capture_output=True,
            cwd=_REPO_ROOT,
        )
        return completed.returncode == 0


def _require_endpoint_id(value: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("rust_p2p_bridge_invalid_endpoint_id")
    clean = value.strip()
    if len(clean) > 256 or "\x00" in clean:
        raise ValueError("rust_p2p_bridge_invalid_endpoint_id")
    return clean


def _require_payload(value: bytes) -> bytes:
    if not isinstance(value, bytes):
        raise ValueError("rust_p2p_bridge_invalid_payload")
    if len(value) > MAX_PAYLOAD_BYTES:
        raise ValueError("rust_p2p_bridge_payload_too_large")
    return value


def _require_timeout(value: float) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise ValueError("rust_p2p_bridge_invalid_timeout")
    clean = float(value)
    if not 0 < clean <= 30:
        raise ValueError("rust_p2p_bridge_invalid_timeout")
    return clean


__all__ = [
    "CDL_094_ADMISSION_WIRE_NOT_ACTIVATED",
    "MAX_PAYLOAD_BYTES",
    "RUST_P2P_BRIDGE_NOT_ACTIVATED",
    "RustP2PBridge",
]
